# ⛔ AVISO — ESTA APP ES SOLO HORIZONTAL (NADA DE MODO VERTICAL) ⛔

**E-Player NO tiene ni tendrá modo vertical.** Ningún arreglo, mejora o función nueva puede volver a agregarlo,
ni pensar en pantallas o diseños para vertical. Todo se diseña SOLO para horizontal (celular acostado, tablet, TV).

Reglas fijas (no negociables):

1. `AndroidManifest.xml`: **todas** las `<activity>` llevan `android:screenOrientation="sensorLandscape"`. Nunca quitarlo ni cambiarlo.
2. `MainActivity.java`: el método `landscape(...)` siempre fija `SCREEN_ORIENTATION_SENSOR_LANDSCAPE`, también al salir del video. Nunca usar `UNSPECIFIED`, `SENSOR`, `USER` ni `PORTRAIT`.
3. CSS: prohibido escribir `@media (orientation:portrait)` o `max-aspect-ratio`. No se hacen layouts verticales (ni columnas apiladas «para celular de pie»).
4. `manifest.webmanifest`: `"orientation": "landscape"`.
5. `unlockOr()` en `20-player.js` NO libera la orientación: solo vuelve a fijar horizontal.
6. Única excepción: el aviso «Gira tu dispositivo» (`#rot`, marcado `ROT-START/ROT-END` en `vip.css`), que solo aparece en navegador/PWA si alguien abre la web de pie.

**Protección automática:** `npm run build` (web/scripts/build.js) FALLA con un mensaje si detecta modo vertical en el CSS,
el manifest web, el AndroidManifest o MainActivity. Si falla, quita el modo vertical; no desactives la guardia.

---

# ⚠️ AVISO — CUALQUIER AJUSTE SUBE LA VERSIÓN ⚠️

**Cualquier cambio al software, por pequeño que sea (un color, un texto, una animación, un arreglo),
obliga a SUBIR la versión antes de devolver el proyecto.** Sin excepciones y sin que nadie tenga que recordarlo.

Lista de comprobación antes de entregar el zip (hacer las 4 cosas):

1. `android/app/build.gradle` → subir `def vcFloor = N` (+1 como mínimo) y actualizar el comentario de historial.
2. `web/package.json` y `web/package-lock.json` → subir el número de la web (p. ej. 6.7.0 → 6.8.0).
3. `web/src/app/00-core.js` → subir `VER='x.y.z-pwa'` al mismo número.
4. Esta tabla (abajo) → añadir una fila con el nuevo código y qué cambió. El nombre del zip lleva la versión (v14, v15…).

---

# Regla de versiones (leer antes de entregar o compilar)

**Cada vez que se devuelve el proyecto (zip) hay que SUBIR la versión, aunque el cambio sea mínimo.**
Nunca se entrega un zip con el mismo código de versión que el anterior.

Por qué: Google Play Console rechaza cualquier .aab cuyo `versionCode` ya se haya usado
("Ya se usó el código de la versión N. Prueba con otro código.").

Dónde se cambia (un solo lugar):

- `android/app/build.gradle` → `def vcFloor = N`
  - El código final es `max(-PvCode del proceso de compilación, vcFloor)`.
  - Si el proceso de compilación (GitHub Actions) pasa un `-PvCode` menor que el piso, **gana el piso**:
    por eso, si el piso no sube, el .aab sale siempre con el mismo número.
- `versionName` se calcula solo: `"2." + versionCode`.

Antes de subir a Play Console, comprobar que el .aab nuevo dice el código esperado
(la pantalla de Play Console lo muestra al subir el archivo).

Historial de códigos:

| Código | Qué fue |
|-------:|---------|
| 120 | Subido a Play Console |
| 121 | v8-fix (solo corrige el piso de versión) |
| 122 | v9: auditoría IPTV (M3U / Xtream / reproducción) |
| 123 | v10: rediseño 3D (dock, losas, transiciones, GSAP) |
| 124 | v10.1: mismo rediseño 3D, entrega renombrada (el código sube por la regla de versiones) |
| 125 | v11: mismo código que v10.1, entrega renombrada (nombre simple sin punto, para que el workflow lo tome) |
| 126 | v12: corrige el celular en horizontal (el dock inferior aplastaba el Inicio; ahora es un riel fijo a la izquierda) |
| 127 | v13: login rediseñado (tarjeta de dos caras: acceso y cuentas guardadas con scroll propio, buscador, borrado con confirmación) |
| 128 | v14: login con logo grande y transición «ElohimPlayer → E▮▶», fondo vivo con filas de contenido, y transición cinematográfica al pulsar Entrar (web 6.7.0) |
| 129 | v15: ElohimVIP (banner, tarjeta de funciones y aviso de pruebas): lista combinada de hasta 3 cuentas con buscador global, vencimientos por cuenta, multivista de 3 pantallas, temas, Ver más tarde, Mi resumen, canales rápidos y respaldo. Gratis: Compartir E-Player y Buscar actualización (web 6.8.0) |
| 130 | v16: SOLO HORIZONTAL: se eliminó todo el código de modo vertical, la orientación nunca se libera, aviso «Gira tu dispositivo» en la web y guardia en la compilación que impide volver a agregarlo (web 6.9.0) |
| 131 | v17: TV en vivo más fiable (memoria por canal, más intentos, motivo y diagnóstico proveedor/reproductor, respaldo avanzado también desde la vista previa) y ElohimVIP completo: cambio automático de fuente, ecualizador, subtítulos a medida, recordatorios de programas, alertas de vencimiento, enviar a otra pantalla, soporte y novedades (web 6.10.0) |
| 132 | v18: el VIP deja de depender del banner: multicuentas y todas las funciones en Perfil (acordeón), buscador superior global, botón Multivista en TV en vivo, banner ElohimVIP en el login; multivista con control y diagnóstico de sonido (web 6.11.0) |
| 133 | v19: buscador superior: resultados visibles mientras se escribe (lista compacta en pantalla baja, contador, Enter oculta el teclado) y teclado de Android sin pantalla completa; el banner del login indica «Incluido» (web 6.12.0) |
| 134 | v20: `npm start` trae su propio proxy local (ya no depende de «opcional-cloud-functions» ni del Worker) y el error de conexión de la web explica qué revisar (web 6.13.0) |
| 135 | v21: compatible con Android 5.0+ (`minSdk` 24 → 21) para TV box y tablets antiguos; la entrada de Android TV (LEANBACK_LAUNCHER) ahora viene activa por defecto; si el WebView del sistema falta o está desactivado se muestra un aviso en vez de cerrarse la app (web 6.14.0) |
| 136 | v22: aviso de Play «SDK desactualizado» (androidx.activity 1.0.0): se fijan activity 1.9.3, fragment 1.8.5 y core 1.13.1. Play rechazó el .aab 135 por la «protección automática» (exige minSdk 24): hay que desactivarla en Play Console para publicar con minSdk 21 (web 6.15.0) |

Web (`web/package.json` y `VER` en `web/src/app/00-core.js`): subir también el número cuando cambie la web.

## Probar la web en local (localhost)

1. `cd web && npm install && npm run build`
2. `npm start` (o `PORT=3000 npm start`) y abrir `http://localhost:8080` (o el puerto elegido).

`npm start` usa **su propio proxy local** y siempre ignora el Worker de producción: el Worker puede rechazar el origen
`localhost` y entonces la web muestra «no se pudo conectar» aunque la lista esté bien (en la app Android no se usa proxy).
Si el navegador muestra una versión vieja (Service Worker), recarga con Ctrl+Shift+R o limpia los datos del sitio.
