/* npm run build  ->  public/   (opcional: PROXY_URL=https://...run.app npm run build  para usar la URL directa de la función) */
const fs=require('fs'),path=require('path'),crypto=require('crypto');
let esbuild;try{esbuild=require('esbuild')}catch(e){console.error('Falta esbuild. Ejecuta primero:  npm install');process.exit(1)}
const R=(...a)=>path.join(__dirname,'..',...a),PUB=R('public');
const SRC=['lib.js','app/00-core.js','app/08-brand.js','app/09-cine.js','app/10-ui.js','app/15-screens.js','app/20-player.js','app/30-login-input.js','app/35-install.js','app/36-extras.js','app/40-license.js','app/45-vip.js','app/50-fx.js'];
/* ===== GUARDIA «SOLO HORIZONTAL» (ver LEEME-VERSIONES.md): si alguien vuelve a meter modo vertical, la compilación FALLA ===== */
(function(){const bad=[];
 ['style.css','fx.css','vip.css'].forEach(f=>{let c=fs.readFileSync(R('src',f),'utf8').replace(/\/\* ROT-START[\s\S]*?ROT-END \*\//g,'').replace(/\/\*[\s\S]*?\*\//g,'');
  if(/orientation\s*:\s*portrait|max-aspect-ratio|min-aspect-ratio\s*:\s*[0-9]\s*\/\s*[0-9]*\s*\)?\s*and\s*\(max/i.test(c))bad.push('src/'+f+' tiene reglas de modo vertical (orientation:portrait / max-aspect-ratio)')});
 try{const m=JSON.parse(fs.readFileSync(R('src/manifest.webmanifest'),'utf8'));if(m.orientation!=='landscape')bad.push('manifest.webmanifest: "orientation" debe ser "landscape"')}catch(e){bad.push('manifest.webmanifest ilegible')}
 const am=R('..','android','app','src','main','AndroidManifest.xml');
 if(fs.existsSync(am)){const x=fs.readFileSync(am,'utf8').replace(/<!--[\s\S]*?-->/g,''),acts=(x.match(/<activity\b/g)||[]).length,ok=(x.match(/android:screenOrientation="sensorLandscape"/g)||[]).length;
  if(acts!==ok)bad.push('AndroidManifest.xml: las '+acts+' activity deben llevar android:screenOrientation="sensorLandscape" (hay '+ok+')')}
 const mj=R('..','android','app','src','main','java','com','elohim','eplayer','MainActivity.java');
 if(fs.existsSync(mj)){const j=fs.readFileSync(mj,'utf8');if(/SCREEN_ORIENTATION_(UNSPECIFIED|SENSOR|FULL_SENSOR|USER|PORTRAIT|REVERSE_PORTRAIT|SENSOR_PORTRAIT|USER_PORTRAIT)\b/.test(j.replace(/\/\*[\s\S]*?\*\//g,'')))bad.push('MainActivity.java: solo se permite SCREEN_ORIENTATION_SENSOR_LANDSCAPE')}
 if(bad.length){console.error('\n⛔ ESTA APP ES SOLO HORIZONTAL. No se permite el modo vertical:\n - '+bad.join('\n - ')+'\nLee el aviso al inicio de LEEME-VERSIONES.md\n');process.exit(1)}})();
const code=SRC.map(f=>fs.readFileSync(R('src',f),'utf8')).join('\n');
const js=esbuild.transformSync(code,{target:'chrome53',minify:true}).code;   /* chrome53: también corre en navegadores de TV antiguos */
const VER=require(R('package.json')).version;
fs.rmSync(PUB,{recursive:true,force:true});fs.mkdirSync(PUB,{recursive:true});
fs.writeFileSync(path.join(PUB,'app.js'),js);
['index.html','style.css','fx.css','vip.css','qrcode.js','hls.min.js','mpegts.min.js','manifest.webmanifest','icon-192.png','icon-512.png','icon-maskable-512.png'].forEach(f=>fs.copyFileSync(R('src',f),path.join(PUB,f)));
/* GSAP (librería pública, MIT/Standard): viene de node_modules tras `npm install`. Sin ella la app funciona con CSS 3D */
const GS=R('node_modules/gsap/dist/gsap.min.js');
if(fs.existsSync(GS))fs.copyFileSync(GS,path.join(PUB,'gsap.min.js'));else{fs.writeFileSync(path.join(PUB,'gsap.min.js'),'/* gsap no instalado: ejecuta npm install */');console.warn('⚠ gsap no instalado (npm install): se usa solo CSS 3D')}
let PURL=(process.env.PROXY_URL||'').trim();
if(!PURL&&fs.existsSync(R('proxy-url.txt')))PURL=fs.readFileSync(R('proxy-url.txt'),'utf8').split('\n').map(s=>s.trim()).filter(s=>s&&s[0]!=='#')[0]||'';
PURL=PURL.replace(/\/+$/,'');
if(PURL&&!/^https?:\/\//.test(PURL)){console.error('proxy-url.txt: la URL debe empezar con https://');process.exit(1)}
fs.writeFileSync(path.join(PUB,'config.js'),'window.IPTV_PROXY=true;window.IPTV_PROXY_URL='+JSON.stringify(PURL)+';\n');
/* la versión del service worker cambia sola con cada cambio de contenido: los usuarios reciben la actualización */
const hash=crypto.createHash('sha1').update(js).update(fs.readFileSync(R('src/index.html'))).update(fs.readFileSync(R('src/style.css'))).update(fs.readFileSync(R('src/fx.css'))).update(fs.readFileSync(R('src/vip.css'))).digest('hex').slice(0,8);
fs.writeFileSync(path.join(PUB,'sw.js'),fs.readFileSync(R('src/sw.js'),'utf8').replace('__VER__',VER+'-'+hash));
console.log('public/ listo (v'+VER+'-'+hash+', app.js '+Math.round(js.length/1024)+' KB)'+(PURL?' · proxy: '+PURL:' · ⚠ SIN proxy (pon la URL de tu Worker en proxy-url.txt)'));
