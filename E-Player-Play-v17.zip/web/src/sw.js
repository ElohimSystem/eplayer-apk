/* Service worker de ElohimPlayer: la app abre al instante y funciona la interfaz aunque falle la red.
   NO guarda video, listas ni /proxy: eso siempre va directo a la red. La versión se estampa en build.sh. */
var CACHE='elohim-__VER__';
var SHELL=['./','index.html','style.css','fx.css','vip.css','gsap.min.js','app.js','hls.min.js','mpegts.min.js','manifest.webmanifest','icon-192.png','icon-512.png'];
self.addEventListener('install',function(e){
 e.waitUntil(caches.open(CACHE).then(function(c){return c.addAll(SHELL)}).then(function(){return self.skipWaiting()}));
});
self.addEventListener('activate',function(e){
 e.waitUntil(caches.keys().then(function(ks){return Promise.all(ks.filter(function(k){return k!==CACHE}).map(function(k){return caches.delete(k)}))}).then(function(){return self.clients.claim()}));
});
self.addEventListener('fetch',function(e){
 var r=e.request,u=new URL(r.url);
 if(r.method!=='GET'||u.origin!==location.origin||u.pathname==='/proxy'||u.pathname.indexOf('/proxy')===0||r.headers.has('range'))return;
 /* config.js lo genera el servidor (modo proxy): siempre red primero */
 if(u.pathname.slice(-10)==='/config.js'){
  e.respondWith(fetch(r).then(function(x){var k=x.clone();caches.open(CACHE).then(function(c){c.put(r,k)});return x}).catch(function(){return caches.match(r)}));return}
 /* resto: caché primero y se actualiza en segundo plano */
 e.respondWith(caches.match(r,{ignoreSearch:true}).then(function(hit){
  var net=fetch(r).then(function(x){if(x&&x.status===200){var k=x.clone();caches.open(CACHE).then(function(c){c.put(r,k)})}return x}).catch(function(){return hit});
  return hit||net;
 }));
});
