/* ===== v8: probar conexión, guía en cuadrícula, deslizar canales, primer uso, comentarios, atajos ===== */
const SUPPORT_MAIL='elohimguzman2023@gmail.com';
const npPref=(k,v)=>{try{if(window.AndroidApp&&AndroidApp.setPref)AndroidApp.setPref(k,v)}catch(e){}};
function mailTo(subject,body){const u='mailto:'+SUPPORT_MAIL+'?subject='+encodeURIComponent(subject)+(body?'&body='+encodeURIComponent(body):'');
 try{if(window.AndroidApp&&AndroidApp.openUrl){AndroidApp.openUrl(u);return}}catch(e){}location.href=u}

/* ---------- Probar conexión ---------- */
function ctRow(p,ok,t,d){const r=h('div','row ct '+(ok===null?'warn2':ok?'ok':'bad'));r.appendChild(h('span','rl ctm',ok===null?'!':ok?'✓':'✗'));
 const v=h('span','rv',t);if(d){v.appendChild(document.createElement('br'));v.appendChild(h('small','dm',d))}r.appendChild(v);p.appendChild(r);return r}
async function readHead(r){try{if(r.body&&r.body.getReader){const rd=r.body.getReader(),x=await rd.read();try{rd.cancel()}catch(e){}return new TextDecoder().decode(x.value||new Uint8Array())}}catch(e){}
 return String(await r.text()).slice(0,6000)}
async function connTest(cfg){
 const p=ovOpen('#ab');p.appendChild(h('h2','','Probar conexión'));
 const box=h('div','rows'),out=h('p','dm',''),acts=h('div','acts');p.appendChild(box);p.appendChild(out);p.appendChild(acts);
 const bb=btn(acts,'Volver',()=>ovClose('#ab'),'','close'),step=(ok,t,d)=>ctRow(box,ok,t,d),E=encodeURIComponent;
 out.textContent='Comprobando…';
 try{
  let host=null,user='',pass='';
  if(cfg.t==='X'){host=(cfg.host||'').trim();user=(cfg.user||'').trim();pass=cfg.pass||''}
  else if(cfg.t==='M'){const xu=parseXtreamUrl(cfg.url||'');if(xu){host=xu.host;user=xu.user;pass=xu.pass}}
  if(host!==null){
   if(!host||!user){step(false,'Faltan datos','Escribe el servidor y el usuario.');out.textContent='';return}
   const base=normalizeHost(host);step(true,'Dirección del servidor',base);
   const t0=performance.now();let info;
   try{info=await jget(base+'/player_api.php?username='+E(user)+'&password='+E(pass))}
   catch(e){const m=e.message||'';
    if(/^HTTP \d+/.test(m))step(false,'El servidor respondió con error: '+m,/40[13]/.test(m)?'Suele indicar usuario o contraseña incorrectos, o acceso bloqueado.':/5\d\d/.test(m)?'El servidor tiene un problema; intenta más tarde.':'Revisa la dirección y el puerto.');
    else if(/válidos/.test(m))step(false,'Respondió, pero no parece un servidor Xtream','Revisa la dirección y el puerto (ejemplo: http://servidor.com:8080).');
    else step(false,'No hubo respuesta del servidor','Revisa la dirección, el puerto y tu internet. El servidor podría estar caído o bloquear la app.');
    out.textContent='';return}
   const ms=Math.round(performance.now()-t0);step(ms>4000?null:true,'El servidor responde',ms+' ms'+(ms>4000?' · conexión lenta (prueba el buffer largo en Perfil)':''));
   const ui=info&&info.user_info;
   if(!ui||+ui.auth!==1){step(false,'Usuario o contraseña incorrectos','Revisa mayúsculas, espacios y que sean los de este servidor.');out.textContent='';return}
   step(true,'Credenciales correctas',user);
   const st=String(ui.status||'');
   if(/banned|disabled/i.test(st))step(false,'Cuenta '+st,'Contacta a tu proveedor.');
   else if(/expired/i.test(st))step(false,'Cuenta vencida'+(+ui.exp_date?' el '+fmtDay(+ui.exp_date*1000):''),'Contacta a tu proveedor para renovar.');
   else{const ex=+ui.exp_date;step(true,'Cuenta activa',ex?'Vence el '+fmtDay(ex*1000)+' ('+Math.max(0,Math.ceil((ex*1000-Date.now())/864e5))+' días)':'Sin fecha de vencimiento')}
   if(ui.max_connections){const a=+ui.active_cons||0,m=+ui.max_connections;step(a<m?true:null,'Conexiones en uso: '+a+' de '+m,a>=m?'Ya usas todas; cierra otro dispositivo antes de ver.':'')}
   try{const c=await jget(base+'/player_api.php?username='+E(user)+'&password='+E(pass)+'&action=get_live_categories');step(true,'Catálogo disponible',(Array.isArray(c)?c.length:0)+' categorías de TV')}
   catch(e){step(null,'No se pudo leer el catálogo','La cuenta entra, pero el servidor no entregó las categorías.')}
  }else if(cfg.t==='M'){
   const url=(cfg.url||'').trim();
   if(!/^https?:\/\//i.test(url)){step(false,'La dirección no es válida','Debe empezar con http:// o https://');out.textContent='';return}
   step(true,'Dirección de la lista','');
   const t0=performance.now();let r;
   try{r=await get(url)}catch(e){step(false,'No hubo respuesta del servidor','Revisa el enlace y tu internet. El servidor podría estar caído o bloquear la app.');out.textContent='';return}
   if(!r.ok){step(false,'El servidor respondió con error HTTP '+r.status,r.status===404?'El enlace no existe o venció.':'Revisa el enlace o pide uno nuevo a tu proveedor.');out.textContent='';return}
   step(true,'El servidor responde',Math.round(performance.now()-t0)+' ms');
   const txt=await readHead(r);
   if(!looksLikeM3U(txt)){const web=/^\s*</.test(txt);step(false,web?'Devolvió una página web, no una lista':'No es una lista M3U/M3U8 válida',web?'El enlace puede estar vencido, incorrecto o requerir iniciar sesión.':'Revisa que sea el enlace de la lista (.m3u o .m3u8).');out.textContent='';return}
   step(true,'Lista válida',(txt.match(/#EXTINF/g)||[]).length?'Se encontraron canales o videos':'Formato correcto')
  }else{step(false,'Primero completa los datos de acceso','');out.textContent='';return}
  const bad=box.querySelector('.bad');out.textContent=bad?'Hay un problema: revisa lo marcado con ✗.':'Todo en orden: ya puedes entrar.'}
 catch(e){step(false,'No se pudo comprobar',e.message||'');out.textContent=''}
 try{bb.focus()}catch(e){}}
$('#test').onclick=()=>connTest(srcType==='X'?{t:'X',host:$('#host').value,user:$('#user').value.trim(),pass:$('#pass').value}:{t:'M',url:$('#murl').value.trim()});

/* ---------- Deslizar para cambiar de canal (TV en vivo, celular) ---------- */
(function(){const pl=$('#pl');let sx=0,sy=0,t0=0,ok=false;
 pl.addEventListener('touchstart',e=>{const t=e.changedTouches[0];sx=t.clientX;sy=t.clientY;t0=Date.now();
  ok=!!(S.live&&!S.pv&&!D.open&&S.zap>=0&&!(e.target.closest&&e.target.closest('button,.pb,#cd,#pm,#ib,.cbt,.ct')))},{passive:true});
 pl.addEventListener('touchend',e=>{if(!ok)return;ok=false;const t=e.changedTouches[0],dx=t.clientX-sx,dy=t.clientY-sy;
  if(Date.now()-t0<700&&Math.abs(dy)>70&&Math.abs(dx)<Math.abs(dy)*.5){zap(dy<0?1:-1);showCtl();
   try{localStorage.setItem('ep_hz','99')}catch(x){}}},{passive:true})})();
/* aviso de la primera vez que se entra a un canal */
const zapHint=()=>{try{const n=+localStorage.getItem('ep_hz')||0;if(n<3&&S.live&&!S.pv){localStorage.setItem('ep_hz',String(n+1));toast('Desliza hacia arriba o abajo para cambiar de canal',4500)}}catch(e){}};
{const p0=playLiveFrom;playLiveFrom=function(){const r=p0.apply(this,arguments);if(TOUCH||narrow())setTimeout(zapHint,2500);return r}}

/* ---------- Guía en cuadrícula ---------- */
const PPM=.3;/* rem por minuto */
function openGuide(){
 const list=(S.view&&S.view.length?S.view:filterItems('*','','live')).filter(i=>i.type==='live').slice(0,400);
 if(!list.length){toast('No hay canales para mostrar',2500);return}
 let g=$('#gd');if(!g){g=h('div','ovl hidden');g.id='gd';document.body.appendChild(g)}
 const p=ovOpen('#gd');p.classList.add('gd');
 const T0=Math.floor(Date.now()/1800000)*1800000,SPAN=240,W=SPAN*PPM+'rem';
 const hd=h('div','gdh');hd.appendChild(h('h2','','Guía · '+catLabel(S.cat,S.mode)));const acts=h('div','acts');hd.appendChild(acts);btn(acts,'Volver',()=>ovClose('#gd'),'','close');p.appendChild(hd);
 const wrap=h('div','gdw');p.appendChild(wrap);
 const tr=h('div','gdr gdt');tr.appendChild(h('div','gdc',''));const tl=h('div','gdp');tl.style.width=W;
 for(let m=0;m<SPAN;m+=30){const c=h('span','gdk',hm(T0+m*60000));c.style.left=(m*PPM)+'rem';tl.appendChild(c)}tr.appendChild(tl);wrap.appendChild(tr);
 const now=(Date.now()-T0)/60000*PPM;
 const fill=(pn,L,it)=>{pn.textContent='';let any=false;
  (L||[]).forEach(x=>{const s=Math.max(x.start,T0),e=Math.min(x.end,T0+SPAN*60000);if(e<=s)return;any=true;
   const b=h('div','gdb'+(x.start<=Date.now()&&x.end>Date.now()?' now':''));b.style.left=((s-T0)/60000*PPM)+'rem';b.style.width=Math.max(2,((e-s)/60000*PPM)-.12)+'rem';
   b.appendChild(h('b','',x.title||'Sin título'));b.appendChild(h('small','',hm(x.start)+' – '+hm(x.end)));b.tabIndex=0;b.classList.add('f');
   b.onclick=()=>{if(x.start<=Date.now()&&x.end>Date.now()){ovClose('#gd');playLiveFrom(it,list)}else if(window.VIPX&&VIP.on()){VIPX.remind(it,x);b.classList.toggle('rem',VIPX.hasRem(it,x))}else toast((x.title||'')+' · '+hm(x.start)+' – '+hm(x.end),4500)};if(window.VIPX&&VIPX.hasRem(it,x))b.classList.add('rem');pn.appendChild(b)});
  if(!any)pn.appendChild(h('div','gdb none','Sin guía para este canal'))};
 const obs=('IntersectionObserver' in window)?new IntersectionObserver(es=>es.forEach(en=>{if(!en.isIntersecting)return;obs.unobserve(en.target);const r=en.target;
  epgLazy(r,r._i,L=>fill(r._p,L,r._i))}),{root:wrap,rootMargin:'200px'}):null;
 list.forEach(i=>{const r=h('div','gdr');r._i=i;const c=h('div','gdc f');c.tabIndex=0;if(i.logo){const im=h('img','');im.loading='lazy';im.src=i.logo;im.alt='';c.appendChild(im)}c.appendChild(h('span','',i.name));
  c.onclick=()=>{ovClose('#gd');playLiveFrom(i,list)};r.appendChild(c);
  const pn=h('div','gdp');pn.style.width=W;if(now>0&&now<SPAN*PPM){const ln=h('i','gdn');ln.style.left=now+'rem';pn.appendChild(ln)}r._p=pn;r.appendChild(pn);wrap.appendChild(r);
  if(obs)obs.observe(r);else epgLazy(r,i,L=>fill(pn,L,i))});
 setTimeout(()=>{try{p.querySelector('.f').focus()}catch(e){}},50)}
/* el botón "Guía" aparece junto al orden, solo en TV en vivo */
(function(){const sb=$('#sortb');if(!sb)return;const b=h('button','f sm hidden','Guía');b.id='gdb';b.onclick=()=>openGuide();sb.parentNode.insertBefore(b,sb);
 const u0=updBt;updBt=function(){u0();b.classList.toggle('hidden',S.mode!=='live'||S.cat==='__home'||S.cat==='__hist')}})();

/* ---------- Primer uso ---------- */
function showOnb(){
 let first=false;try{first=!localStorage.getItem('ep_onb')&&!localStorage.getItem(KEY)&&!(ACCTS&&ACCTS.length)}catch(e){}
 if(!first||$('#login').classList.contains('hidden'))return;
 const S3=[['link','Agrega tu lista','Entra con tu cuenta Xtream Codes o con el enlace de una lista M3U. E-Player no incluye contenido: usa solo lo que tú agregas.'],
  ['audio','Idioma y subtítulos','En películas y series toca «Audio» y «Subtítulos». La app recuerda tu elección para lo siguiente que veas.'],
  ['expand','Control a tu gusto','Desliza para cambiar brillo y volumen, toca dos veces para saltar 10 s y usa PiP para seguir viendo mientras haces otra cosa.']];
 const o=h('div','onb');o.id='ob';let k=0;document.body.appendChild(o);
 const done=()=>{try{localStorage.setItem('ep_onb','1')}catch(e){}o.remove();try{$('#host').focus()}catch(e){}};
 const draw=()=>{o.textContent='';const s=S3[k],ico=h('div','onbi');ico.innerHTML=ic(s[0]);o.appendChild(ico);o.appendChild(h('h2','',s[1]));o.appendChild(h('p','dm',s[2]));
  const dots=h('div','onbd');S3.forEach((x,j)=>dots.appendChild(h('span',j===k?'on':'')));o.appendChild(dots);
  const a=h('div','acts');o.appendChild(a);if(k<S3.length-1){btn(a,'Siguiente',()=>{k++;draw()},'main','right');btn(a,'Saltar',done)}else btn(a,'Empezar',done,'main','check');
  setTimeout(()=>{try{o.querySelector('.f').focus()}catch(e){}},30)};
 draw()}

/* ---------- Comentarios y calificación ---------- */
function sendFeedback(){let d='';try{d=AndroidApp.deviceInfo()}catch(e){}
 mailTo('Comentarios sobre E-Player','\n\n—\nVersión: '+(APPV||VER)+(d?'\n'+d:'')+'\n(Puedes borrar estas líneas)')}
function maybeReview(){try{
 if(!(window.AndroidApp&&AndroidApp.askReview))return;
 const L=localStorage,w=+L.getItem('ep_w')||0,t0=+L.getItem('ep_t0')||Date.now(),last=+L.getItem('ep_rv')||0;
 if(w>=5&&Date.now()-t0>3*864e5&&Date.now()-last>60*864e5){L.setItem('ep_rv',String(Date.now()));AndroidApp.askReview()}}catch(e){}}
const countWatch=js=>{try{let o={};try{o=JSON.parse(js||'{}')}catch(e){}const n=Object.keys(o).filter(k=>o[k]&&(+o[k].e||+o[k].p>=300)).length;if(n){localStorage.setItem('ep_w',String((+localStorage.getItem('ep_w')||0)+n));setTimeout(maybeReview,2500)}}catch(e){}};
try{if(!localStorage.getItem('ep_t0'))localStorage.setItem('ep_t0',String(Date.now()))}catch(e){}

/* ---------- Atajos del ícono (mantener pulsado) ---------- */
window.goDest=d=>{let n=0;const iv=setInterval(()=>{if(!$('#app').classList.contains('hidden')){clearInterval(iv);try{showPage(d==='tv'?'live':d,{focus:false})}catch(e){}}else if(++n>40)clearInterval(iv)},500)};
/* sincroniza los ajustes del reproductor nativo */
setTimeout(()=>{try{if(hasNP()){npPref('buf',CFG.buf?'l':'n');npPref('night',CFG.night?'1':'0')}}catch(e){}},1500);
setTimeout(showOnb,250);
