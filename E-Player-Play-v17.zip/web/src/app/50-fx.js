/* ===== v6.5 — FX: dock con lente, losas 3D con inclinación, transición de pantallas en 3D (GSAP opcional) ===== */
(function(){
var G=window.gsap,doc=document.documentElement,UA=navigator.userAgent,
 RM=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches,
 LITE=/\b(TV|AFT[A-Z]*|BRAVIA|SmartTV|Tizen|Web0S|webOS|Fire)\b/i.test(UA)||(navigator.hardwareConcurrency||4)<=2,
 ORDER=['home','live','movie','series','favs','profile'],
 COL={home:'#6f86ff',live:'#19c9b4',movie:'#ff5a6e',series:'#8a5cff',favs:'#ffb84d',profile:'#8fa3c2'};
doc.classList.add('fx');if(G)doc.classList.add('fx-g');if(LITE)doc.classList.add('fx-lite');
var FX=window.FX={origin:null,until:0},pg=document.getElementById('pg'),amb,sweep;
const sec=p=>document.getElementById('p-'+(p==='live'||p==='movie'||p==='series'?'browse':p));
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));

/* ambiente + haz de luz */
amb=document.createElement('div');amb.id='fxAmb';ORDER.forEach(p=>{const i=document.createElement('i');i.setAttribute('data-p',p);amb.appendChild(i)});
document.body.insertBefore(amb,document.body.firstChild);
sweep=document.createElement('div');sweep.style.cssText='position:absolute;top:0;bottom:0;left:0;width:26%;opacity:0;pointer-events:none;z-index:5;transform:skewX(-14deg)';
pg.appendChild(sweep);

/* lente deslizante del dock */
function lens(dock,anim){
 if(!dock||!dock.offsetWidth)return;
 let l=dock._lens;if(!l||l.parentNode!==dock){l=dock._lens=document.createElement('i');l.className='fx-lens';dock.insertBefore(l,dock.firstChild)}
 const on=dock.querySelector('button.on'),row=getComputedStyle(dock).flexDirection!=='column';
 if(!on||!row){dock.classList.remove('lensed');l.style.display='none';return}
 dock.classList.add('lensed');l.style.display='block';
 const x=on.offsetLeft,w=on.offsetWidth;
 if(G){if(anim&&!RM)G.to(l,{x:x,width:w,duration:.75,ease:'back.out(1.6)',overwrite:true});else G.set(l,{x:x,width:w})}
 else{l.style.transform='translateX('+x+'px)';l.style.width=w+'px'}}
FX.mark=function(p){
 [].forEach.call(amb.children,i=>i.classList.toggle('on',i.getAttribute('data-p')===p));
 doc.style.setProperty('--tint',COL[p]||COL.home);
 [document.getElementById('nav'),document.getElementById('bn')].forEach(d=>lens(d,true));
 setTimeout(()=>{[document.getElementById('nav'),document.getElementById('bn')].forEach(d=>lens(d,false))},400)};
window.addEventListener('resize',()=>{[document.getElementById('nav'),document.getElementById('bn')].forEach(d=>lens(d,false))});

/* botones del dock: inclinación hacia el puntero y elevación con el foco del mando */
function dockFx(dock){
 if(!G||!dock||dock._fx)return;dock._fx=1;
 const rst=()=>G.to(dock.querySelectorAll('button'),{rotationX:0,rotationY:0,z:0,duration:.7,ease:'elastic.out(1,.6)',overwrite:'auto'});
 dock.addEventListener('pointermove',e=>{if(e.pointerType==='touch')return;
  [].forEach.call(dock.querySelectorAll('button'),b=>{const r=b.getBoundingClientRect(),
   dx=clamp((e.clientX-(r.left+r.width/2))/(r.width*1.1),-1,1),dy=clamp((e.clientY-(r.top+r.height/2))/(r.height*1.1),-1,1),near=1-Math.min(1,Math.sqrt(dx*dx+dy*dy));
   G.to(b,{rotationY:dx*20,rotationX:-dy*20,z:near*20,duration:.35,ease:'power2.out',overwrite:'auto',transformPerspective:600})})});
 dock.addEventListener('pointerleave',rst);
 dock.addEventListener('focusin',e=>{const b=e.target.closest&&e.target.closest('button');if(b&&!TOUCH)G.to(b,{z:30,rotationX:-10,duration:.45,ease:'back.out(2)',overwrite:'auto',transformPerspective:600})});
 dock.addEventListener('focusout',rst)}
FX.dock=function(){dockFx(document.getElementById('nav'));dockFx(document.getElementById('bn'))};

/* inclinación 3D con brillo especular (losas y tarjetas del Inicio) */
function tilt(el,tg,max,lift){
 if(!G||el._tl)return;el._tl=1;const face=el.querySelector('.tl-face')||el,P={transformPerspective:900,overwrite:'auto'};
 const lv=()=>G.to(tg,Object.assign({rotationY:0,rotationX:0,z:0,scale:1,duration:.9,ease:'elastic.out(1,.55)'},P));
 el.addEventListener('pointermove',e=>{if(e.pointerType==='touch')return;const r=el.getBoundingClientRect(),nx=(e.clientX-r.left)/r.width-.5,ny=(e.clientY-r.top)/r.height-.5;
  G.to(tg,Object.assign({rotationY:nx*max*2,rotationX:-ny*max*2,z:lift,duration:.45,ease:'power3.out'},P));
  face.style.setProperty('--mx',(nx+.5)*100+'%');face.style.setProperty('--my',(ny+.5)*100+'%')});
 el.addEventListener('pointerleave',lv);
 el.addEventListener('pointerdown',()=>G.to(tg,Object.assign({z:-12,scale:.97,duration:.15},P)));
 el.addEventListener('pointerup',()=>G.to(tg,Object.assign({z:lift,scale:1,duration:.4,ease:'back.out(2)'},P)));
 const pose=()=>{if(document.activeElement!==el||TOUCH)return;face.style.setProperty('--mx','30%');face.style.setProperty('--my','15%');
  G.to(tg,Object.assign({z:lift+16,rotationX:-5,rotationY:-7,duration:.6,ease:'back.out(1.8)'},P))};
 el.addEventListener('focus',()=>{const w=FX.until-Date.now();if(w>0)G.delayedCall(w/1000,pose);else pose()});
 el.addEventListener('blur',lv)}
FX.bind=function(root){
 if(!G||!root)return;
 [].forEach.call(root.querySelectorAll('.tile'),t=>tilt(t,t.querySelector('.tl-body'),9,22));
 [].forEach.call(root.querySelectorAll('.rcard,.acard'),c=>tilt(c,c,3,8))};
FX.dive=function(el){const r=el.getBoundingClientRect(),p=pg.getBoundingClientRect();FX.origin={x:r.left+r.width/2-p.left,y:r.top+r.height/2-p.top}};

/* transición entre pantallas: la saliente es una «foto» que se aleja; la entrante gira desde profundidad */
function scrub(n){
 [].forEach.call(n.querySelectorAll('[id]'),e=>e.removeAttribute('id'));
 [].forEach.call(n.querySelectorAll('.f'),e=>e.classList.remove('f'));
 [].forEach.call(n.querySelectorAll('[tabindex],button,input'),e=>{e.setAttribute('tabindex','-1')});
 n.removeAttribute('id');n.setAttribute('aria-hidden','true');n.className='page fx-ghost'}
FX.before=function(prev,next){
 const org=FX.origin;FX.origin=null;
 if(!G||RM||prev===next||document.getElementById('app').classList.contains('hidden'))return null;
 const from=sec(prev);if(!from||from.classList.contains('hidden'))return null;
 const gh=from.cloneNode(true);scrub(gh);pg.appendChild(gh);
 const dir=(ORDER.indexOf(next)>ORDER.indexOf(prev))?1:-1,dive=!!org&&prev==='home',T=.6;
 FX.until=Date.now()+1400;
 if(dive)G.fromTo(gh,{transformOrigin:org.x+'px '+org.y+'px',scale:1,opacity:1},{scale:1.3,opacity:0,duration:T,ease:'power3.in',onComplete:()=>gh.remove()});
 else G.fromTo(gh,{transformOrigin:dir>0?'0% 50%':'100% 50%',transformPerspective:1500,rotationY:0,xPercent:0,z:0,opacity:1},
  {rotationY:-dir*34,xPercent:-dir*6,z:-240,opacity:0,duration:T,ease:'power3.in',onComplete:()=>gh.remove()});
 return{next:next,dir:dir,dive:dive,org:org}};
FX.after=function(c){
 const to=sec(c.next),clean=()=>{pg.scrollLeft=0;pg.scrollTop=0};
 if(c.dive)G.fromTo(to,{transformOrigin:c.org.x+'px '+c.org.y+'px',scale:.8,z:-300,opacity:0},{scale:1,z:0,opacity:1,duration:.95,delay:.2,ease:'expo.out',clearProps:'transform,opacity,transformOrigin',onComplete:clean});
 else G.fromTo(to,{transformOrigin:c.dir>0?'100% 50%':'0% 50%',transformPerspective:1500,rotationY:c.dir*38,xPercent:c.dir*7,z:-260,opacity:0},
  {rotationY:0,xPercent:0,z:0,opacity:1,duration:1,delay:.14,ease:'expo.out',clearProps:'transform,opacity,transformOrigin',onComplete:clean});
 const tl=to.querySelectorAll('.tile .tl-body');
 if(tl.length)G.fromTo(tl,{rotationX:-72,y:70,opacity:0,transformOrigin:'50% 100%',transformPerspective:900},{rotationX:0,y:0,opacity:1,duration:.9,stagger:.1,delay:.4,ease:'back.out(1.5)',clearProps:'transform,opacity,transformOrigin'});
 const col=COL[c.next]||'#fff';
 sweep.style.background='linear-gradient(90deg,transparent,'+col+',transparent)';sweep.style.mixBlendMode='screen';
 G.fromTo(sweep,{xPercent:-130,opacity:.34},{xPercent:430,duration:.95,ease:'power2.inOut',onComplete:()=>{sweep.style.opacity=0}})};
FX.dock();
})();
