/* ===== ElohimVIP — funciones extra (hoy libres durante las pruebas) + Compartir y Buscar actualización (gratis) =====
   Interruptor único: VIP.free. Cuando llegue el cobro con Google Play Billing, basta poner VIP.free=false y VIP.paid=<compra>. */
const VIP={free:true,paid:false,on:function(){return this.free||!!this.paid}};
const LATER=lsGet('iptv_later',{}),STATS=lsGet('iptv_stats',{d:{},t:{},c:{}}),QUICK=lsGet('iptv_quick',{});
const PLAY_URL='https://play.google.com/store/apps/details?id=com.elohim.eplayer',LET=['A','B','C'];
const E_=encodeURIComponent;

/* ---------- Temas ---------- */
const THEMES=[
 {id:'def',n:'E-Player',a:'#3fe0c5',b:'#4a86ff',t:'#3a5bff',bg:'#070a11',bg2:'#0c1220'},
 {id:'oro',n:'Oro',a:'#e9c46a',b:'#f4a261',t:'#c8923a',bg:'#0b0906',bg2:'#14100a'},
 {id:'esm',n:'Esmeralda',a:'#34d399',b:'#10b981',t:'#12a36f',bg:'#06100c',bg2:'#0a1812'},
 {id:'rub',n:'Rubí',a:'#ff6b81',b:'#ff8a5b',t:'#e0405a',bg:'#12070a',bg2:'#1c0c11'},
 {id:'ama',n:'Amatista',a:'#b794f6',b:'#7c6cf2',t:'#8a5cf0',bg:'#0b0714',bg2:'#130c20'},
 {id:'oce',n:'Océano',a:'#38bdf8',b:'#2dd4bf',t:'#1d8fd1',bg:'#050d14',bg2:'#09161f'}];
function applyTheme(id){const t=THEMES.filter(x=>x.id===id)[0]||THEMES[0],s=document.documentElement.style;
 s.setProperty('--a',t.a);s.setProperty('--a2',t.b);s.setProperty('--tint',t.t);s.setProperty('--bg',t.bg);s.setProperty('--bg2',t.bg2);
 try{document.body.style.background=''}catch(e){}}

/* ---------- Vencimientos ---------- */
const dleft=exp=>exp?Math.ceil((exp*1000-Date.now())/864e5):null;
const dlvl=d=>d===null?'':d<=7?'bad':d<=30?'warn':'ok';
function xtCfg(a){const c=a.cfg||{};if(c.t==='X'&&c.host&&c.user)return{host:normalizeHost(c.host),user:c.user.trim(),pass:c.pass};
 if(c.t==='M'){const x=parseXtreamUrl(c.url||'');if(x)return{host:x.host,user:x.user,pass:x.pass}}return null}
async function refreshAccts(){
 await Promise.all(ACCTS.map(a=>{const x=xtCfg(a);if(!x)return 0;a.err=0;
  return tmo(jget(x.host+'/player_api.php?username='+E_(x.user)+'&password='+E_(x.pass)),9000).then(info=>{const u=info&&info.user_info;
   if(u){a.exp=+u.exp_date||0;a.st=u.status||'';a.mc=+u.max_connections||0;a.ac=+u.active_cons||0;a.chk=Date.now()}else a.err=1}).catch(()=>{a.err=1})}));
 lsSet('iptv_accts',ACCTS)}
const expiring=()=>ACCTS.filter(a=>{const d=dleft(a.exp);return d!==null&&d<=7}).length;

/* ---------- Lista combinada ---------- */
const VIPX={max:()=>isLite()?2:3};
VIPX.badge=k=>{const b=h('i','sb s'+k,LET[k]||'?');const p=S.combo&&S.combo[k];if(p)b.title=p.name;return b};
VIPX.combine=async function(cfgs,force){
 cfgs=cfgs.slice(0,VIPX.max());
 const res=await Promise.all(cfgs.map(c=>loadAny(c,force).then(d=>({ok:1,c:c,d:d}),e=>({ok:0,c:c,e:e}))));
 const ok=res.filter(r=>r.ok);if(!ok.length)throw Error(res[0].e.message||'No se pudo cargar ninguna cuenta');
 const d={live:[],movie:[],series:[],catOrder:{live:[],movie:[],series:[]},epg:'',skipped:0},xts=[],parts=[];
 res.forEach((r,k)=>{const nm=acctName(r.c);
  if(!r.ok){xts[k]=null;parts.push({cfg:r.c,name:nm,error:r.e.message||'Error'});return}
  xts[k]=r.d.xt||null;const ep=r.d.epg||'';
  ['live','movie','series'].forEach(m=>{r.d[m].forEach(i=>{i.src=k;if(!r.d.xt&&ep)i.eu=ep;d[m].push(i)});
   const o=r.d.catOrder&&r.d.catOrder[m];if(o&&o.length)o.forEach(n=>{if(d.catOrder[m].indexOf(n)<0)d.catOrder[m].push(n)})});
  d.skipped+=r.d.skipped||0;if(!d.epg&&ep)d.epg=ep;
  parts.push({cfg:r.c,name:nm,acct:r.d.acct,counts:r.d.acct.counts})});
 ['live','movie','series'].forEach(m=>{if(!d.catOrder[m].length)delete d.catOrder[m]});
 const first=ok[0];
 S.xts=xts;S.xt=first.d.xt||null;S.combo=parts;S.srcF=null;S.fromCache=ok.map(r=>r.d.from||0).reduce((a,b)=>a&&b?Math.min(a,b):0,ok[0].d.from||0);
 S.acct={type:'M',url:'combinada',combined:true,epg:d.epg,skipped:d.skipped,parts:parts,counts:{live:d.live.length,movie:d.movie.length,series:d.series.length}};
 const bad=parts.filter(p=>p.error);if(bad.length)setTimeout(()=>toast('⚠ '+bad.length+' cuenta(s) no cargaron: '+bad.map(p=>p.name).join(', '),8000),1200);
 return d};
VIPX.srcBtn=function(){const b=$('#srcb');if(!b)return;const on=!!S.combo&&VIP.on();b.classList.toggle('hidden',!on);if(!on)return;
 setIc(b,'users',S.srcF==null?'Todas':'Solo '+LET[S.srcF]);b.setAttribute('aria-label','Filtrar por cuenta')};
$('#srcb').onclick=function(){if(!S.combo)return;const ks=S.combo.map((p,k)=>p.error?-1:k).filter(k=>k>=0);const at=ks.indexOf(S.srcF);
 S.srcF=at<0?ks[0]:at+1<ks.length?ks[at+1]:null;refreshBrowse()};


VIPX.partDays=function(p){const u=p.acct&&p.acct.info&&p.acct.info.user_info;if(!u)return{u:null,d:null};const e=+u.exp_date;return{u:u,e:e,d:e?dleft(e):null}};
VIPX.dtxt=function(x){return x.d===null?'Sin vencimiento':x.d<0?'Vencida':x.d===0?'Vence hoy':'Quedan '+x.d+(x.d===1?' día':' días')};
VIPX.describeCombo=function(a){const rows=[],warns=[];(a.parts||[]).forEach(function(p,k){const L='Cuenta '+LET[k]+' · '+p.name;
 if(p.error){rows.push([L,'Error: '+p.error]);warns.push(L+' no cargó');return}
 const x=VIPX.partDays(p);rows.push([L,x.u?VIPX.dtxt(x)+(x.e?' (vence el '+fmtDay(x.e*1000)+')':''):'Lista M3U (sin datos de vencimiento)']);
 if(x.d!==null&&x.d<=7)warns.push(L+(x.d<0?' está vencida':' vence en '+x.d+(x.d===1?' día':' días')))});return{rows:rows,warns:warns}};
VIPX.comboCard=function(){const a=S.acct,c=h('div','acard f vcc');c.tabIndex=0;const top=h('div','at');top.appendChild(h('b','','Lista combinada'));top.appendChild(h('span','pill ok',a.parts.length+' cuentas'));c.appendChild(top);
 a.parts.forEach(function(p,k){const r=h('div','vcl');r.appendChild(VIPX.badge(k));r.appendChild(h('span','vcn',p.name));
  if(p.error)r.appendChild(h('em','vtag bad','Error'));else{const x=VIPX.partDays(p);const e=h('em','vdy lv-'+(x.u?(dlvl(x.d)||'ok'):'ok'),x.u?VIPX.dtxt(x):'M3U');r.appendChild(e)}c.appendChild(r)});
 const ct=a.counts||{};c.appendChild(h('p','dm',fmtN(ct.live||0)+' canales · '+fmtN(ct.movie||0)+' películas · '+fmtN(ct.series||0)+' series'));
 c.onclick=function(){showPage('profile',{focus:true})};return c};

/* ---------- Ver más tarde ---------- */
VIPX.laterItems=function(){const o=[];['movie','series'].forEach(m=>S.data[m].forEach(i=>{if(LATER[fk(i)]&&!hidden(i))o.push(i)}));
 return o.sort((a,b)=>LATER[fk(b)]-LATER[fk(a)])};
VIPX.laterBtn=function(acts,i){if(!VIP.on())return;const k=fk(i),t=()=>LATER[k]?'En «Ver más tarde»':'Ver más tarde';
 const b=btn(acts,t(),()=>{if(LATER[k])delete LATER[k];else LATER[k]=Date.now();lsSet('iptv_later',LATER);setIc(b,LATER[k]?'check':'hist',t())},'','hist');setIc(b,LATER[k]?'check':'hist',t())};

/* ---------- Compartir y actualizar (gratis) ---------- */
const APPLINK=()=>window.AndroidApp?PLAY_URL:(location.protocol==='file:'?PLAY_URL:location.origin+location.pathname);
function copyText(t){try{if(navigator.clipboard&&navigator.clipboard.writeText)return navigator.clipboard.writeText(t).then(()=>true,()=>false)}catch(e){}
 return new Promise(res=>{try{const a=document.createElement('textarea');a.value=t;a.style.cssText='position:fixed;left:-999px';document.body.appendChild(a);a.select();const ok=document.execCommand('copy');a.remove();res(!!ok)}catch(e){res(false)}})}
VIPX.share=function(){const txt='Te recomiendo E-Player: reproductor para tus listas IPTV (Xtream Codes y M3U), rápido y pensado para el control remoto. '+APPLINK();
 try{if(window.AndroidApp&&typeof AndroidApp.shareText==='function'){AndroidApp.shareText(txt);return}}catch(e){}
 if(navigator.share){navigator.share({title:'E-Player',text:txt}).catch(()=>{});return}
 copyText(txt).then(ok=>toast(ok?'Enlace copiado: pégalo en WhatsApp o donde quieras':'Copia este enlace: '+APPLINK(),5000))};
window.__updRes=function(k){toast(k==='none'?'Ya tienes la última versión ✓':k==='avail'?'Hay una versión nueva: se descargará en segundo plano':k==='ready'?'Actualización lista: reinicia la app para instalarla':'No se pudo comprobar. Revisa tu internet y que la app venga de Google Play',5000)};
VIPX.update=function(){toast('Buscando actualización…',3000);
 try{if(window.AndroidApp&&typeof AndroidApp.checkUpdateNow==='function'){AndroidApp.checkUpdateNow();return}}catch(e){}
 if('serviceWorker' in navigator){navigator.serviceWorker.getRegistration().then(r=>{if(r)return r.update().then(()=>toast('Revisado. Si hay una versión nueva, se aplica al reabrir la app.',4500));toast('Esta versión web siempre carga lo último al recargar la página.',4500)}).catch(()=>toast('No se pudo comprobar',3000));return}
 toast('Esta versión web siempre carga lo último al recargar la página.',4500)};

/* ---------- Estadísticas de uso (solo en el dispositivo) ---------- */
const dkey=t=>{const d=new Date(t||Date.now());return d.getFullYear()+'-'+('0'+(d.getMonth()+1)).slice(-2)+'-'+('0'+d.getDate()).slice(-2)};
function topN(o,n){return Object.keys(o).map(k=>[k,o[k]]).sort((a,b)=>b[1]-a[1]).slice(0,n)}
setInterval(()=>{try{const v=$('#v'),pl=$('#pl');if(!v||pl.classList.contains('hidden')||v.paused||v.ended||v.readyState<3)return;
 const k=dkey(),T=10;STATS.d[k]=STATS.d[k]||{l:0,v:0};STATS.d[k][S.live?'l':'v']+=T;
 const nm=(S.title||'').slice(0,60),ct=(S.cur&&S.cur.cat||'').slice(0,40);
 if(nm){STATS.t[nm]=(STATS.t[nm]||0)+T;if(Object.keys(STATS.t).length>80){topN(STATS.t,40).forEach(()=>0);const keep={};topN(STATS.t,50).forEach(x=>keep[x[0]]=x[1]);STATS.t=keep}}
 if(ct)STATS.c[ct]=(STATS.c[ct]||0)+T;
 const ks=Object.keys(STATS.d).sort();while(ks.length>45)delete STATS.d[ks.shift()];
 lsSet('iptv_stats',STATS)}catch(e){}},10000);

/* ---------- Canales rápidos: mantener pulsado 1-9 en el reproductor ---------- */
const kdt={},kdn={};
function quickAct(d){clearTimeout(numT);numS='';$('#nm').classList.add('hidden');const q=QUICK[d];
 if(q){const it=idx('live')[q.url]||{name:q.name,logo:q.logo,cat:'Rápidos',type:'live',url:q.url,src:q.src};S.zl=S.zl&&S.zl.length?S.zl:[it];playLiveFrom(it);toast('Canal rápido '+d+': '+q.name,2200);return}
 if(S.cur&&S.cur.type==='live'){QUICK[d]={url:S.cur.url,name:S.cur.name,logo:S.cur.logo||'',src:S.cur.src};lsSet('iptv_quick',QUICK);toast('Canal rápido '+d+' guardado: '+S.cur.name,3500)}}
window.addEventListener('keydown',e=>{if(!VIP.on())return;const k=e.keyCode,d=(k>=49&&k<=57)?k-48:(k>=97&&k<=105)?k-96:0;if(!d)return;
 if(!playerFull()||!S.live||e.target.tagName==='INPUT')return;
 if(!e.repeat){kdt[k]=Date.now();kdn[k]=0;return}
 e.stopImmediatePropagation();e.preventDefault();if(kdn[k])return;
 if(Date.now()-(kdt[k]||0)>=700){kdn[k]=1;quickAct(d)}},true);

/* ---------- Selector de canal (rápidos y multivista) ---------- */
function pickLive(cb,title){
 const p=ovOpen('#vk'),hd=h('div','mvph');hd.appendChild(h('h2','',title||'Elige un canal'));btn(hd,'Cerrar',()=>ovClose('#vk'),'sm','close');p.appendChild(hd);
 const inp=document.createElement('input');inp.className='vin f';inp.type='search';inp.placeholder='Buscar canal…';p.appendChild(inp);
 const out=h('div','vres');p.appendChild(out);
 const base=()=>{const a=[],seen={};favItems('live').concat(histItems('live')).forEach(i=>{if(!seen[i.url]){seen[i.url]=1;a.push(i)}});
  S.data.live.forEach(i=>{if(a.length<60&&!seen[i.url]&&!hidden(i)){seen[i.url]=1;a.push(i)}});return a};
 const run=()=>{out.textContent='';const q=searchNorm(inp.value.trim());let a;
  if(!q)a=base();else{a=[];const L=S.data.live;for(let k=0;k<L.length&&a.length<80;k++){const x=L[k];if(!hidden(x)&&(x._n||(x._n=searchNorm(x.name))).indexOf(q)>=0)a.push(x)}}
  if(!a.length)out.appendChild(h('p','vd','Sin resultados.'));
  a.forEach(i=>{const r=h('div','vsr f');r.tabIndex=0;r.appendChild(h('b','',i.name));r.appendChild(h('span','dm',i.cat||''));if(S.combo&&i.src!=null)r.appendChild(VIPX.badge(i.src));
   r.onclick=()=>{ovClose('#vk');cb(i)};out.appendChild(r)})};
 let t=0;inp.oninput=()=>{clearTimeout(t);t=setTimeout(run,160)};run();setTimeout(()=>{try{inp.focus()}catch(e){}},60)}

/* ---------- Multivista: 1 principal + 2 secundarias, la principal se gira a gusto ---------- */
const MV={slots:[],el:null};
function mvStop(s){clearTimeout(s.st);try{if(s.hls){s.hls.destroy()}}catch(e){}try{if(s.mp){s.mp.destroy()}}catch(e){}s.hls=s.mp=null;
 const v=s.v;v.onerror=v.onplaying=v.onwaiting=null;try{v.pause();v.removeAttribute('src');v.load()}catch(e){}}
function mvPlay(s,item){mvStop(s);s.item=item;s.el.classList.remove('empty','err');s.el.classList.add('load');s.nm.textContent=item.name;
 s.bd.textContent='';if(S.combo&&item.src!=null)s.bd.appendChild(VIPX.badge(item.src));
 const v=s.v,url=liveUrl(item.url),isH=/\.m3u8(\?|$)|[?&]type=m3u8/i.test(url),isTS=!isH&&(/\.ts(\?|$)/i.test(url)||/\/live\/[^\/]+\/[^\/]+\/\d+(\?|$)/.test(url)),
  hj=!!window.Hls&&Hls.isSupported(),mj=!!window.mpegts&&mpegts.isSupported(),nat=v.canPlayType('application/vnd.apple.mpegurl')!=='',c=[];
 if(isH){if(hj)c.push('h');if(nat)c.push('n');if(/\/live\//.test(url)&&mj)c.push('t')}else if(isTS){if(mj)c.push('m');c.push('n')}else{if(mj)c.push('m');c.push('n');if(hj)c.push('h')}
 let i=0;const next=()=>{clearTimeout(s.st);
  if(i>=c.length){s.el.classList.remove('load');s.el.classList.add('err');return}
  const m=c[i++];try{if(s.hls)s.hls.destroy()}catch(e){}try{if(s.mp)s.mp.destroy()}catch(e){}s.hls=s.mp=null;
  s.st=setTimeout(next,16000);v.onerror=next;
  if(m==='h'){s.hls=new Hls({maxBufferLength:12,capLevelToPlayerSize:true,startLevel:0,fragLoadingMaxRetry:3,manifestLoadingMaxRetry:2,xhrSetup:PROXY?(x,u)=>x.open('GET',PX(u),true):undefined});
   s.hls.on(Hls.Events.ERROR,(e,d)=>{if(d.fatal)next()});s.hls.loadSource(url);s.hls.attachMedia(v)}
  else if(m==='m'||m==='t'){const u2=m==='t'?url.replace(/\.m3u8(\?.*)?$/i,'.ts'):url;
   s.mp=mpegts.createPlayer({type:'mpegts',isLive:true,url:PROXY?PX(u2):u2},{enableWorker:false,liveBufferLatencyChasing:true});
   s.mp.on(mpegts.Events.ERROR,next);s.mp.attachMediaElement(v);s.mp.load()}
  else v.src=mx(url);
  const p=v.play();if(p&&p.catch)p.catch(()=>{if(!v.muted){v.muted=true;const q=v.play();q&&q.catch&&q.catch(()=>{})}})};
 v.onplaying=()=>{clearTimeout(s.st);s.el.classList.remove('load','err')};
 mvAudio();next();mvCheck()}
function mvAudio(){MV.slots.forEach(s=>{s.v.muted=s.pos!==0})}
function mvPos(){MV.slots.forEach(s=>{s.el.setAttribute('data-p',String(s.pos))});mvAudio()}
function mvMain(s){if(s.pos===0)return;const m=MV.slots.filter(x=>x.pos===0)[0];if(m){m.pos=s.pos}s.pos=0;mvPos();try{s.el.focus()}catch(e){}}
function mvRotate(){const n=MV.slots.length;MV.slots.forEach(s=>{s.pos=(s.pos+1)%n});mvPos()}
function mvCheck(){const cnt={};MV.slots.forEach(s=>{if(s.item){const k=s.item.src!=null?s.item.src:-1;cnt[k]=(cnt[k]||0)+1}});
 Object.keys(cnt).forEach(k=>{const a=k<0?S.acct:(S.combo&&S.combo[k]&&S.combo[k].acct),u=a&&a.info&&a.info.user_info,mc=u?+u.max_connections:0;
  if(mc>0&&cnt[k]>mc)toast('⚠ '+(k<0?'Tu cuenta':'La cuenta '+LET[k])+' permite '+mc+' conexión(es) a la vez: algunas pantallas pueden fallar.',7000)})}
MV.close=function(){MV.slots.forEach(mvStop);MV.slots=[]};
MV.open=function(){if(!VIP.on())return;
 if(!$('#pl').classList.contains('hidden'))stop();
 if(!S.data.live.length){toast('Esta cuenta no tiene canales en vivo');return}
 const n=isLite()?2:3,p=ovOpen('#vm',MV.close);p.classList.add('mv');
 const top=h('div','mvtop');top.appendChild(h('b','','Multivista'));top.appendChild(h('span','dm mvh','Toca una pantalla pequeña para hacerla principal'));top.appendChild(h('span','sp'));
 btn(top,'Girar',mvRotate,'sm','refresh');btn(top,'Cerrar',()=>ovClose('#vm'),'sm','close');p.appendChild(top);
 const g=h('div','mvgrid n'+n);p.appendChild(g);MV.slots=[];
 for(let k=0;k<n;k++){const el=h('div','mvs f empty');el.tabIndex=0;const v=document.createElement('video');v.setAttribute('playsinline','');v.muted=true;v.autoplay=true;el.appendChild(v);
  const ph=h('div','mvph2');ph.appendChild(h('b','',k===0?'Pantalla principal':'Pantalla '+(k+1)));ph.appendChild(h('small','','Toca para elegir un canal'));el.appendChild(ph);
  el.appendChild(h('i','mvsp'));const lb=h('div','mvl'),nm=h('b',''),bd=h('span','');lb.appendChild(nm);lb.appendChild(bd);el.appendChild(lb);
  const s={el:el,v:v,nm:nm,bd:bd,pos:k,item:null};
  const ch=h('button','f sm mvc');ch.textContent='Canal';ch.onclick=ev=>{ev.stopPropagation();pickLive(it=>mvPlay(s,it),'Canal para la pantalla '+(s.pos===0?'principal':'secundaria'))};el.appendChild(ch);
  el.onclick=()=>{if(!s.item){pickLive(it=>mvPlay(s,it),'Elige un canal');return}if(s.pos!==0)mvMain(s)};
  g.appendChild(el);MV.slots.push(s)}
 mvPos();
 const first=(S.cur&&S.cur.type==='live')?S.cur:(favItems('live')[0]||S.data.live.filter(i=>!hidden(i))[0]);if(first)mvPlay(MV.slots[0],first);
 setTimeout(()=>{try{MV.slots[1].el.focus()}catch(e){}},80)};

/* ---------- Respaldo ---------- */
const BKEYS=['iptv_fav','iptv_hist','iptv_seen','iptv_last','iptv_later','iptv_quick','iptv_stats','iptv_set'];
function backupJson(withAccts){const d={};BKEYS.concat(withAccts?['iptv_accts']:[]).forEach(k=>{try{const v=localStorage.getItem(k);if(v!=null)d[k]=v}catch(e){}});
 return JSON.stringify({app:'eplayer',v:1,t:Date.now(),accts:!!withAccts,data:d})}
function restoreJson(t){let o;try{o=JSON.parse(t)}catch(e){throw Error('El texto no es un respaldo válido')}
 if(!o||o.app!=='eplayer'||!o.data)throw Error('Este archivo no es un respaldo de E-Player');
 Object.keys(o.data).forEach(k=>{if(BKEYS.concat(['iptv_accts']).indexOf(k)>=0&&typeof o.data[k]==='string'){try{localStorage.setItem(k,o.data[k])}catch(e){}}});return Object.keys(o.data).length}


/* ---------- Cambio automático de fuente: si un canal falla, prueba el mismo en otra cuenta o en otra calidad ---------- */
const normCh=n=>searchNorm(String(n||'').replace(/\([^)]*\)|\[[^\]]*\]/g,' ')).replace(/\b(hd|sd|fhd|uhd|4k|hevc|h265|h264|1080p?|720p?|480p?|50fps|60fps)\b/g,' ').replace(/[^a-z0-9]+/g,' ').trim();
VIPX.foOn=()=>CFG.fo!==0;
VIPX.failover=function(url){
 if(!VIP.on()||!VIPX.foOn()||!S.cur||S.cur.type!=='live'||!S.data)return false;
 const cur=S.cur;if(!S.fo||S.fo.base!==cur.url)S.fo={base:cur.url,tried:[cur.url]};
 if(S.fo.tried.indexOf(url)<0)S.fo.tried.push(url);
 const key=cur._c||(cur._c=normCh(cur.name));if(!key)return false;
 const alts=S.data.live.filter(i=>S.fo.tried.indexOf(i.url)<0&&!hidden(i)&&(i._c||(i._c=normCh(i.name)))===key);
 if(!alts.length)return false;
 alts.sort((a,b)=>(a.src!==cur.src?0:1)-(b.src!==cur.src?0:1));
 const a=alts[0];S.fo.tried.push(a.url);
 const other=S.combo&&a.src!=null&&a.src!==cur.src;
 toast('Ese canal falló: probando '+(other?'el mismo en la cuenta '+LET[a.src]:'otra versión del canal'),4500);
 play(a.url,cur.name+(other?' · cuenta '+LET[a.src]:' · versión alternativa'),true,S.master,S.meta,undefined,true,S.pv);return true};

/* ---------- Ecualizador (reproductor integrado y avanzado) ---------- */
const EQB=[60,230,910,3600,14000],EQP={plano:[0,0,0,0,0],voces:[-3,-1,4,3,-1],graves:[6,4,0,-1,-2],agudos:[-2,-1,0,4,6],cine:[4,2,-1,2,3],musica:[3,1,-1,2,4]},
 EQN={plano:'Plano',voces:'Voces claras',graves:'Más graves',agudos:'Más agudos',cine:'Cine',musica:'Música'};
const eqCfg=()=>CFG.eq=CFG.eq||{on:0,p:'plano',g:[0,0,0,0,0]};
let EQG=null;
VIPX.eqLive=()=>!!EQG;
VIPX.eqNative=function(){const c=eqCfg();try{if(window.AndroidApp&&AndroidApp.setPref)AndroidApp.setPref('eq',c.on?c.g.join(','):'')}catch(e){}};
VIPX.eqApply=function(quiet){const c=eqCfg();
 try{const v=$('#v');
  if(!EQG){if(!c.on)return true;
   if((v.currentSrc||'').indexOf('blob:')!==0){if(!quiet)toast('Aquí no hay un canal en vivo del reproductor integrado: el ecualizador se aplicará cuando veas uno y en el reproductor avanzado.',5500);return false}
   const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return false;
   const ctx=new AC(),src=ctx.createMediaElementSource(v),fl=EQB.map(f=>{const b=ctx.createBiquadFilter();b.type='peaking';b.frequency.value=f;b.Q.value=1.1;b.gain.value=0;return b});
   let n=src;fl.forEach(f=>{n.connect(f);n=f});n.connect(ctx.destination);EQG={ctx:ctx,fl:fl}}
  EQG.fl.forEach((f,k)=>{f.gain.value=c.on?(+c.g[k]||0):0});try{if(EQG.ctx.state==='suspended')EQG.ctx.resume()}catch(e){}
  return true}catch(e){return false}};

/* ---------- Subtítulos a medida ---------- */
const SUBC=[['Blanco','#ffffff'],['Amarillo','#ffe45c'],['Celeste','#7fe3ff'],['Verde','#8dff9b']],SUBB=['Sin fondo','Fondo suave','Fondo oscuro'],SUBE=['Sin borde','Sombra','Contorno'];
const SUBBG=['transparent','rgba(0,0,0,.55)','rgba(0,0,0,.9)'],SUBSH=['none','0 0 4px #000,1px 1px 3px #000','-1px -1px 0 #000,1px -1px 0 #000,-1px 1px 0 #000,1px 1px 0 #000'];
const subCfg=()=>CFG.sub=CFG.sub||{z:100,c:0,b:1,e:1};
VIPX.subApply=function(){const c=subCfg(),s=document.documentElement.style;
 s.setProperty('--subsz',(3.4*c.z/100).toFixed(2)+'vh');s.setProperty('--subcol',SUBC[c.c][1]);s.setProperty('--subbg',SUBBG[c.b]);s.setProperty('--subsh',SUBSH[c.e]);
 try{if(window.AndroidApp&&AndroidApp.setPref)AndroidApp.setPref('sub',c.z+','+c.c+','+c.b+','+c.e)}catch(e){}};

/* ---------- Avisos: recordatorios de programas y vencimiento de cuentas ---------- */
const REM=lsGet('iptv_rem',[]);
const natAl=()=>{try{return !!(window.AndroidApp&&typeof AndroidApp.scheduleAlert==='function')}catch(e){return false}};
function nSched(id,when,title,text){try{if(natAl()){if(AndroidApp.requestNotifPerm)AndroidApp.requestNotifPerm();AndroidApp.scheduleAlert(id,String(when),title,text)}}catch(e){}}
function nCancel(id){try{if(natAl())AndroidApp.cancelAlert(id)}catch(e){}}
function webPerm(){try{if(!natAl()&&window.Notification&&Notification.permission==='default')Notification.requestPermission()}catch(e){}}
const remId=(it,x)=>fk(it)+'|'+x.start;
VIPX.hasRem=(it,x)=>REM.some(r=>r.id===remId(it,x));
VIPX.remind=function(it,x){
 if(!VIP.on())return false;const id=remId(it,x),at=REM.map(r=>r.id).indexOf(id);
 if(at>=0){REM.splice(at,1);lsSet('iptv_rem',REM);nCancel('rem|'+id);toast('Recordatorio quitado',2500);return false}
 if(x.start<=Date.now()+60000){playLiveFrom(it);return false}
 REM.push({id:id,t:x.start,end:x.end,title:x.title||'Programa',ch:it.name,url:it.url,src:it.src,logo:it.logo||''});REM.sort((a,b)=>a.t-b.t);lsSet('iptv_rem',REM);
 nSched('rem|'+id,Math.max(Date.now()+5000,x.start-60000),'Empieza: '+(x.title||'tu programa'),it.name+' · '+hm(x.start));webPerm();
 toast('🔔 Te aviso: '+(x.title||'programa')+' · '+hm(x.start)+' en '+it.name,5000);return true};
VIPX.expAl=()=>CFG.expAl!==0;
VIPX.syncAlerts=function(){
 try{const now=Date.now();
  ACCTS.forEach(a=>{[3,1].forEach(d=>{const id='exp|'+a.id+'|'+d;nCancel(id);if(!VIP.on()||!VIPX.expAl()||!a.exp)return;
   const t=new Date(a.exp*1000-d*864e5);t.setHours(10,0,0,0);if(t.getTime()>now)nSched(id,t.getTime(),'Tu cuenta vence '+(d===1?'mañana':'en '+d+' días'),a.name+' · renueva con tu proveedor')})});
  for(let k=REM.length-1;k>=0;k--){const r=REM[k];if(r.t<now-3600000){REM.splice(k,1);continue}if(r.t>now)nSched('rem|'+r.id,Math.max(now+5000,r.t-60000),'Empieza: '+r.title,r.ch+' · '+hm(r.t))}
  lsSet('iptv_rem',REM)}catch(e){}};
VIPX.expToast=function(){try{const k=dkey();if(localStorage.getItem('iptv_exptoast')===k)return;
 const l=ACCTS.map(a=>({a:a,d:dleft(a.exp)})).filter(x=>x.d!==null&&x.d<=7);if(!l.length)return;localStorage.setItem('iptv_exptoast',k);
 const x=l.sort((p,q)=>p.d-q.d)[0];setTimeout(()=>toast('⚠ '+x.a.name+(x.d<0?' está vencida':x.d===0?' vence hoy':' vence en '+x.d+(x.d===1?' día':' días')),7000),2500)}catch(e){}};
/* sin app Android (web/PWA): aviso dentro de la página mientras esté abierta */
setInterval(()=>{try{const now=Date.now();for(let k=REM.length-1;k>=0;k--){const r=REM[k];if(r.t-60000>now)continue;
 if(!natAl()&&r.t>now-600000){const it=idx('live')[r.url]||{name:r.ch,url:r.url,type:'live',src:r.src,logo:r.logo};
  try{if(window.Notification&&Notification.permission==='granted')new Notification('Empieza: '+r.title,{body:r.ch+' · '+hm(r.t)})}catch(e){}
  let b=$('#remb');if(b)b.remove();b=h('div','remb');b.id='remb';b.appendChild(h('b','','🔔 '+r.title));b.appendChild(h('small','',r.ch+' · '+hm(r.t)));
  const go=h('button','f sm');go.textContent='Ver ahora';go.onclick=()=>{b.remove();playLiveFrom(it)};b.appendChild(go);const x=h('button','f sm');x.textContent='Cerrar';x.onclick=()=>b.remove();b.appendChild(x);document.body.appendChild(b);setTimeout(()=>{try{b.remove()}catch(e){}},30000)}
 if(r.t<now-60000)REM.splice(k,1)}lsSet('iptv_rem',REM)}catch(e){}},20000);

/* ---------- Enviar a otra pantalla ---------- */
VIPX.cast=function(){const u=S.url||S.master;if(!u){toast('Reproduce algo primero',2500);return}
 try{if(window.AndroidApp&&typeof AndroidApp.sendExternal==='function'){AndroidApp.sendExternal(u,S.title||'');return}}catch(e){}
 try{const v=$('#v');if(v.remote&&v.remote.prompt){v.remote.prompt().catch(()=>{});return}}catch(e){}
 copyText(u).then(ok=>toast(ok?'Enlace copiado: pégalo en VLC (Flujo de red) o en tu app para Chromecast':'Copia este enlace: '+u,6000))};

/* ---------- Novedades ---------- */
const NEWS=[{v:'6.10.0',t:'ElohimVIP completo y TV en vivo más fiable',i:['ElohimVIP: lista combinada, multivista de 3 pantallas, buscador global, vencimientos con alertas, cambio automático de fuente, ecualizador, subtítulos a medida, recordatorios de programas, canales rápidos, temas, «Ver más tarde», resumen y respaldo.','TV en vivo: más intentos antes de fallar, aprende qué método funciona en cada canal y te dice si el fallo es del proveedor o del reproductor.','Gratis para todos: Compartir E-Player y Buscar actualización en Perfil.','La app es solo horizontal.']}];
VIPX.newsAuto=function(){try{const cur=VER.replace('-pwa',''),seen=localStorage.getItem('iptv_seenver');localStorage.setItem('iptv_seenver',cur);
 if(!seen||seen===cur||!NEWS.some(n=>n.v===cur))return;setTimeout(()=>{if($('#vp').classList.contains('hidden')&&!$('#app').classList.contains('hidden'))vShow('news')},3500)}catch(e){}};

/* ---------- Interfaz ElohimVIP ---------- */
const VUI={view:'home',inc:false};
const CROWN='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 8l4.5 4L12 5l4.5 7L21 8l-1.8 10H4.8L3 8zm2 12h14v1.6H5z" fill="currentColor"/></svg>';
function vTitle(p,sub,back){const hd=h('div','vhd');
 if(back){const b=h('button','f vback');b.innerHTML=ic('left');b.setAttribute('aria-label','Volver');b.onclick=()=>vShow('home');hd.appendChild(b)}
 const lg=h('div','vlogo');lg.innerHTML='<i>'+CROWN+'</i><b>ElohimVIP</b>';hd.appendChild(lg);p.appendChild(hd);if(sub)p.appendChild(h('p','vsub',sub))}
function vShow(view,arg){let p=$('#vp');if(p.classList.contains('hidden')){p=ovOpen('#vp',()=>{VUI.view='home'})}else p.textContent='';
 VUI.view=view;p.classList.add('vip');p.scrollTop=0;const w=h('div','vwrap'),c=h('div','vcard');w.appendChild(c);p.appendChild(w);
 ({home:vHome,combo:vCombo,search:vSearch,accts:vAccts,themes:vThemes,later:vLater,stats:vStats,quick:vQuick,backup:vBackup,failover:vFailover,audio:vAudio,subs:vSubs,rem:vRem,cast:vCast,support:vSupport,news:vNews})[view](c,arg);
 setTimeout(()=>{const f=c.querySelector('.vin')||c.querySelector('.vrow,.vsw,.vsr')||c.querySelector('.vback')||c.querySelector('.f');try{f&&f.focus()}catch(e){}p.scrollTop=0},60)}
function vRow(p,ico,title,desc,tag,fn){const r=h('div','vrow f'+(fn?'':' soon'));r.tabIndex=0;const i=h('span','vi');i.innerHTML=ic(ico);r.appendChild(i);
 const b=h('div','vt');b.appendChild(h('b','',title));b.appendChild(h('small','',desc));r.appendChild(b);r.appendChild(h('em','vtag '+(fn?'on':'soon'),tag));if(fn)r.onclick=fn;p.appendChild(r);return r}
function vHome(c){vTitle(c,'Funciones extra para tu E-Player');
 const av=h('div','vaviso');av.innerHTML='<b>Gratis durante las pruebas.</b> Al pasar a producción, las funciones VIP tendrán un costo (los testers de la fase de pruebas no pagan). Se planea una prueba gratuita de 15 días al activarlo. Te avisaremos antes de que cambie.';c.appendChild(av);
 const grp=(t,rows)=>{c.appendChild(h('h3','vh',t));const L=h('div','vlist');c.appendChild(L);rows.forEach(r=>vRow(L,r[0],r[1],r[2],'Disponible',r[3]))};
 grp('Cuentas y listas',[
  ['users','Lista combinada','Junta hasta '+VIPX.max()+' cuentas en una sola lista, con etiqueta de origen.',()=>vShow('combo')],
  ['film','Buscador global','Busca en todas tus cuentas: canales, películas y series a la vez.',()=>vShow('search')],
  ['hist','Vencimientos y alertas','Días restantes de cada cuenta y aviso antes de que se acaben.',()=>vShow('accts')],
  ['swap','Cambio automático de fuente','Si un canal falla, prueba el mismo en la otra cuenta o en otra calidad.',()=>vShow('failover')]]);
 grp('Reproducción',[
  ['tv','Multivista','3 pantallas: una principal y dos secundarias. Cambia la principal cuando quieras.',()=>{ovClose('#vp');setTimeout(MV.open,60)}],
  ['audio','Ecualizador','Graves, voces y agudos a tu gusto, también en el reproductor avanzado.',()=>vShow('audio')],
  ['type','Subtítulos a medida','Tamaño, color, fondo y borde de los subtítulos.',()=>vShow('subs')],
  ['list','Canales rápidos','Mantén pulsada una tecla del 1 al 9 en el reproductor para guardar o abrir un canal.',()=>vShow('quick')],
  ['link','Enviar a otra pantalla','Manda lo que ves a tu TV o a otro equipo con apps compatibles con Chromecast.',()=>vShow('cast')]]);
 grp('Tu espacio',[
  ['sliders','Temas de color','Cambia el color y el ambiente de toda la app.',()=>vShow('themes')],
  ['star','Ver más tarde','Guarda películas y series pendientes, aparte de tus favoritos.',()=>vShow('later')],
  ['clock','Recordatorios de programas','Te avisamos cuando empiece el programa que elegiste en la guía.',()=>vShow('rem')],
  ['speed','Mi resumen','Tus horas vistas, canales y categorías favoritas. Todo queda en tu dispositivo.',()=>vShow('stats')],
  ['refresh','Respaldo y restauración','Guarda tus favoritos y ajustes en un archivo y recupéralos en otro equipo.',()=>vShow('backup')]]);
 grp('Ayuda',[['user','Soporte prioritario y novedades','Escríbenos con prioridad y mira lo nuevo de cada versión.',()=>vShow('support')]]);
 btn(c,'Cerrar',()=>ovClose('#vp'),'vclose','close')}
function vCombo(c){vTitle(c,'Lista combinada',true);const mx=VIPX.max();
 c.appendChild(h('p','vd','Elige hasta '+mx+' cuentas para verlas juntas en una sola lista. Cada película, serie o canal lleva una etiqueta con su cuenta de origen, y el buscador mira todas a la vez.'+(isLite()?' (En este equipo el máximo es '+mx+' para que vaya fluido.)':'')));
 if(S.combo){const st=h('div','vstat');S.combo.forEach((p,k)=>{const r=h('div','vcr');r.appendChild(VIPX.badge(k));r.appendChild(h('span','',p.name));r.appendChild(h('em',p.error?'vtag bad':'vtag on',p.error?'Error: '+p.error:(p.counts?fmtN(p.counts.live+p.counts.movie+p.counts.series)+' títulos':'')));st.appendChild(r)});c.appendChild(st)}
 if(!ACCTS.length){c.appendChild(h('p','vd','Primero guarda al menos dos cuentas (Perfil > Agregar o cambiar de cuenta).'));return}
 const sel=[];const cur=S.cfg?acctId(S.cfg):'';
 (S.combo?S.combo.map(p=>acctId(p.cfg)):[cur]).forEach(id=>{if(ACCTS.some(a=>a.id===id)&&sel.indexOf(id)<0)sel.push(id)});
 const L=h('div','vlist'),go=btn(c,'',()=>{},'vgo main','check');
 const upd=()=>{go.textContent=sel.length>1?'Cargar lista combinada ('+sel.length+')':'Elige al menos 2 cuentas';go.disabled=sel.length<2;L.querySelectorAll('.vck').forEach(r=>r.classList.toggle('on',sel.indexOf(r._id)>=0))};
 ACCTS.forEach(a=>{const r=h('div','vrow vck f');r.tabIndex=0;r._id=a.id;const i=h('span','vi');i.innerHTML=ic('users');r.appendChild(i);const b=h('div','vt');b.appendChild(h('b','',a.name));const d=dleft(a.exp);b.appendChild(h('small','',d===null?(xtCfg(a)?'Sin vencimiento':'Lista M3U'):d<0?'Vencida':d+' días restantes'));r.appendChild(b);r.appendChild(h('em','vtag chk','✓'));
  r.onclick=()=>{const at=sel.indexOf(a.id);if(at>=0)sel.splice(at,1);else if(sel.length<mx)sel.push(a.id);else toast('Máximo '+mx+' cuentas a la vez',2500);upd()};L.appendChild(r)});
 c.insertBefore(L,go);
 go.onclick=()=>{if(sel.length<2)return;const cf=sel.map(id=>ACCTS.filter(a=>a.id===id)[0].cfg);ovClose('#vp');connect(Object.assign({},cf[0],{combo:cf}),false)};
 if(S.combo){const b=btn(c,'Volver a una sola cuenta',()=>{const f=S.combo.filter(p=>!p.error)[0];ovClose('#vp');if(f)connect(f.cfg,false)},'','left')}
 upd()}
function vSearch(c){vTitle(c,'Buscador global',true);
 c.appendChild(h('p','vd',S.combo?'Busca en tus '+S.combo.length+' cuentas combinadas.':'Busca en todo el catálogo cargado. Con la lista combinada, también en todas tus cuentas.'));
 const inp=document.createElement('input');inp.className='vin f';inp.type='search';inp.placeholder='Escribe un nombre…';c.appendChild(inp);const out=h('div','vres');c.appendChild(out);
 const run=()=>{out.textContent='';const q=searchNorm(inp.value.trim());if(q.length<2){out.appendChild(h('p','vd','Escribe al menos 2 letras.'));return}
  let any=0;[['live','Canales','tv'],['movie','Películas','film'],['series','Series','series']].forEach(m=>{const r=[];let tot=0;S.data[m[0]].forEach(x=>{if(hidden(x))return;if((x._n||(x._n=searchNorm(x.name))).indexOf(q)>=0){tot++;if(r.length<25)r.push(x)}});
   if(!tot)return;any=1;out.appendChild(h('h3','vh',m[1]+' · '+fmtN(tot)));
   r.forEach(x=>{const e=h('div','vsr f');e.tabIndex=0;e.appendChild(h('b','',x.name));e.appendChild(h('span','dm',x.cat||''));if(S.combo&&x.src!=null)e.appendChild(VIPX.badge(x.src));
    e.onclick=()=>{ovClose('#vp');setTimeout(()=>openItem(x,{}),80)};out.appendChild(e)});
   if(tot>r.length)out.appendChild(h('p','vd','…y '+fmtN(tot-r.length)+' más. Escribe más letras para afinar.'))});
  if(!any)out.appendChild(h('p','vd','Sin resultados para «'+inp.value.trim()+'».'))};
 let t=0;inp.oninput=()=>{clearTimeout(t);t=setTimeout(run,200)};run()}
function vAccts(c){vTitle(c,'Vencimientos de tus cuentas',true);const box=h('div','vlist');
 const draw=()=>{box.textContent='';if(!ACCTS.length){box.appendChild(h('p','vd','Aún no hay cuentas guardadas.'));return}
  ACCTS.slice().sort((a,b)=>{const x=dleft(a.exp),y=dleft(b.exp);return(x===null?9e9:x)-(y===null?9e9:y)}).forEach(a=>{const d=dleft(a.exp),lv=dlvl(d),r=h('div','vac lv-'+(lv||'ok'));
   const hd=h('div','vah');hd.appendChild(h('b','',a.name));
   hd.appendChild(h('span','vdays',d===null?(xtCfg(a)?'Sin vencimiento':'Sin datos'):d<0?'Vencida':d===0?'Vence hoy':d+(d===1?' día':' días')));r.appendChild(hd);
   if(d!==null&&d>=0){const g=h('u','pgb lv-'+lv),s=h('s');s.style.width=Math.max(4,Math.min(100,d/365*100))+'%';g.appendChild(s);r.appendChild(g)}
   const meta=[];if(a.exp)meta.push('Vence el '+fmtDay(a.exp*1000));if(a.mc)meta.push('Conexiones: '+(a.ac!=null?a.ac+'/':'')+a.mc);if(a.err)meta.push('No se pudo consultar ahora');if(!xtCfg(a))meta.push('Las listas M3U simples no informan su vencimiento');
   if(meta.length)r.appendChild(h('small','vm',meta.join('  ·  ')));box.appendChild(r)})};
 c.appendChild(box);const st=h('p','vd','');c.appendChild(st);draw();
 const go=()=>{st.textContent='Consultando a tus proveedores…';return refreshAccts().then(()=>{st.textContent='Actualizado '+fmtClock(Date.now(),CFG.h12);draw()})};
 btn(c,'Actualizar ahora',go,'vgo main','refresh');
 const al=btn(c,'',()=>{CFG.expAl=VIPX.expAl()?0:1;saveCfg();setIc(al,'clock','Avisarme antes de que venzan: '+(VIPX.expAl()?'Sí':'No'));if(VIPX.expAl()&&natAl()&&AndroidApp.requestNotifPerm)AndroidApp.requestNotifPerm();VIPX.syncAlerts()},'','clock');setIc(al,'clock','Avisarme antes de que venzan: '+(VIPX.expAl()?'Sí':'No'));
 c.appendChild(h('p','vd',natAl()?'Recibirás una notificación 3 días y 1 día antes del vencimiento (a las 10:00).':'Los avisos del teléfono funcionan en la app de Android. Aquí verás el aviso al abrir la app.'));
 if(!ACCTS.some(a=>a.chk&&Date.now()-a.chk<600000))go()}
function vThemes(c){vTitle(c,'Temas de color',true);const g=h('div','vth');
 THEMES.forEach(t=>{const b=h('button','f vsw'+((CFG.theme||'def')===t.id?' on':''));b.style.cssText='--sa:'+t.a+';--sb:'+t.b+';--sbg:'+t.bg2;b.appendChild(h('i','vsd'));b.appendChild(h('span','',t.n));
  b.onclick=()=>{CFG.theme=t.id;saveCfg();applyTheme(t.id);g.querySelectorAll('.vsw').forEach(x=>x.classList.toggle('on',x===b))};g.appendChild(b)});c.appendChild(g);
 c.appendChild(h('p','vd','El tema se aplica al instante y se recuerda al volver a abrir la app.'))}
function vLater(c){vTitle(c,'Ver más tarde',true);const L=VIPX.laterItems(),box=h('div','vres');c.appendChild(box);
 if(!L.length)box.appendChild(h('p','vd','Todavía no guardaste nada. Abre una película o serie y toca «Ver más tarde».'));
 L.forEach(i=>{const r=h('div','vsr f');r.tabIndex=0;r.appendChild(h('b','',i.name));r.appendChild(h('span','dm',(i.type==='series'?'Serie':'Película')+(i.cat?' · '+i.cat:'')));if(S.combo&&i.src!=null)r.appendChild(VIPX.badge(i.src));
  const x=h('button','f sm');x.textContent='Quitar';x.onclick=ev=>{ev.stopPropagation();delete LATER[fk(i)];lsSet('iptv_later',LATER);r.remove()};r.appendChild(x);
  r.onclick=()=>{ovClose('#vp');setTimeout(()=>openItem(i,{}),80)};box.appendChild(r)})}
function vStats(c){vTitle(c,'Mi resumen',true);const days=[];for(let k=6;k>=0;k--){const t=Date.now()-k*864e5,key=dkey(t),e=STATS.d[key]||{l:0,v:0};days.push({k:key,w:new Date(t).toLocaleDateString('es',{weekday:'short'}),l:e.l,v:e.v})};
 const tot=days.reduce((a,x)=>a+x.l+x.v,0),lv=days.reduce((a,x)=>a+x.l,0),hrs=s=>s<60?Math.round(s)+' s':s<3600?Math.round(s/60)+' min':(Math.round(s/360)/10)+' h';
 const big=h('div','vbig');big.appendChild(h('b','',hrs(tot)));big.appendChild(h('span','','vistos en los últimos 7 días'));c.appendChild(big);
 const mxv=Math.max.apply(null,days.map(x=>x.l+x.v).concat([1])),bars=h('div','vbars');
 days.forEach(x=>{const col=h('div','vbc'),b=h('i','');b.style.height=Math.max(3,(x.l+x.v)/mxv*100)+'%';b.title=hrs(x.l+x.v);col.appendChild(b);col.appendChild(h('small','',x.w));bars.appendChild(col)});c.appendChild(bars);
 c.appendChild(h('p','vd','En vivo: '+hrs(lv)+'  ·  Películas y series: '+hrs(tot-lv)));
 const sec=(t,o)=>{const a=topN(o,5);if(!a.length)return;c.appendChild(h('h3','vh',t));a.forEach(x=>{const r=h('div','vcr');r.appendChild(h('span','',x[0]));r.appendChild(h('em','vtag on',hrs(x[1])));c.appendChild(r)})};
 sec('Lo más visto',STATS.t);sec('Categorías favoritas',STATS.c);
 if(!tot)c.appendChild(h('p','vd','Aún no hay datos. Se cuentan los minutos que ves en el reproductor integrado de la app.'));
 c.appendChild(h('p','vd','Todo se calcula y guarda solo en este dispositivo.'));
 btn(c,'Borrar estadísticas',()=>{STATS.d={};STATS.t={};STATS.c={};lsSet('iptv_stats',STATS);vShow('stats')},'','trash')}
function vQuick(c){vTitle(c,'Canales rápidos',true);
 c.appendChild(h('p','vd','En el reproductor (pantalla completa, con control remoto o teclado): mantén pulsado un número del 1 al 9. Si está vacío, guarda el canal que estás viendo; si ya tiene canal, te lleva a él. También puedes elegirlos aquí.'));
 const L=h('div','vlist');c.appendChild(L);
 const draw=()=>{L.textContent='';for(let d=1;d<=9;d++)(function(d){const q=QUICK[d],r=h('div','vrow f');r.tabIndex=0;r.appendChild(h('span','vn',String(d)));const b=h('div','vt');b.appendChild(h('b','',q?q.name:'Vacío'));b.appendChild(h('small','',q?'Toca para cambiar':'Toca para elegir un canal'));r.appendChild(b);
  if(q){const x=h('button','f sm');x.textContent='Quitar';x.onclick=ev=>{ev.stopPropagation();delete QUICK[d];lsSet('iptv_quick',QUICK);draw()};r.appendChild(x)}
  r.onclick=()=>pickLive(it=>{QUICK[d]={url:it.url,name:it.name,logo:it.logo||'',src:it.src};lsSet('iptv_quick',QUICK);vShow('quick')},'Canal rápido '+d);L.appendChild(r)})(d)};draw()}
function vBackup(c){vTitle(c,'Respaldo y restauración',true);
 c.appendChild(h('p','vd','Guarda tus favoritos, historial, «Ver más tarde», canales rápidos y ajustes. Úsalo para cambiar de teléfono o pasar tu configuración a otro equipo.'));
 const lab=h('label','vchk f');lab.tabIndex=0;const cb=document.createElement('input');cb.type='checkbox';cb.checked=VUI.inc;cb.onchange=()=>{VUI.inc=cb.checked};lab.appendChild(cb);lab.appendChild(h('span','','Incluir mis cuentas (contiene usuario y contraseña: guárdalo en un lugar seguro)'));c.appendChild(lab);
 const msg=h('p','vd','');
 btn(c,'Descargar respaldo',()=>{try{const b=new Blob([backupJson(VUI.inc)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='e-player-respaldo-'+dkey()+'.json';document.body.appendChild(a);a.click();setTimeout(()=>{a.remove();URL.revokeObjectURL(a.href)},1500);msg.textContent='Respaldo generado. Si no se descargó, usa «Copiar respaldo».'}catch(e){msg.textContent='No se pudo descargar: usa «Copiar respaldo».'}},'vgo main','check');
 btn(c,'Copiar respaldo',()=>{copyText(backupJson(VUI.inc)).then(ok=>{msg.textContent=ok?'Respaldo copiado. Pégalo en un mensaje o nota para guardarlo.':'No se pudo copiar'})},'','refresh');
 c.appendChild(h('h3','vh','Restaurar'));
 const ta=document.createElement('textarea');ta.className='vin vta f';ta.placeholder='Pega aquí el respaldo…';c.appendChild(ta);
 const fi=document.createElement('input');fi.type='file';fi.accept='.json,application/json';fi.className='vfile';fi.onchange=()=>{const f=fi.files&&fi.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{ta.value=String(r.result||'');msg.textContent='Archivo leído. Pulsa «Restaurar».'};r.readAsText(f)};c.appendChild(fi);
 btn(c,'Restaurar',()=>{try{const n=restoreJson(ta.value);msg.textContent='Listo: se restauraron '+n+' elementos. Reiniciando…';setTimeout(()=>location.reload(),900)}catch(e){msg.textContent=e.message}},'','check');c.appendChild(msg)}

function vFailover(c){vTitle(c,'Cambio automático de fuente',true);
 c.appendChild(h('p','vd','Si un canal en vivo falla, E-Player prueba solo el mismo canal en tu otra cuenta (si usas la lista combinada) o en otra calidad de la misma cuenta (por ejemplo HD y SD), sin que tengas que tocar nada.'));
 c.appendChild(h('p','vd','Detecta canales repetidos por el nombre, ignorando HD, SD, FHD o 4K. Se prueba cada alternativa una sola vez.'));
 const b=btn(c,'',()=>{CFG.fo=VIPX.foOn()?0:1;saveCfg();setIc(b,'swap','Cambio automático: '+(VIPX.foOn()?'Activado':'Desactivado'))},'vgo main','swap');setIc(b,'swap','Cambio automático: '+(VIPX.foOn()?'Activado':'Desactivado'));
 c.appendChild(h('p','vd','Funciona en el reproductor integrado. El reproductor avanzado ya prueba varias variantes del mismo enlace por su cuenta.'))}
function vAudio(c){vTitle(c,'Ecualizador',true);const e=eqCfg();
 c.appendChild(h('p','vd','Ajusta el sonido a tu gusto. Se aplica en el reproductor integrado (TV en vivo) y en el reproductor avanzado (películas y series).'));
 const sw=btn(c,'',()=>{e.on=e.on?0:1;saveCfg();VIPX.eqNative();const ok=VIPX.eqApply();setIc(sw,'audio','Ecualizador: '+(e.on?'Activado':'Desactivado'));if(e.on&&!ok&&!EQG)toast('Se aplicará en el reproductor avanzado y en cuanto veas un canal en vivo',4500)},'vgo main','audio');setIc(sw,'audio','Ecualizador: '+(e.on?'Activado':'Desactivado'));
 const pr=h('div','vth');c.appendChild(pr);const sl=[];
 const set=()=>{VIPX.eqNative();VIPX.eqApply(true);saveCfg()};
 Object.keys(EQP).forEach(k=>{const b=h('button','f vsw'+(e.p===k?' on':''));b.style.cssText='--sa:#e9c46a;--sb:#b88a2e;--sbg:#12100a';b.appendChild(h('span','',EQN[k]));
  b.onclick=()=>{e.p=k;e.g=EQP[k].slice();e.on=1;pr.querySelectorAll('.vsw').forEach(x=>x.classList.toggle('on',x===b));sl.forEach((s,i)=>{s.value=e.g[i];s._o.textContent=e.g[i]+' dB'});setIc(sw,'audio','Ecualizador: Activado');set()};pr.appendChild(b)});
 c.appendChild(h('h3','vh','Bandas'));const bx=h('div','veq');c.appendChild(bx);
 EQB.forEach((f,i)=>{const col=h('div','veqc'),o=h('small','',e.g[i]+' dB'),r=document.createElement('input');r.type='range';r.min=-10;r.max=10;r.step=1;r.value=e.g[i];r.className='f';r._o=o;
  r.oninput=()=>{e.g[i]=+r.value;e.p='';e.on=1;o.textContent=r.value+' dB';pr.querySelectorAll('.vsw').forEach(x=>x.classList.remove('on'));setIc(sw,'audio','Ecualizador: Activado');set()};
  sl.push(r);col.appendChild(o);col.appendChild(r);col.appendChild(h('small','',f>=1000?(f/1000)+' kHz':f+' Hz'));bx.appendChild(col)})}
function vSubs(c){vTitle(c,'Subtítulos a medida',true);const s=subCfg();
 c.appendChild(h('p','vd','Elige cómo se ven los subtítulos. Se aplica en el reproductor integrado y en el avanzado.'));
 const pv=h('div','vsubpv');pv.appendChild(h('span','','Así se verán tus subtítulos'));c.appendChild(pv);
 const paint=()=>{pv.style.fontSize=(1.35*s.z/100)+'rem';pv.firstChild.style.cssText='color:'+SUBC[s.c][1]+';background:'+SUBBG[s.b]+';text-shadow:'+SUBSH[s.e]+';padding:.15em .5em;border-radius:.2em';VIPX.subApply();saveCfg()};
 const chips=(t,arr,key,lab)=>{c.appendChild(h('h3','vh',t));const g=h('div','vth');c.appendChild(g);arr.forEach((x,i)=>{const b=h('button','f vsw'+(s[key]===i?' on':''));b.style.cssText='--sa:#e9c46a;--sb:#b88a2e;--sbg:#12100a';b.appendChild(h('span','',lab(x)));
  b.onclick=()=>{s[key]=i;g.querySelectorAll('.vsw').forEach(q=>q.classList.toggle('on',q===b));paint()};g.appendChild(b)})};
 c.appendChild(h('h3','vh','Tamaño'));const row=h('div','veqc');const o=h('small','',s.z+'%'),r=document.createElement('input');r.type='range';r.min=60;r.max=220;r.step=10;r.value=s.z;r.className='f';r.oninput=()=>{s.z=+r.value;o.textContent=r.value+'%';paint()};row.appendChild(o);row.appendChild(r);c.appendChild(row);
 chips('Color',SUBC,'c',x=>x[0]);chips('Fondo',SUBB,'b',x=>x);chips('Borde',SUBE,'e',x=>x);paint()}
function vRem(c){vTitle(c,'Recordatorios de programas',true);
 c.appendChild(h('p','vd','En la guía de un canal, toca un programa que aún no empieza para que te avise. Aquí ves y quitas tus recordatorios.'));
 const box=h('div','vres');c.appendChild(box);
 const draw=()=>{box.textContent='';const L=REM.filter(r=>r.t>Date.now()-600000);if(!L.length){box.appendChild(h('p','vd','No tienes recordatorios. Abre la guía de TV en vivo y toca un programa próximo.'));return}
  L.forEach(r=>{const e=h('div','vsr f');e.tabIndex=0;e.appendChild(h('b','',r.title));e.appendChild(h('span','dm',r.ch+' · '+hm(r.t)));
   const x=h('button','f sm');x.textContent='Quitar';x.onclick=ev=>{ev.stopPropagation();const at=REM.indexOf(r);if(at>=0){REM.splice(at,1);lsSet('iptv_rem',REM);nCancel('rem|'+r.id)}draw()};e.appendChild(x);
   e.onclick=()=>{ovClose('#vp');const it=idx('live')[r.url]||{name:r.ch,url:r.url,type:'live',src:r.src,logo:r.logo};playLiveFrom(it)};box.appendChild(e)})};draw();
 c.appendChild(h('p','vd',natAl()?'Recibirás una notificación en el teléfono un minuto antes. Si reinicias el teléfono, abre la app una vez para reactivarlos.':'Mientras la página esté abierta verás un aviso un minuto antes.'))}
function vCast(c){vTitle(c,'Enviar a otra pantalla',true);
 c.appendChild(h('p','vd','Manda lo que estás viendo a tu TV u otro equipo. E-Player ofrece el enlace de video a las apps que tengas instaladas: VLC, Web Video Caster, LocalCast y otras que sepan hacer Chromecast.'));
 c.appendChild(h('p','vd','También está en el menú del reproductor, en «Enviar a otra pantalla».'));
 btn(c,'Enviar lo que estoy viendo',()=>{ovClose('#vp');VIPX.cast()},'vgo main','link');
 c.appendChild(h('p','vd','Nota: no es la transmisión Chromecast integrada de Google; depende de que la app que elijas la soporte.'))}
function vSupport(c){vTitle(c,'Soporte prioritario y novedades',true);
 const dev='Versión '+VER+' · '+(navigator.userAgent||'').slice(0,120);
 c.appendChild(h('p','vd','Los mensajes de usuarios VIP se marcan como prioritarios para responderlos primero.'));
 btn(c,'Escribir a soporte VIP',()=>mailTo('[VIP] Soporte E-Player','\n\n—\n'+dev),'vgo main','user');
 c.appendChild(h('h3','vh','Novedades'));NEWS.forEach(n=>{c.appendChild(h('p','vd','Versión '+n.v+' — '+n.t));n.i.forEach(x=>{const r=h('div','vcr');r.appendChild(h('span','','• '+x));c.appendChild(r)})})}
function vNews(c){vTitle(c,'Novedades de esta versión');const n=NEWS[0];
 c.appendChild(h('p','vsub','Versión '+n.v+' — '+n.t));const L=h('div','vstat');n.i.forEach(x=>{const r=h('div','vcr');r.appendChild(h('span','','• '+x));L.appendChild(r)});c.appendChild(L);
 btn(c,'Ver funciones VIP',()=>vShow('home'),'vgo main','star');btn(c,'Cerrar',()=>ovClose('#vp'),'vclose','close')}

const VIPUI={};
VIPUI.back=function(){if(VUI.view!=='home'){vShow('home');return true}return false};
VIPUI.open=()=>vShow('home');
VIPUI.banner=function(){const n=expiring(),b=h('div','vipb f');b.tabIndex=0;
 b.innerHTML='<i class="vb-glow"></i><span class="vb-ic">'+CROWN+'</span><span class="vb-tx"><b>ElohimVIP</b><small>Multivista · Lista combinada · Ecualizador y más</small></span>'+
  (n?'<em class="vb-w">⚠ '+n+(n===1?' cuenta por vencer':' cuentas por vencer')+'</em>':'<em class="vb-g">Gratis ahora</em>')+'<span class="vb-go">'+ic('right')+'</span>';
 b.onclick=VIPUI.open;return b};
VIPUI.profileRows=function(R){R.appendChild(h('h3','sh','ElohimVIP'));
 srow(R,'ElohimVIP','Funciones extra · gratis ahora',()=>{VIPUI.open();return false},'star');
 R.appendChild(h('h3','sh','App'));
 srow(R,'Compartir E-Player','Invita a tus amigos',()=>{VIPX.share();return false},'share');
 srow(R,'Buscar actualización','Versión '+VER.replace('-pwa',''),()=>{VIPX.update();return false},'refresh')};
window.VIPX=VIPX;window.VIPUI=VIPUI;
applyTheme(CFG.theme||'def');VIPX.subApply();VIPX.eqNative();
setTimeout(()=>{VIPX.syncAlerts();VIPX.expToast();VIPX.newsAuto()},4000);
