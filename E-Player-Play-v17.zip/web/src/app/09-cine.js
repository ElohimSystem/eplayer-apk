/* ===== v14 — transición cinematográfica «Entrar → app» =====
   1) Entrada: barras de cine, oscuridad con viñeta, la «E▮▮» se dibuja, el nombre se abre, línea de luz.
   2) Mientras conecta: la pausa «respira» (nunca se corta: dura mínimo 2,4 s).
   3) Clímax: la pausa se convierte en PLAY, lo demás se apaga y el triángulo se acerca hasta
      convertirse en una ventana por la que aparece la app (destello + línea anamórfica). */
const CINE=(function(){
 const TRI='M48 4.4v31.2a1.5 1.5 0 0 0 2.3 1.3L64 21.3a1.5 1.5 0 0 0 0-2.6L50.3 3.1A1.5 1.5 0 0 0 48 4.4z';
 let el=null,T=[],raf=0,t0=0,busy=false,geo=null;
 const later=(f,ms)=>{T.push(setTimeout(f,ms))};
 const clr=()=>{T.forEach(clearTimeout);T=[];if(raf){cancelAnimationFrame(raf);raf=0}};
 const lite=()=>document.body.classList.contains('lite');
 const reduce=()=>{try{return !!(window.matchMedia&&matchMedia('(prefers-reduced-motion:reduce)').matches)}catch(e){return false}};
 const q=s=>el.querySelector(s);
 function build(){
  const W=innerWidth,H=innerHeight,lh=Math.min(H*.3,W*.17),k=lh/40,x0=(W-66*k)/2,y0=H*.4-lh/2,cx=x0+53.33*k,cy=y0+20*k;
  const fs=Math.max(10,Math.round(H*.03)),nt=Math.round(y0+lh+H*.075),R=Math.max(W,H);
  geo={W:W,H:H,k:k,cx:cx,cy:cy};
  const tf='translate('+x0+' '+y0+') scale('+k+')',gl=Math.round(lh*1.9);
  el=document.createElement('div');el.id='cine';el.setAttribute('aria-hidden','true');
  el.innerHTML=
   '<svg class="cn-svg" width="'+W+'" height="'+H+'" viewBox="0 0 '+W+' '+H+'">'+
   '<defs><radialGradient id="cnbg" cx="50%" cy="42%" r="78%"><stop offset="0" stop-color="#0e2038"/><stop offset=".5" stop-color="#060b15"/><stop offset="1" stop-color="#010204"/></radialGradient>'+
   '<radialGradient id="cngl"><stop offset="0" stop-color="#3fe0c5" stop-opacity=".34"/><stop offset=".55" stop-color="#4a86ff" stop-opacity=".16"/><stop offset="1" stop-color="#4a86ff" stop-opacity="0"/></radialGradient>'+
   '<mask id="cnm" maskUnits="userSpaceOnUse" x="0" y="0" width="'+W+'" height="'+H+'"><rect width="'+W+'" height="'+H+'" fill="#fff"/>'+
   '<g id="cnZh" opacity="0"><g transform="'+tf+'"><path d="'+TRI+'" fill="#000"/></g></g></mask></defs>'+
   '<rect id="cnDark" width="'+W+'" height="'+H+'" fill="url(#cnbg)" mask="url(#cnm)"/>'+
   '<ellipse class="cn-glow" cx="'+cx+'" cy="'+(y0+lh/2)+'" rx="'+gl+'" ry="'+Math.round(gl*.75)+'" fill="url(#cngl)" style="transform-origin:'+cx+'px '+(y0+lh/2)+'px"/>'+
   '<g transform="'+tf+'"><g class="cn-e" fill="#3fe0c5"><rect x="2" y="2" width="7" height="36" rx="2"/><rect x="2" y="2" width="22" height="7" rx="2"/><rect x="2" y="16.5" width="17" height="7" rx="2"/><rect x="2" y="31" width="22" height="7" rx="2"/></g>'+
   '<g class="cn-pg" fill="#4a86ff"><rect class="cn-pst" x="36" y="2" width="7" height="36" rx="2"/><rect class="cn-pz" x="49" y="2" width="7" height="36" rx="2"/></g></g>'+
   '<g id="cnZ"><g transform="'+tf+'"><path class="cn-tri" d="'+TRI+'" fill="#4a86ff"/></g></g></svg>'+
   '<div class="cn-streak" style="top:'+Math.round(cy)+'px"></div>'+
   '<div class="cn-name" style="top:'+nt+'px;font-size:'+fs+'px"><b>ELOHIM</b><em>PLAYER</em></div>'+
   '<div class="cn-load" style="top:'+Math.round(nt+fs*2.7)+'px"><i></i></div>'+
   '<div class="cn-sub" style="top:'+Math.round(nt+fs*3.6)+'px;font-size:'+Math.round(fs*.72)+'px">Preparando tu contenido</div>'+
   '<div class="cn-flash" style="width:'+R*1.3+'px;height:'+R*1.3+'px;left:'+Math.round(cx-R*.65)+'px;top:'+Math.round(cy-R*.65)+'px"></div>'+
   '<div class="cn-bar t"></div><div class="cn-bar b"></div>';
  document.body.appendChild(el)}
 function finish(){clr();if(el&&el.parentNode)el.parentNode.removeChild(el);el=null;busy=false;
  const L=document.getElementById('login');if(L)L.classList.remove('cine-go')}
 function zoom(){
  const g=geo,W=g.W,H=g.H,smax=Math.max(W/(10.67*g.k),(W+H)/(21.4*g.k))*1.15,L=Math.log(smax),D=1750,a=Date.now(),
   z=q('#cnZ'),zh=q('#cnZh'),lt=lite();
  if(lt){q('#cnDark').removeAttribute('mask');el.classList.add('lz')}else zh.setAttribute('opacity','1');
  const step=()=>{let p=(Date.now()-a)/D;if(p>1)p=1;const e=p*p*(3-2*p),s=Math.exp(L*e),
    px=g.cx+(W/2-g.cx)*e,py=g.cy+(H/2-g.cy)*e,tr='translate('+px+' '+py+') scale('+s+') translate('+(-g.cx)+' '+(-g.cy)+')';
   z.setAttribute('transform',tr);if(!lt)zh.setAttribute('transform',tr);
   z.setAttribute('opacity',String(Math.max(0,1-Math.max(0,p-.04)/.3)));
   if(p<1)raf=requestAnimationFrame(step);else{raf=0;later(finish,60)}};
  raf=requestAnimationFrame(step)}
 return{
  get busy(){return busy},
  start(){if(busy||reduce())return false;busy=true;build();t0=Date.now();
   const L=document.getElementById('login');if(L)L.classList.add('cine-go');
   void el.offsetWidth;el.classList.add('on');return true},
  /* la intro siempre se ve completa (mín. 2,4 s), aunque el servidor responda al instante */
  ready(){return new Promise(r=>setTimeout(r,Math.max(0,2400-(Date.now()-t0))))},
  reveal(){if(!el)return;clr();
   el.classList.add('play');                         /* pausa → PLAY */
   later(()=>{if(el)el.classList.add('fade')},650);  /* se apaga todo menos el triángulo */
   later(()=>{if(!el)return;el.classList.add('zoom');zoom()},1080)},
  /* si falla, no se corta de golpe: espera ~1,2 s y se disuelve devolviendo el acceso */
  fail(){if(!busy)return;clr();later(()=>{if(el)el.classList.add('out');
   const L=document.getElementById('login');if(L)L.classList.remove('cine-go');later(finish,650)},Math.max(0,1200-(Date.now()-t0)))}}})();
