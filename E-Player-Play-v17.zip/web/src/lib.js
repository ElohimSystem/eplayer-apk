/* ===== Lógica pura (sin DOM): se prueba con `node test/test.js` ===== */
/* Compatible Chromium 53 (webOS 4): sin padStart, Object.values, finally, etc. */
function searchNorm(s){s=String(s==null?'':s).toLowerCase();try{if(s.normalize)s=s.normalize('NFD').replace(/[̀-ͯ]/g,'')}catch(e){}return s}
function pad2(n){return(n<10?'0':'')+n}
function fmtDur(sec){sec=Math.max(0,Math.floor(+sec||0));var h=Math.floor(sec/3600),m=Math.floor(sec%3600/60),s=sec%60;return(h?h+':'+pad2(m):m)+':'+pad2(s)}
function fmtDateTime(ms){var d=new Date(ms);return d.getFullYear()+'-'+pad2(d.getMonth()+1)+'-'+pad2(d.getDate())+' '+pad2(d.getHours())+':'+pad2(d.getMinutes())}
function fmtDay(ms){var d=new Date(ms);return d.getFullYear()+'-'+pad2(d.getMonth()+1)+'-'+pad2(d.getDate())}

/* ---------- Clasificación TV / Películas / Series (listas M3U) ---------- */
var RX_VOD_EXT=/\.(mp4|mkv|avi|mov|wmv|flv|webm|m4v|mpg|mpeg)(\?|#|$)/i;
var RX_G_LIVE=/24\s*[\/x-]?\s*7|\bradio\b|en\s+vivo|\blive\b/i;
var RX_G_SERIES=/\bseries?\b|\bs[eé]ries\b|temporada|season|telenovela|novela|\banime\b|dorama|k-?drama/i;
var RX_G_MOVIE=/pel[ií]cula|\bmovies?\b|\bfilm(s|es|e)?\b|\bvod\b|\bcine\b|\bcinema\b|estreno|documental|documentary/i;
function parseEpisode(name){
 var n=String(name||''),m,clean=function(t){return t.replace(/^[\s._\-–|:]+|[\s._\-–|:]+$/g,'')},r=function(m){var t=clean(m[1]);return{title:t||clean(n),s:+m[2],e:+m[3]}};
 m=n.match(/^(.*?)[\s._\-–|]*\bS(\d{1,2})\s?[._-]?\s?E(\d{1,4})\b/i);if(m)return r(m);
 m=n.match(/^(.*?)[\s._\-–|]*\b(\d{1,2})x(\d{1,3})\b/i);if(m)return r(m);
 m=n.match(/^(.*?)[\s._\-–|]*\b(?:temporada|temp|season|t)\s?\.?(\d{1,2})\s*[-–,.]?\s*(?:episodio|episode|cap[ií]tulo|cap|ep|e)\s?\.?\s?(\d{1,4})\b/i);if(m)return r(m);
 return null}
function classify(url,name,group,hint){
 if(hint==='movie'||hint==='series'||hint==='live')return hint;
 url=url||'';group=group||'';name=name||'';
 if(/\/movie\//i.test(url))return'movie';
 if(/\/series\//i.test(url))return'series';
 if(parseEpisode(name))return'series';
 if(RX_G_LIVE.test(group))return'live';
 if(RX_G_SERIES.test(group)&&!/\bserie\s+[a-z]\b/i.test(group))return'series';
 if(RX_G_MOVIE.test(group))return'movie';
 if(RX_VOD_EXT.test(url))return'movie';
 if(/\((?:19|20)\d\d\)\s*$/.test(name))return'movie';
 return'live'}
function resolveUrl(base,rel){rel=String(rel||'');if(/^https?:/i.test(rel))return rel;
 try{return new URL(rel,base).href}catch(e){}
 if(rel.indexOf('//')===0)return(base.match(/^https?:/i)||['http:'])[0]+rel;
 if(rel[0]==='/')return base.match(/^https?:\/\/[^\/]+/)[0]+rel;
 var b=base.replace(/[?#].*$/,'');if(/^https?:\/\/[^\/]+$/i.test(b))b+='/';return b.replace(/[^\/]*$/,'')+rel}
/* separa "#EXTINF:-1 a="x, y" b="z",Nombre" respetando comas dentro de comillas */
function splitExtinf(l){var q='',i=l.indexOf(':')+1;for(;i<l.length;i++){var c=l[i];if(q){if(c===q)q=''}else if(c==='"'||c==="'"){if(/=$/.test(l.slice(i-1,i)))q=c}else if(c===',')break}
 return{meta:l.slice(0,i),name:i<l.length?l.slice(i+1).trim():''}}
function attrsOf(meta){var o={},re=/([A-Za-z0-9_-]+)=(?:"([^"]*)"|'([^']*)'|([^\s",]+))/g,m;while((m=re.exec(meta)))o[m[1].toLowerCase()]=m[2]!=null?m[2]:m[3]!=null?m[3]:m[4];return o}
/* &amp; &quot; … que algunas listas dejan dentro de los nombres */
function decEnt(s){s=String(s);return s.indexOf('&')<0?s:s.replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#0?39;|&apos;/g,"'").replace(/&amp;/g,'&')}
/* nombre de respaldo para una URL sin #EXTINF */
function nameFromUrl(u){var p='';try{p=decodeURIComponent(String(u).replace(/[?#].*$/,'').replace(/\/+$/,'').split('/').pop()||'')}catch(e){p=''}
 p=p.replace(/\.[A-Za-z0-9]{2,5}$/,'').replace(/[_+]+/g,' ').trim();return p||hostOf(u)||'Sin nombre'}
/* ¿es una lista HLS (lista maestra o de segmentos de UN canal) y no una lista de canales IPTV? */
function isHlsPlaylist(t){return /#EXT-X-(STREAM-INF|TARGETDURATION|MEDIA-SEQUENCE|PLAYLIST-TYPE|ENDLIST)/.test(String(t||''))}
function parseM3U(txt,base){
 /* sm sin prototipo: un título como "constructor" o "__proto__" no puede romper la lectura de toda la lista */
 var out={live:[],movie:[],series:[],epg:'',skipped:0},sm=Object.create(null),inf=null,grp='';
 txt=String(txt||'').replace(/^\uFEFF/,'');
 var hm=txt.match(/#EXTM3U[^\r\n]*?(?:url-tvg|x-tvg-url)=["']?([^"',\s]+)/i);out.epg=hm?hm[1]:'';
 txt.split(/\r\n|\r|\n/).forEach(function(l){l=l.trim();if(!l)return;
  if(l.indexOf('#EXTINF')===0){var sp=splitExtinf(l),a=attrsOf(sp.meta);
   inf={tid:a['tvg-id']||'',name:decEnt(sp.name||a['tvg-name']||'Sin nombre'),logo:a['tvg-logo']||'',gt:decEnt((a['group-title']||'').replace(/;.*$/,'').trim()),hint:(a['tvg-type']||'').toLowerCase()}}
  else if(l.indexOf('#EXTGRP:')===0)grp=l.slice(8).trim();
  else if(l[0]!=='#'){
   /* URL suelta sin #EXTINF: se acepta si es http(s) */
   if(!inf){if(!/^https?:\/\//i.test(l))return;inf={tid:'',name:nameFromUrl(l),logo:'',gt:'',hint:''}}
   var u=l.replace(/\|[A-Za-z-]+=.*$/,'');
   /* solo http/https se pueden reproducir: rtmp, rtsp, udp, acestream, etc. se ignoran (y se cuentan) */
   if(/^[a-z][a-z0-9+.-]*:/i.test(u)&&!/^https?:/i.test(u)){out.skipped++;inf=null;return}
   if(base&&!/^https?:/i.test(u))u=resolveUrl(base,u);
   inf.cat=inf.gt||decEnt(grp)||'Sin categoría';
   var t=classify(u,inf.name,inf.cat,inf.hint);
   if(t==='series'){var ep=parseEpisode(inf.name),title=ep?ep.title:inf.name,k=searchNorm(title);
    if(!sm[k]){sm[k]={name:title,logo:inf.logo,cat:inf.cat,type:'series',eps:{}};out.series.push(sm[k])}
    var s=ep?ep.s:1,arr=sm[k].eps[s]=sm[k].eps[s]||[];if(!sm[k].logo&&inf.logo)sm[k].logo=inf.logo;
    arr.push({title:ep?'E'+ep.e+' - '+inf.name:inf.name,full:inf.name,url:u,n:ep?ep.e:arr.length+1})}
   else out[t].push({name:inf.name,logo:inf.logo,cat:inf.cat,url:u,type:t,tid:inf.tid});
   inf=null}});
 return out}
function normalizeHost(h){h=(h||'').trim();if(!/^https?:\/\//i.test(h))h='http://'+h;
 try{var u=new URL(h);return u.origin+u.pathname.replace(/\/(c|player_api\.php|get\.php|panel_api\.php|portal\.php)?\/*$/,'')}catch(e){return h.replace(/\/+$/,'')}}
function parseXtreamUrl(u){var m=(u||'').match(/^(https?:\/\/[^\/]+)\/(?:.*\/)?get\.php\?(.*)$/i);if(!m)return null;var q={};
 m[2].split('&').forEach(function(p){var kv=p.split('=');try{q[kv[0]]=decodeURIComponent((kv[1]||'').replace(/\+/g,' '))}catch(e){q[kv[0]]=kv[1]||''}});
 return q.username&&q.password?{host:m[1],user:q.username,pass:q.password}:null}
function maskUrl(u){return String(u||'').replace(/((?:username|password|user|pass|token|key)=)[^&]*/ig,'$1•••')}
function hostOf(u){var m=String(u||'').match(/^https?:\/\/([^\/:?#]+)/i);return m?m[1]:String(u||'')}
function isAdult(cat,name){return /adult|xxx|18\s*\+|\+\s*18|porn|er[oó]tic|sexo|hentai/i.test(cat||'')||/\bxxx\b|porn/i.test(name||'')}

/* ---------- Xtream Codes ---------- */
function fmtList(a){if(typeof a==='string')a=a.split(/[,\s]+/);return Array.isArray(a)?a.filter(Boolean):[]}
function pickFormat(allowed,pref){var a=fmtList(allowed).map(function(f){f=String(f).toLowerCase();return f==='hls'?'m3u8':f});
 if(pref&&pref!=='auto'&&(!a.length||a.indexOf(pref)>=0))return pref;
 /* m3u8 si el plan lo permite; si no, ts (rtmp y otros no se pueden reproducir aquí) */
 if(!a.length||a.indexOf('m3u8')>=0)return'm3u8';return'ts'}
function num(x){var n=parseFloat(x);return isFinite(n)?n:0}
/* Los paneles Xtream no siempre responden igual: lista, objeto indexado, false, mensaje de error… Siempre devolvemos un arreglo de objetos. */
function toArr(x){if(Array.isArray(x))return x.filter(function(v){return v&&typeof v==='object'});
 if(x&&typeof x==='object'){var o=[];Object.keys(x).forEach(function(k){var v=x[k];if(v&&typeof v==='object'&&!Array.isArray(v))o.push(v)});return o}return[]}
function xstr(x,d){var s=x==null?'':String(x).trim();return s||d||''}
function hasId(v){return v!=null&&v!==''}
function mapXtream(raw,base,u,p,fmt){
 var E=encodeURIComponent,pre=base+'/',L=raw.L||[],arr=toArr;
 var cm=function(a){var o=Object.create(null),ord=[];arr(a).forEach(function(c){if(!hasId(c.category_id))return;var n=xstr(c.category_name,'Otros');o[c.category_id]=n;ord.push(n)});return{map:o,ord:ord}};
 var lc=cm(L[0]),mc=cm(L[2]),sc=cm(L[4]);
 var rt=function(x){var r=num(x.rating_5based)?num(x.rating_5based)*2:num(x.rating);return r?Math.round(r*10)/10:0};
 var yr=function(x){var m=String(x.year||x.releaseDate||x.releasedate||'').match(/\d{4}/);return m?m[0]:''};
 var lg=function(v){return typeof v==='string'?v.trim():''};
 var ext=function(v,d){var e=xstr(v,d).replace(/^\./,'').replace(/[^A-Za-z0-9]/g,'');return e||d};
 return{
  live:arr(L[1]).filter(function(x){return hasId(x.stream_id)}).map(function(x){return{name:xstr(x.name,'Sin nombre'),logo:lg(x.stream_icon),cat:lc.map[x.category_id]||'Otros',type:'live',sid:x.stream_id,tid:xstr(x.epg_channel_id),adult:+x.is_adult===1,added:num(x.added),
   url:pre+'live/'+E(u)+'/'+E(p)+'/'+x.stream_id+'.'+fmt}}),
  movie:arr(L[3]).filter(function(x){return hasId(x.stream_id)}).map(function(x){return{name:xstr(x.name,'Sin nombre'),logo:lg(x.stream_icon),cat:mc.map[x.category_id]||'Otros',type:'movie',vid:x.stream_id,adult:+x.is_adult===1,added:num(x.added),rating:rt(x),year:yr(x),
   url:pre+'movie/'+E(u)+'/'+E(p)+'/'+x.stream_id+'.'+ext(x.container_extension,'mp4')}}),
  series:arr(L[5]).filter(function(x){return hasId(x.series_id)}).map(function(x){return{name:xstr(x.name,'Sin nombre'),logo:lg(x.cover),cat:sc.map[x.category_id]||'Otros',type:'series',sid:x.series_id,added:num(x.last_modified),rating:rt(x),year:yr(x),plot:xstr(x.plot),genre:xstr(x.genre)}}),
  catOrder:{live:lc.ord,movie:mc.ord,series:sc.ord},epg:''}}
/* episodios: acepta {"1":[...]} (lo normal), una lista plana, listas anidadas o vacío; ordena por número de episodio */
function mapEpisodes(d,base,u,p){var e={},E=encodeURIComponent,eps=d&&d.episodes,flat=[];
 var add=function(x,k){if(Array.isArray(x)){x.forEach(function(y){add(y,k)});return}if(!x||typeof x!=='object'||!hasId(x.id))return;flat.push({x:x,k:k})};
 if(Array.isArray(eps))add(eps,null);else if(eps&&typeof eps==='object')Object.keys(eps).forEach(function(k){add(eps[k],k)});
 flat.forEach(function(o,i){var x=o.x,s=x.season||o.k||1,n=+x.episode_num||0,inf=x.info&&typeof x.info==='object'?x.info:{},ex=String(x.container_extension||'mp4').replace(/^\./,'').replace(/[^A-Za-z0-9]/g,'')||'mp4';
  (e[s]=e[s]||[]).push({title:'E'+n+(x.title?' - '+x.title:''),full:x.title||'',n:n,dur:inf.duration||'',plot:inf.plot||'',_i:i,
   url:base+'/series/'+E(u)+'/'+E(p)+'/'+x.id+'.'+ex})});
 Object.keys(e).forEach(function(k){e[k].sort(function(a,b){return a.n-b.n||a._i-b._i})});return e}

/* ---------- Datos de la cuenta ---------- */
function describeAccount(a,now){
 var rows=[],warns=[],lvl='ok',c=a.counts||{};now=now||Date.now();
 var cnt='TV: '+(c.live||0)+'  ·  Películas: '+(c.movie||0)+'  ·  Series: '+(c.series||0);
 if(a.type==='X'){var ui=(a.info&&a.info.user_info)||{},si=(a.info&&a.info.server_info)||{};
  var st=String(ui.status||'').trim()||'Desconocido';rows.push(['Tipo de fuente','Xtream Codes']);rows.push(['Usuario',ui.username||a.user||'—']);
  rows.push(['Estado',st+(+ui.is_trial?'  (cuenta de PRUEBA)':'')]);
  var ex=+ui.exp_date;
  if(!ex||String(ui.exp_date)==='null')rows.push(['Vence','Sin vencimiento']);
  else{var ms=ex*1000,dl=Math.ceil((ms-now)/86400000);
   rows.push(['Vence',fmtDateTime(ms)+(dl>=0?'  ('+dl+(dl===1?' día restante)':' días restantes)'):'  (VENCIDA hace '+(-dl)+' días)')]);
   if(dl<0){lvl='bad';warns.push('La cuenta está vencida.')}else if(dl<=7){lvl=lvl==='bad'?lvl:'warn';warns.push('La cuenta vence en '+dl+(dl===1?' día.':' días.'))}}
  if(!/^active$/i.test(st)&&st!=='Desconocido'){lvl='bad';warns.push('Estado de la cuenta: '+st)}
  if(ui.created_at&&+ui.created_at)rows.push(['Creada',fmtDay(+ui.created_at*1000)]);
  var ac=ui.active_cons,mx=ui.max_connections;
  if(ac!=null||mx!=null){rows.push(['Conexiones','En uso: '+(ac==null?'?':ac)+'  ·  Máximo: '+(mx==null?'?':mx)]);
   if(+mx&&+ac>=+mx){lvl=lvl==='bad'?lvl:'warn';warns.push('Alcanzaste el máximo de conexiones simultáneas: otro dispositivo puede estar usando la cuenta.')}}
  var f=fmtList(ui.allowed_output_formats);if(f.length)rows.push(['Formatos permitidos',f.join(', ')]);
  if(ui.message)rows.push(['Mensaje del servidor',String(ui.message)]);
  var sv=(si.server_protocol||'http')+'://'+(si.url||hostOf(a.host))+(si.port?':'+si.port:'');rows.push(['Servidor',a.host?hostOf(a.host)+'  ('+sv+')':sv]);
  if(si.timezone)rows.push(['Zona horaria del servidor',si.timezone]);
  if(si.time_now)rows.push(['Hora del servidor',si.time_now])}
 else{rows.push(['Tipo de fuente','Lista M3U / M3U8']);rows.push(['Origen',maskUrl(a.url||'')]);rows.push(['Servidor',hostOf(a.url)]);
  rows.push(['Guía EPG',a.epg||'No indicada en la lista (puedes poner una en Ajustes)']);
  if(a.skipped)warns.push(a.skipped+' entradas ignoradas (protocolos rtmp/rtsp/udp que no se pueden reproducir aquí).');
  rows.push(['Cuenta','Las listas M3U no informan vencimiento ni conexiones; solo los paneles Xtream lo hacen.'])}
 rows.push(['Contenido',cnt]);
 return{rows:rows,warns:warns,level:lvl}}

/* ---------- Orden ---------- */
function sortItems(arr,mode){if(mode!=='az'&&mode!=='new')return arr;
 var d=arr.map(function(x,i){return{x:x,i:i,k:mode==='az'?searchNorm(x.name):0,a:x.added||0}});
 d.sort(function(p,q){if(mode==='az'){return p.k<q.k?-1:p.k>q.k?1:p.i-q.i}return q.a-p.a||p.i-q.i});
 return d.map(function(o){return o.x})}

/* ---------- EPG / otros ---------- */
function b64u(s){try{return decodeURIComponent(escape(atob(s)))}catch(e){return s||''}}
function xmlDate(s){var m=(s||'').match(/^(\d{4})(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)\s*([+-]\d{4})?/);if(!m)return 0;
 var t=Date.UTC(+m[1],m[2]-1,+m[3],+m[4],+m[5],+m[6]);if(m[7]){var o=(+m[7].slice(1,3)*60+ +m[7].slice(3,5))*60000;t-=(m[7][0]==='-'?-o:o)}return t}
function xmlText(s){return s.replace(/<!\[CDATA\[|\]\]>/g,'').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#39;|&apos;/g,"'").replace(/&amp;/g,'&').trim()}
function epgFromXml(xml,id,now){var re=new RegExp('<programme[^>]*channel="'+id.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'"[^>]*>[\\s\\S]*?<\\/programme>','g'),out=[],m;
 while((m=re.exec(xml))){var b=m[0],st=b.match(/start="([^"]+)"/),sp=b.match(/stop="([^"]+)"/),ti=b.match(/<title[^>]*>([\s\S]*?)<\/title>/);
  if(!st||!sp)continue;var s=xmlDate(st[1]),e=xmlDate(sp[1]);if(e>now)out.push({title:xmlText(ti?ti[1]:''),start:s,end:e})}
 return out.sort(function(a,b){return a.start-b.start}).slice(0,5)}
function parseVariants(txt,base){var L=[],ln=txt.split(/\r?\n/);ln.forEach(function(l,k){if(l.indexOf('#EXT-X-STREAM-INF')!==0)return;
 var rs=l.match(/RESOLUTION=\d+x(\d+)/),bw=l.match(/[^-]BANDWIDTH=(\d+)/),u=(ln[k+1]||'').trim();if(!u||u[0]==='#')return;
 L.push({h:rs?+rs[1]:0,bw:bw?+bw[1]:0,label:(rs?rs[1]+'p':'')+(bw?'  '+Math.round(bw[1]/1000)+' kbps':''),url:resolveUrl(base,u)})});
 return L.sort(function(a,b){return b.bw-a.bw})}
/* ¿la respuesta parece una lista M3U? (detecta páginas HTML de error/login) */
function looksLikeM3U(t){t=String(t||'').replace(/^﻿/,'').trim();return /^#EXTM3U/i.test(t)||/#EXTINF/i.test(t)||/#EXT-X-/i.test(t)}

/* ---------- v3: filas de inicio (Películas / Series) y guía ---------- */
function groupByCat(items,order){var by=Object.create(null),seen=[],names=[];
 items.forEach(function(i){if(!by[i.cat]){by[i.cat]=[];seen.push(i.cat)}by[i.cat].push(i)});
 (order||[]).forEach(function(n){if(by[n]&&names.indexOf(n)<0)names.push(n)});seen.forEach(function(n){if(names.indexOf(n)<0)names.push(n)});
 return{names:names,by:by}}
function buildHomeRows(items,order,hist,isFav,rown){var rows=[],g=groupByCat(items,order);
 if(hist&&hist.length)rows.push({t:'Continuar viendo',a:hist,hist:1});
 var fv=items.filter(isFav);if(fv.length)rows.push({t:'Favoritos',a:fv.slice(0,rown)});
 if(items.some(function(i){return i.added}))rows.push({t:'Agregado recientemente',a:sortItems(items,'new').slice(0,rown)});
 g.names.forEach(function(n){var a=g.by[n];rows.push({t:n,a:a.slice(0,rown),cat:n,total:a.length})});return rows}
function epgPct(s,e,now){if(!(e>s))return 0;return Math.max(0,Math.min(100,100*(now-s)/(e-s)))}

/* ---------- v4: fechas, cuenta resumida, búsqueda global, guía, ajustes ---------- */
var MESES=['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'];
var MESES_L=['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
var DIAS_L=['domingo','lunes','martes','miércoles','jueves','viernes','sábado'];
function fmtDateEs(ms){var d=new Date(ms);return d.getDate()+' '+MESES[d.getMonth()]+' '+d.getFullYear()}
function fmtDayLong(ms){var d=new Date(ms);return DIAS_L[d.getDay()]+' '+d.getDate()+' de '+MESES_L[d.getMonth()]}
function fmtClock(ms,h12){var d=new Date(ms),H=d.getHours(),m=pad2(d.getMinutes());if(!h12)return pad2(H)+':'+m;var s=H<12?'a. m.':'p. m.';H=H%12||12;return H+':'+m+' '+s}
function daysLeft(expSec,now){var e=+expSec;if(!e||!isFinite(e))return null;return Math.ceil((e*1000-(now||Date.now()))/86400000)}
/* resumen de la cuenta para la cabecera / perfil: {kind,text,short,level,days,conn,pct} */
function acctSummary(a,now){now=now||Date.now();
 if(!a)return{kind:'none',text:'Sin cuenta',short:'',level:'ok',days:null,conn:'',pct:0};
 if(a.type!=='X')return{kind:'M',text:'Lista M3U / M3U8',short:'Lista M3U',level:'ok',days:null,conn:'',pct:0};
 var ui=(a.info&&a.info.user_info)||{},st=String(ui.status||'').trim(),dl=daysLeft(ui.exp_date,now),lvl='ok',txt,sh;
 if(dl===null){txt='Sin fecha de vencimiento';sh='Sin vencimiento'}
 else if(dl<0){lvl='bad';txt='Vencida el '+fmtDateEs(+ui.exp_date*1000);sh='Vencida'}
 else{txt='Vence el '+fmtDateEs(+ui.exp_date*1000)+' ('+dl+(dl===1?' día':' días')+')';sh=dl+(dl===1?' día':' días');if(dl<=7)lvl='warn'}
 if(st&&!/^active$/i.test(st)){lvl='bad'}
 var ac=ui.active_cons,mx=ui.max_connections,conn=(ac!=null||mx!=null)?(ac==null?'?':ac)+' de '+(mx==null?'?':mx):'';
 if(+mx&&+ac>=+mx&&lvl==='ok')lvl='warn';
 var pct=dl===null?100:Math.max(0,Math.min(100,100*dl/365));
 return{kind:'X',text:txt,short:sh,level:lvl,days:dl,conn:conn,pct:pct,status:st,trial:!!+ui.is_trial}}
/* búsqueda: todas las palabras deben aparecer; gana lo que empieza igual */
function searchRank(n,q){var t=q.split(/\s+/).filter(Boolean),f=-1,k;if(!t.length)return 0;
 for(k=0;k<t.length;k++){if(n.indexOf(t[k])<0)return 0}
 f=n.indexOf(t[0]);var s=f===0?3:n.charAt(f-1)===' '?2:1;if(n.indexOf(q)>=0)s+=1;return s}
function searchLists(data,q,scope,hid,lim){q=searchNorm(String(q||'').trim());var out={live:[],movie:[],series:[]};if(!q)return out;
 ['live','movie','series'].forEach(function(m){if(scope&&scope!=='all'&&scope!==m)return;var r=[];
  (data[m]||[]).forEach(function(it,k){if(hid&&hid(it))return;var n=it._n||(it._n=searchNorm(it.name)),s=searchRank(n,q);if(s)r.push({it:it,s:s,k:k})});
  r.sort(function(a,b){return b.s-a.s||a.k-b.k});out[m]=r.slice(0,lim||60).map(function(o){return o.it})});return out}
/* guía: ahora / siguiente / porcentaje */
function nowNext(L,now){now=now||Date.now();var a=(L||[]).filter(function(x){return x.end>now});var c=a[0]||null,cur=c&&c.start<=now?c:null;
 return{now:cur,next:cur?(a[1]||null):c,list:a,pct:cur?epgPct(cur.start,cur.end,now):0}}
var ASPECTS=[['fit','Ajustar','contain'],['fill','Llenar pantalla','cover'],['str','Estirar','fill']];
function aspectOf(k){for(var i=0;i<ASPECTS.length;i++)if(ASPECTS[i][0]===k)return ASPECTS[i];return ASPECTS[0]}
function nextAspect(k){for(var i=0;i<ASPECTS.length;i++)if(ASPECTS[i][0]===k)return ASPECTS[(i+1)%ASPECTS.length][0];return ASPECTS[1][0]}
var SLEEPS=[0,15,30,45,60,90,120];
function sleepLabel(m){return m?m+' min':'Apagado'}
function nextSleep(m){var i=SLEEPS.indexOf(m);return SLEEPS[(i+1)%SLEEPS.length]}
function fmtLeft(ms){var s=Math.max(0,Math.ceil(ms/1000)),m=Math.floor(s/60);return m+':'+pad2(s%60)}
function hideSet(arr){var o=Object.create(null);(arr||[]).forEach(function(n){o[n]=1});return o}
function toggleIn(arr,v){arr=(arr||[]).slice();var i=arr.indexOf(v);if(i>=0)arr.splice(i,1);else arr.push(v);return arr}
/* entrada más reciente del historial (para el botón "Continuar") */
function newestHist(H){var best=null,k;for(k in H){if(!H.hasOwnProperty(k))continue;var e=H[k];if(!e||!e.ts)continue;if(!e.live&&!(e.t>10))continue;if(!best||e.ts>best.e.ts)best={k:k,e:e}}return best}
function initial(name){var s=String(name||'?').replace(/^[^A-Za-z0-9ÁÉÍÓÚÑáéíóúñ]+/,'');return(s.charAt(0)||'?').toUpperCase()}
