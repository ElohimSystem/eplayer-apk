package com.elohim.eplayer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/**
 * Avisos de E-Player: vencimiento de cuentas y recordatorios de programas.
 * La web los programa con AlarmManager (MainActivity.Bridge.scheduleAlert) y aquí se muestran.
 */
public class AlertReceiver extends BroadcastReceiver {
    static final String CH = "eplayer_alerts";

    @Override
    public void onReceive(Context ctx, Intent in) {
        try {
            String title = in.getStringExtra("t");
            String text = in.getStringExtra("x");
            int nid = in.getIntExtra("n", 1);
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel c = new NotificationChannel(CH, "Avisos de E-Player", NotificationManager.IMPORTANCE_DEFAULT);
                nm.createNotificationChannel(c);
            }
            Intent open = ctx.getPackageManager().getLaunchIntentForPackage(ctx.getPackageName());
            PendingIntent pi = null;
            if (open != null) {
                open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                pi = PendingIntent.getActivity(ctx, nid, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            }
            Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(ctx, CH) : new Notification.Builder(ctx);
            b.setSmallIcon(ctx.getApplicationInfo().icon)
                    .setContentTitle(title == null ? "E-Player" : title)
                    .setContentText(text == null ? "" : text)
                    .setAutoCancel(true);
            if (pi != null) b.setContentIntent(pi);
            nm.notify(nid, b.build());
        } catch (Throwable ignored) { }
    }
}
