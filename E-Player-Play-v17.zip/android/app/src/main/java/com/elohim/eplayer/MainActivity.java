package com.elohim.eplayer;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.os.Handler;
import android.os.Looper;
import com.google.android.play.core.appupdate.AppUpdateInfo;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.appupdate.AppUpdateOptions;
import com.google.android.play.core.install.InstallStateUpdatedListener;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.android.play.core.install.model.InstallStatus;
import com.google.android.play.core.install.model.UpdateAvailability;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.content.SharedPreferences;
import android.net.Uri;
import android.provider.Settings;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.ByteArrayInputStream;
import java.security.MessageDigest;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * E-Player (Android): carga la web de E-Player desde los assets y hace TODAS las peticiones de red
 * directamente desde el celular (sin Cloudflare ni proxy). Así el proveedor IPTV ve tu IP normal.
 */
public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String START = "https://" + HOST + "/app/index.html";

    private WebView web;
    private WebViewAssetLoader assets;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        assets = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/app/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);

        web.addJavascriptInterface(new Bridge(), "AndroidApp");
        web.setWebViewClient(new Client());
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);

        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT, new OnBackInvokedCallback() {
                        @Override
                        public void onBackInvoked() {
                            atras();
                        }
                    });
        }

        if (b != null) web.restoreState(b);
        else web.loadUrl(START);
        handleDest(getIntent());
        checkUpdate();
    }

    private static final int REQ_PLAYER = 4711;

    /* ---------------------------------------------------------------- atajos del ícono */
    private void handleDest(Intent in) {
        if (in == null) return;
        final String d = in.getStringExtra("dest");
        if (d == null || !d.matches("[a-z]{2,10}")) return;
        in.removeExtra("dest");
        Handler hh = new Handler(Looper.getMainLooper());
        hh.postDelayed(new Runnable() {
            @Override
            public void run() {
                js("window.goDest&&window.goDest('" + d + "')");
            }
        }, 1400);
        hh.postDelayed(new Runnable() {
            @Override
            public void run() {
                js("window.goDest&&window.goDest('" + d + "')");
            }
        }, 3500);
    }

    @Override
    protected void onNewIntent(Intent in) {
        super.onNewIntent(in);
        setIntent(in);
        handleDest(in);
    }

    /* ---------------------------------------------------------------- Google Play: actualizar y pedir calificación */
    private AppUpdateManager aum;
    private final InstallStateUpdatedListener updListener = new InstallStateUpdatedListener() {
        @Override
        public void onStateUpdate(com.google.android.play.core.install.InstallState state) {
            if (state.installStatus() == InstallStatus.DOWNLOADED) askRestart();
        }
    };

    private void askRestart() {
        try {
            new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                    .setTitle("Actualización lista")
                    .setMessage("Se descargó una versión nueva de E-Player. ¿Reiniciar la app para instalarla?")
                    .setPositiveButton("Reiniciar", new android.content.DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(android.content.DialogInterface d, int w) {
                            try {
                                aum.completeUpdate();
                            } catch (Throwable ignored) { }
                        }
                    })
                    .setNegativeButton("Más tarde", null)
                    .show();
        } catch (Throwable ignored) { }
    }

    /** Si hay una versión nueva en Google Play, la descarga en segundo plano y avisa al terminar. */
    private void checkUpdate() {
        checkUpdate(false);
    }

    /** manual = lo pidió el usuario desde Perfil: responde a la web con window.__updRes('none'|'avail'|'ready'|'err'). */
    private void checkUpdate(final boolean manual) {
        try {
            aum = AppUpdateManagerFactory.create(this);
            aum.getAppUpdateInfo().addOnSuccessListener(info -> {
                try {
                    if (info.installStatus() == InstallStatus.DOWNLOADED) {
                        if (manual) js("window.__updRes&&window.__updRes('ready')");
                        askRestart();
                    } else if (info.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE
                            && info.isUpdateTypeAllowed(AppUpdateType.FLEXIBLE)) {
                        aum.unregisterListener(updListener);
                        aum.registerListener(updListener);
                        aum.startUpdateFlowForResult(info, this,
                                AppUpdateOptions.newBuilder(AppUpdateType.FLEXIBLE).build(), REQ_UPDATE);
                        if (manual) js("window.__updRes&&window.__updRes('avail')");
                    } else if (manual) {
                        js("window.__updRes&&window.__updRes('none')");
                    }
                } catch (Throwable ignored) {
                    if (manual) js("window.__updRes&&window.__updRes('err')");
                }
            }).addOnFailureListener(e -> {
                if (manual) js("window.__updRes&&window.__updRes('err')");
            });
        } catch (Throwable ignored) {
            if (manual) js("window.__updRes&&window.__updRes('err')");
        }
    }

    private static final int REQ_UPDATE = 4712;

    private void launchReview() {
        try {
            final ReviewManager rm = ReviewManagerFactory.create(this);
            rm.requestReviewFlow().addOnCompleteListener(t -> {
                try {
                    if (t.isSuccessful()) rm.launchReviewFlow(MainActivity.this, t.getResult());
                } catch (Throwable ignored) { }
            });
        } catch (Throwable ignored) { }
    }

    /** El reproductor nativo se cerró: la web guarda dónde quedó el usuario. */
    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_PLAYER) {
            /* El reproductor nativo ya guardó el progreso; la web lo recoge con takeProgress(). */
            js("window.nativeDone&&window.nativeDone()");
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (web != null) web.saveState(out);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) immersive();
    }

    @SuppressWarnings("deprecation")
    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
        if (aum != null) {
            try {
                aum.getAppUpdateInfo().addOnSuccessListener(info -> {
                    try {
                        if (info.installStatus() == InstallStatus.DOWNLOADED) askRestart();
                    } catch (Throwable ignored) { }
                });
            } catch (Throwable ignored) { }
        }
    }

    @Override
    protected void onDestroy() {
        try {
            if (aum != null) aum.unregisterListener(updListener);
        } catch (Throwable ignored) { }
        if (web != null) {
            web.stopLoading();
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    /** Atrás: la propia web decide (historial interno); en el inicio, la app pasa a segundo plano. */
    @Override
    public void onBackPressed() {
        atras();
    }

    private void atras() {
        if (web != null && web.canGoBack()) web.goBack();
        else moveTaskToBack(true);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        /* Control remoto de TV: Esc/Retroceso lo maneja la web; aquí solo evitamos cerrar la app. */
        return super.onKeyDown(keyCode, event);
    }

    /* ---------------- puente JS -> Android ---------------- */
    void js(final String code) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (web != null) web.evaluateJavascript(code, null);
            }
        });
    }

    private class Bridge {
        /** Código estable del equipo (no cambia al reinstalar la app). */
        @JavascriptInterface
        public String deviceId() {
            try {
                String id = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
                if (id == null || id.length() == 0) {
                    SharedPreferences p = getSharedPreferences("ep", MODE_PRIVATE);
                    id = p.getString("id", null);
                    if (id == null) {
                        id = java.util.UUID.randomUUID().toString();
                        p.edit().putString("id", id).apply();
                    }
                }
                byte[] h = MessageDigest.getInstance("SHA-256").digest((id + "|eplayer").getBytes("UTF-8"));
                String a = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < 8; i++) {
                    if (i == 4) sb.append('-');
                    sb.append(a.charAt(h[i] & 31));
                }
                return sb.toString();
            } catch (Exception e) {
                return "ERRO-RID0";
            }
        }

        @JavascriptInterface
        @SuppressWarnings("deprecation")
        public int versionCode() {
            try {
                return getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
            } catch (Exception e) {
                return 0;
            }
        }

        /** Abre el reproductor nativo con una lista (película = 1, serie = capítulos). json = [{u,t,k,n,l,y,s,sn}]. */
        @JavascriptInterface
        public boolean playNativeList(final String json, final int index, final int startSec, final boolean live) {
            try {
                org.json.JSONArray a = new org.json.JSONArray(json);
                if (a.length() == 0) return false;
                for (int i = 0; i < a.length(); i++) {
                    String u = a.getJSONObject(i).optString("u", "");
                    if (!(u.startsWith("http://") || u.startsWith("https://"))) return false;
                }
            } catch (Throwable t) {
                return false;
            }
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent i = new Intent(MainActivity.this, PlayerActivity.class);
                    i.putExtra(PlayerActivity.X_ITEMS, json);
                    i.putExtra(PlayerActivity.X_INDEX, index);
                    i.putExtra(PlayerActivity.X_START, (long) startSec);
                    i.putExtra(PlayerActivity.X_LIVE, live);
                    startActivityForResult(i, REQ_PLAYER);
                }
            });
            return true;
        }

        /** TV en vivo: abre el reproductor nativo como respaldo. */
        @JavascriptInterface
        public boolean playNativeLive(String url, String title) {
            try {
                org.json.JSONArray a = new org.json.JSONArray();
                a.put(new org.json.JSONObject().put("u", url).put("t", title == null ? "" : title));
                return playNativeList(a.toString(), 0, 0, true);
            } catch (Throwable t) {
                return false;
            }
        }

        /** Progreso que guardó el reproductor nativo (por si la app se cerró mientras reproducía). Se borra al leerlo. */
        @JavascriptInterface
        public String takeProgress() {
            SharedPreferences p = getSharedPreferences("np", MODE_PRIVATE);
            String r = p.getString("prog", "{}");
            p.edit().remove("prog").apply();
            return r;
        }

        /** Ajustes del reproductor nativo que elige el usuario en Perfil (buffer y modo noche). */
        @JavascriptInterface
        public void setPref(String k, String v) {
            if (k == null || v == null) return;
            if (k.equals("eq") || k.equals("sub")) {
                getSharedPreferences("np", MODE_PRIVATE).edit().putString(k, v.length() > 40 ? "" : v).apply();
                return;
            }
            if (!(k.equals("buf") || k.equals("night"))) return;
            getSharedPreferences("np", MODE_PRIVATE).edit().putString(k, v.length() > 3 ? "" : v).apply();
        }

        /** Datos del equipo para el correo de comentarios. */
        @JavascriptInterface
        public String deviceInfo() {
            return "Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ") · " + Build.MANUFACTURER + " " + Build.MODEL;
        }

        /** Pide la calificación con el panel oficial de Google Play (Play decide si lo muestra). */
        @JavascriptInterface
        public void askReview() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    launchReview();
                }
            });
        }

        /** Abre un enlace en el navegador o el correo (solo http, https y mailto). */
        @JavascriptInterface
        public void openUrl(final String url) {
            if (url == null || !(url.startsWith("https://") || url.startsWith("http://") || url.startsWith("mailto:"))) return;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (Throwable t) {
                        Toast.makeText(MainActivity.this, "No se pudo abrir el enlace", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }

        /** Programa un aviso (vencimiento de cuenta o recordatorio de programa) para la hora indicada. */
        @JavascriptInterface
        public void scheduleAlert(final String id, final String whenMs, final String title, final String text) {
            try {
                long when = Long.parseLong(whenMs);
                int code = id.hashCode();
                Intent i = new Intent(MainActivity.this, AlertReceiver.class);
                i.setAction("com.elohim.eplayer.ALERT." + id);
                i.putExtra("t", title);
                i.putExtra("x", text);
                i.putExtra("n", code);
                android.app.PendingIntent pi = android.app.PendingIntent.getBroadcast(MainActivity.this, code, i,
                        android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE);
                android.app.AlarmManager am = (android.app.AlarmManager) MainActivity.this.getSystemService(android.content.Context.ALARM_SERVICE);
                if (am == null) return;
                if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, when, pi);
                else am.set(android.app.AlarmManager.RTC_WAKEUP, when, pi);
            } catch (Throwable ignored) { }
        }

        /** Cancela un aviso programado con scheduleAlert. */
        @JavascriptInterface
        public void cancelAlert(final String id) {
            try {
                Intent i = new Intent(MainActivity.this, AlertReceiver.class);
                i.setAction("com.elohim.eplayer.ALERT." + id);
                android.app.PendingIntent pi = android.app.PendingIntent.getBroadcast(MainActivity.this, id.hashCode(), i,
                        android.app.PendingIntent.FLAG_NO_CREATE | android.app.PendingIntent.FLAG_IMMUTABLE);
                if (pi == null) return;
                android.app.AlarmManager am = (android.app.AlarmManager) MainActivity.this.getSystemService(android.content.Context.ALARM_SERVICE);
                if (am != null) am.cancel(pi);
                pi.cancel();
            } catch (Throwable ignored) { }
        }

        /** Android 13+: pide permiso para mostrar avisos (solo la primera vez que se programa uno). */
        @JavascriptInterface
        public void requestNotifPerm() {
            MainActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (Build.VERSION.SDK_INT >= 33 && MainActivity.this.checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                            MainActivity.this.requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 4713);
                        }
                    } catch (Throwable ignored) { }
                }
            });
        }

        /** Enviar a otra pantalla: ofrece el enlace de video a las apps instaladas (VLC, Web Video Caster, etc.). */
        @JavascriptInterface
        public void sendExternal(final String url, final String title) {
            MainActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent i = new Intent(Intent.ACTION_VIEW);
                        i.setDataAndType(Uri.parse(url), "video/*");
                        i.putExtra("title", title == null ? "" : title);
                        MainActivity.this.startActivity(Intent.createChooser(i, "Enviar a otra pantalla"));
                    } catch (Throwable ignored) { }
                }
            });
        }

        /** Perfil > Buscar actualización: usa la actualización dentro de la app de Google Play. */
        @JavascriptInterface
        public void checkUpdateNow() {
            MainActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    checkUpdate(true);
                }
            });
        }

        /** Perfil > Compartir E-Player: abre el menú de compartir de Android con el texto recibido. */
        @JavascriptInterface
        public void shareText(final String text) {
            MainActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType("text/plain");
                        i.putExtra(Intent.EXTRA_TEXT, text);
                        MainActivity.this.startActivity(Intent.createChooser(i, "Compartir E-Player"));
                    } catch (Throwable ignored) { }
                }
            });
        }

        @JavascriptInterface
        public void installApk(final String url) {
            Updater.instalar(MainActivity.this, url);
        }

        @JavascriptInterface
        public void landscape(final boolean on) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    /* SOLO HORIZONTAL (regla del proyecto, ver LEEME-VERSIONES.md): NUNCA liberar la orientación, ni al salir del video. */
                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
                }
            });
        }
    }

    /* ---------------- WebViewClient: assets locales + red directa ---------------- */
    private class Client extends WebViewClient {

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
            Uri u = req.getUrl();
            String sch = u.getScheme() == null ? "" : u.getScheme();
            if (sch.equals("intent")) {
                try {
                    Intent i = Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME);
                    i.addCategory(Intent.CATEGORY_BROWSABLE);
                    i.setComponent(null);
                    i.setSelector(null);
                    startActivity(Intent.createChooser(i, "Abrir con…"));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this,
                            "No hay un reproductor instalado (instala VLC)", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "No se pudo abrir el enlace", Toast.LENGTH_LONG).show();
                }
                return true;
            }
            if (HOST.equals(u.getHost())) return false;
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, u));
            } catch (Exception ignored) { }
            return true;
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
            Uri u = req.getUrl();
            String sch = u.getScheme();
            if (HOST.equals(u.getHost())) return assets.shouldInterceptRequest(u);
            if ("http".equals(sch) || "https".equals(sch)) return direct(req);
            return null;
        }
    }

    private static final Pattern URI_ATTR = Pattern.compile("URI=\"([^\"]+)\"");

    /** Listas M3U y catálogos Xtream enormes: el panel puede tardar más de 60 s en generarlos. */
    private static int readTimeoutFor(String url) {
        String l = url == null ? "" : url.toLowerCase();
        boolean big = l.contains("player_api.php") || l.contains("get.php") || l.contains("xmltv")
                || (l.contains(".m3u") && !l.contains(".m3u8"));
        return big ? 180000 : 60000;
    }

    /** Cierra la conexión HTTP cuando el navegador termina de leer el cuerpo. */
    private static InputStream closing(InputStream in, final HttpURLConnection fc) {
        return new FilterInputStream(in) {
            @Override
            public void close() throws IOException {
                try {
                    super.close();
                } finally {
                    fc.disconnect();
                }
            }
        };
    }

    private static String absolute(String base, String rel) {
        try {
            return new URL(new URL(base), rel).toString();
        } catch (Exception e) {
            return rel;
        }
    }

    /** Petición directa desde el celular, con cabeceras CORS añadidas para que la web pueda leerla. */
    private WebResourceResponse direct(WebResourceRequest req) {
        Map<String, String> cors = new HashMap<String, String>();
        cors.put("Access-Control-Allow-Origin", "*");
        cors.put("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
        cors.put("Access-Control-Allow-Headers", "Range, Content-Type, Accept");
        cors.put("Access-Control-Expose-Headers", "Content-Length, Content-Range, Accept-Ranges, Content-Type");

        String method = req.getMethod() == null ? "GET" : req.getMethod().toUpperCase();
        if (method.equals("OPTIONS")) {
            return new WebResourceResponse("text/plain", "utf-8", 204, "No Content", cors,
                    new ByteArrayInputStream(new byte[0]));
        }
        if (!method.equals("GET") && !method.equals("HEAD")) {
            return new WebResourceResponse("text/plain", "utf-8", 405, "Method Not Allowed", cors,
                    new ByteArrayInputStream(new byte[0]));
        }

        Map<String, String> rh = req.getRequestHeaders();
        String range = null, ua = null, accept = null;
        for (Map.Entry<String, String> e : rh.entrySet()) {
            String k = e.getKey().toLowerCase();
            if (k.equals("range")) range = e.getValue();
            else if (k.equals("user-agent")) ua = e.getValue();
            else if (k.equals("accept")) accept = e.getValue();
        }
        if (ua == null) ua = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36";
        /* el User-Agent de WebView incluye "; wv" y "Version/4.0": algunos paneles lo rechazan */
        ua = ua.replace("; wv", "").replace("Version/4.0 ", "");

        String url = req.getUrl().toString();
        HttpURLConnection c = null;
        try {
            int hops = 0, code;
            while (true) {
                c = (HttpURLConnection) new URL(url).openConnection();
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(15000);
                c.setReadTimeout(readTimeoutFor(url));
                c.setRequestMethod(method);
                c.setRequestProperty("User-Agent", ua);
                c.setRequestProperty("Accept", accept == null ? "*/*" : accept);
                if (range != null) {
                    c.setRequestProperty("Range", range);
                    c.setRequestProperty("Accept-Encoding", "identity");
                }
                code = c.getResponseCode();
                if (code >= 300 && code < 400 && code != 304) {
                    String loc = c.getHeaderField("Location");
                    if (loc != null && hops++ < 8) {
                        url = absolute(url, loc);
                        c.disconnect();
                        continue;
                    }
                    code = 502;
                }
                break;
            }

            String ct = c.getContentType();
            String mime = "application/octet-stream", enc = null;
            if (ct != null) {
                String[] p = ct.split(";");
                if (p[0].trim().length() > 0) mime = p[0].trim();
                for (int i = 1; i < p.length; i++) {
                    String q = p[i].trim();
                    if (q.toLowerCase().startsWith("charset=")) enc = q.substring(8).replace("\"", "");
                }
            }
            if (enc == null && (mime.startsWith("text/") || mime.contains("json") || mime.contains("mpegurl"))) enc = "utf-8";

            Map<String, String> out = new HashMap<String, String>(cors);
            for (Map.Entry<String, List<String>> h : c.getHeaderFields().entrySet()) {
                if (h.getKey() == null || h.getValue() == null || h.getValue().isEmpty()) continue;
                String k = h.getKey().toLowerCase();
                if (k.equals("content-length") || k.equals("content-range") || k.equals("accept-ranges")
                        || k.equals("cache-control") || k.equals("last-modified") || k.equals("etag")) {
                    out.put(h.getKey(), h.getValue().get(h.getValue().size() - 1));
                }
            }

            String reason = c.getResponseMessage();
            if (reason == null || reason.length() == 0) reason = code < 400 ? "OK" : "Error";

            InputStream in;
            try {
                in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            } catch (IOException e) {
                in = c.getErrorStream();
            }
            if (in == null || method.equals("HEAD")) in = new ByteArrayInputStream(new byte[0]);

            /* listas HLS: se reescriben con URLs absolutas (si hubo redirección, el navegador las resolvería mal) */
            boolean isM3u8 = mime.toLowerCase().contains("mpegurl")
                    || url.toLowerCase().matches("^[^?#]*\\.m3u8([?#].*)?$");
            if (isM3u8 && code == 200 && method.equals("GET")) {
                /* Se lee como máximo 4 MB: una lista HLS real es pequeña. Si es más grande (lista IPTV de canales)
                   o no tiene etiquetas #EXT-X-, pasa tal cual, en streaming y sin cargarla en memoria. */
                final int LIMIT = 4 * 1024 * 1024;
                java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n;
                boolean tooBig = false;
                while ((n = in.read(buf)) > 0) {
                    bo.write(buf, 0, n);
                    if (bo.size() > LIMIT) {
                        tooBig = true;
                        break;
                    }
                }
                byte[] head = bo.toByteArray();
                boolean hls = !tooBig && new String(head, StandardCharsets.ISO_8859_1).contains("#EXT-X-");
                if (!hls) {
                    InputStream rest = tooBig ? new java.io.SequenceInputStream(new ByteArrayInputStream(head), in)
                            : new ByteArrayInputStream(head);
                    if (!tooBig) {
                        in.close();
                        c.disconnect();
                        return new WebResourceResponse(mime, enc, code, reason, out, rest);
                    }
                    return new WebResourceResponse(mime, enc, code, reason, out, closing(rest, c));
                }
                in.close();
                c.disconnect();
                String text = new String(head, StandardCharsets.UTF_8);
                StringBuilder sb = new StringBuilder();
                for (String line : text.split("\\r?\\n", -1)) {
                    String t = line.trim();
                    if (t.length() == 0) {
                        sb.append(line);
                    } else if (t.charAt(0) == '#') {
                        Matcher m = URI_ATTR.matcher(line);
                        StringBuffer lb = new StringBuffer();
                        while (m.find()) {
                            m.appendReplacement(lb, Matcher.quoteReplacement("URI=\"" + absolute(url, m.group(1)) + "\""));
                        }
                        m.appendTail(lb);
                        sb.append(lb);
                    } else {
                        sb.append(absolute(url, t));
                    }
                    sb.append('\n');
                }
                byte[] data = sb.toString().getBytes(StandardCharsets.UTF_8);
                out.remove("Content-Length");
                out.remove("content-length");
                out.put("Cache-Control", "no-store");
                return new WebResourceResponse("application/vnd.apple.mpegurl", "utf-8", 200, "OK", out,
                        new ByteArrayInputStream(data));
            }

            return new WebResourceResponse(mime, enc, code, reason, out, closing(in, c));
        } catch (Throwable e) {
            if (c != null) c.disconnect();
            String msg = "No se pudo conectar: " + (e.getMessage() == null ? e.toString() : e.getMessage());
            return new WebResourceResponse("text/plain", "utf-8", 502, "Bad Gateway", cors,
                    new ByteArrayInputStream(msg.getBytes(StandardCharsets.UTF_8)));
        }
    }
}
