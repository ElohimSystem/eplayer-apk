# El puente JavaScript <-> Android se llama por nombre desde la web: no se puede renombrar.
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
-keep class com.elohim.eplayer.MainActivity$Bridge { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
# Avisos de librerías opcionales que Media3/Guava no necesitan en ejecución
-dontwarn org.checkerframework.**
-dontwarn javax.annotation.**
-dontwarn com.google.errorprone.annotations.**
-dontwarn org.codehaus.mojo.animal_sniffer.**
