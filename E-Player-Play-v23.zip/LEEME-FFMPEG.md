# FFmpeg para audio (AC3 / E-AC3 / DTS / TrueHD) — v23

## Qué hace
Media3 reproduce con los decodificadores **del equipo**. Muchos TV box económicos no traen AC3/DTS y la película
sale **sin sonido**. Con la extensión FFmpeg, si el equipo no puede decodificar un audio, lo decodifica la app
**por software**. Los decodificadores del equipo siguen siendo los primeros (`EXTENSION_RENDERER_MODE_ON`).

## Lo que NO hace
- No arregla video que el equipo no soporte (HEVC 10 bits, 4K en chips débiles). FFmpeg aquí es **solo audio**.
- No cambia nada en LG webOS (ahí el reproductor es el de la TV).

## Cómo activarlo (desde el celular, como el resto del proyecto)
1. GitHub → Add file → Create new file → `.github/workflows/ffmpeg-media3.yml` → pegar el contenido → Commit.
2. Actions → **FFmpeg para Media3 (genera el .aar)** → Run workflow (con «Guardar en el repositorio» activado).
3. Al terminar en verde aparece `android/app/libs/media3-decoder-ffmpeg.aar` y la licencia LGPL de FFmpeg.
4. Compilar la app como siempre. **Sin el .aar la app compila y funciona exactamente como antes** (la extensión es opcional).

> El workflow está escrito según la guía oficial de Media3 pero **todavía no se ha ejecutado**. Si falla, el error
> dice en qué paso; los pasos imprimen los datos para corregirlo. No hay que cambiar nada en la app.
> Si tu flujo «desempaquetar» reemplaza carpetas completas al subir el zip, verifica que no borre `android/app/libs/`.

## Cómo comprobar que funciona
En una película con audio AC3/DTS que antes no sonaba: si falla, toca **Copiar diagnóstico**. Debe decir
`FFmpeg (audio por software): sí`. Si el audio suena, el campo `aDec` del registro debería contener «ffmpeg».

## Licencia (importante)
FFmpeg se compila **solo con LGPL** (el workflow se detiene si detecta GPL o «nonfree»). Para distribuir en Play:
incluir el aviso de FFmpeg y el texto de la licencia en «Acerca de» / avisos legales, y no publicar ni enlazar
versiones modificadas sin cumplir LGPL. Conviene una revisión legal antes de publicar.

## Diagnóstico de fallas (nuevo)
Cada error de reproducción y cada audio no soportado se guarda **solo en el equipo** (últimas 40): equipo, Android,
códec/decodificador de audio y video, código de error. **Nunca guarda enlaces** (llevan usuario y contraseña).
El botón «Copiar diagnóstico» arma un informe para pegar a soporte. Esto da los datos para decidir qué arreglar
después, en vez de adivinar.
