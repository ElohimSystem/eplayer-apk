/* npm start -> http://localhost:8080  (sirve public/ con un proxy local propio (también `PORT=3000 npm start`); sin comprobación de origen) */
const http=require('http'),fs=require('fs'),path=require('path');
process.env.PROXY_OPEN=process.env.PROXY_OPEN||'1';
let handler;try{handler=require('../opcional-cloud-functions/proxy').handler}catch(e){handler=require('./local-proxy').handler}
const ROOT=path.join(__dirname,'..','public'),PORT=+process.env.PORT||8080;
const MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png','.webmanifest':'application/manifest+json'};
http.createServer((req,res)=>{
 const u=new URL(req.url,'http://x');if(u.pathname==='/proxy')return handler(req,res);
 /* en local se usa SIEMPRE el proxy de este servidor (el Worker de producción puede rechazar el origen localhost) */
 if(u.pathname==='/config.js'){res.writeHead(200,{'Content-Type':'text/javascript; charset=utf-8','Cache-Control':'no-store'});return res.end('window.IPTV_PROXY=true;window.IPTV_PROXY_URL="";\n')}
 let rel;try{rel=decodeURIComponent(u.pathname)}catch(e){res.writeHead(400);return res.end('bad')}
 const f=path.normalize(path.join(ROOT,rel==='/'?'index.html':rel));
 if(f!==ROOT&&!f.startsWith(ROOT+path.sep)){res.writeHead(403);return res.end('403')}
 fs.readFile(f,(e,d)=>{if(e){res.writeHead(404);return res.end('404 (¿ejecutaste npm run build?)')}res.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream','Cache-Control':'no-store'});res.end(d)})
}).listen(PORT,'127.0.0.1',()=>console.log('ElohimPlayer PWA (local): http://localhost:'+PORT));
