/* Proxy local mínimo para probar la web en tu equipo (hace lo mismo que el Worker de Cloudflare, sin comprobar el origen).
   Lo usa `npm start` cuando no existe la carpeta opcional «opcional-cloud-functions». */
const http=require('http'),https=require('https');
const CORS={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'*','Access-Control-Expose-Headers':'*'};
function handler(req,res){
 const u=new URL(req.url,'http://x'),t=u.searchParams.get('url');
 if(req.method==='OPTIONS'){res.writeHead(204,CORS);return res.end()}
 if(!t||!/^https?:\/\//i.test(t)){res.writeHead(400,CORS);return res.end('proxy: falta ?url=http(s)://...')}
 let hops=0;
 const go=url=>{const L=new URL(url),lib=L.protocol==='https:'?https:http,hdr={'User-Agent':'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36','Accept':'*/*'};
  if(req.headers.range)hdr.Range=req.headers.range;
  const r=lib.request({protocol:L.protocol,hostname:L.hostname,port:L.port||undefined,path:L.pathname+L.search,method:'GET',headers:hdr,rejectUnauthorized:false},p=>{
   if([301,302,303,307,308].indexOf(p.statusCode)>=0&&p.headers.location&&hops++<5){p.resume();return go(new URL(p.headers.location,L).toString())}
   const h=Object.assign({},CORS);['content-type','content-length','content-range','accept-ranges'].forEach(k=>{if(p.headers[k])h[k]=p.headers[k]});
   res.writeHead(p.statusCode,h);p.pipe(res);res.on('close',()=>p.destroy())});
  r.on('error',e=>{if(!res.headersSent)res.writeHead(502,CORS);res.end('proxy: '+e.message)});
  r.setTimeout(30000,()=>r.destroy(new Error('tiempo agotado')));r.end()};
 go(t)}
module.exports={handler};
