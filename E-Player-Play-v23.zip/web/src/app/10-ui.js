/* ===== v4 — navegación, tarjetas, Inicio, Favoritos y listado (TV / Películas / Series) ===== */
const fmtN=n=>String(n).replace(/\B(?=(\d{3})+(?!\d))/g,'.');
const MODES=[['live','TV en vivo'],['movie','Películas'],['series','Series']],SORTS=[['orig','Original'],['az','A–Z'],['new','Recientes']],ROWN=18;
const defCat=m=>m==='live'?'*':'__home';
const catLabel=(c,m)=>c==='*'?(m==='live'?'Todos':'Todas'):c==='__fav'?'Favoritos':c==='__hist'?(m==='live'?'Vistos recientemente':'Continuar viendo'):c==='__home'?'Inicio':c;
const isBrowse=p=>p==='live'||p==='movie'||p==='series';
const NAVS=[['home','Inicio','home'],['live','TV en vivo','tv'],['movie','Películas','film'],['series','Series','series'],['favs','Favoritos','star'],['profile','Perfil','user']];
let pvT=0,fiT=0,clkT=0,scT=0,fcT=0,piT=0;

/* ---------- navegación ---------- */
function buildNav(){
 $$('#nav button').forEach(b=>{const n=NAVS.filter(x=>x[0]===b.getAttribute('data-p'))[0];setIc(b,n[2],n[1]);b.onclick=()=>showPage(n[0])});
 const bn=$('#bn');bn.textContent='';
 [['home','Inicio','home'],['live','TV','tv'],['movie','Películas','film'],['series','Series','series'],['profile','Perfil','user']].forEach(n=>{const b=h('button','f');b.setAttribute('data-p',n[0]);setIc(b,n[2],n[1]);b.onclick=()=>showPage(n[0]);bn.appendChild(b)});
 setIc($('#srb'),'search');$('#srb').onclick=()=>openSearch(window.VIP&&VIP.on()?'all':(isBrowse(S.page)?S.page:'all'));
 setIc($('#pvx'),'close');setIc($('#sortb'),'sliders')}
function markNav(){$$('#nav button,#bn button').forEach(b=>b.classList.toggle('on',b.getAttribute('data-p')===S.page));window.FX&&FX.mark(S.page)}
function updClock(){const n=Date.now();$('#clk').textContent=hm(n)}
function catExists(m,c){if(c==='*'||c==='__home'||c==='__fav'||c==='__hist')return true;return catInfo(m).names.indexOf(c)>=0}
function showPage(p,o){o=o||{};
 const fxc=window.FX?FX.before(S.page,p):null;
 if(S.pv&&p!=='live')stop();
 S.page=p;const br=isBrowse(p);
 ['home','browse','favs','profile'].forEach(k=>$('#p-'+k).classList.toggle('hidden',k!==(br?'browse':p)));
 $('#app').setAttribute('data-page',p);markNav();
 if(br){S.mode=p;const lc=CFG.lc[p];S.cat=o.cat||(lc&&catExists(p,lc)?lc:defCat(p));S.q='';refreshBrowse()}
 else if(p==='home')renderStart();else if(p==='favs')renderFavs();else renderProfile();
 if(fxc)FX.after(fxc);
 if(o.focus)focusFirst()}
function focusFirst(){if(TOUCH)return;const pg=$('#p-'+(isBrowse(S.page)?'browse':S.page));const f=pg&&$$('.f',pg).filter(e=>e.offsetWidth>0)[0];if(f){S.skipPv=true;f.focus();S.skipPv=false}}
function rerender(){const fi=$$('.f',$('#p-'+(isBrowse(S.page)?'browse':S.page))).indexOf(document.activeElement);
 if(isBrowse(S.page))refreshBrowse();else if(S.page==='home')renderStart();else if(S.page==='favs')renderFavs();else renderProfile(fi);}

/* ---------- tarjetas ---------- */
/* las imágenes se piden/decodifican solo cuando están cerca de la pantalla (antes se cargaban todas de golpe) */
const IOB=window.IntersectionObserver?new IntersectionObserver(es=>{es.forEach(e=>{if(e.isIntersecting){const im=e.target;IOB.unobserve(im);if(im._s){im.src=im._s;im._s=null}}})},{rootMargin:'500px 700px'}):null;
function picOf(i,cls){const pc=h('div',cls||'pic');pc.appendChild(h('i','ph',initial(i.name)));if(i.logo){const im=h('img');im.decoding='async';im.onerror=()=>im.remove();if(IOB){im._s=mx(i.logo);IOB.observe(im)}else im.src=mx(i.logo);pc.appendChild(im)}return pc}
function starEl(i){const s=h('b','star'+(isFav(i)?' on':''));s.innerHTML=ic(isFav(i)?'starf':'star');s.onclick=ev=>{ev.stopPropagation();toggleFav(i);refStar(i)};return s}
function toggleFav(i){const k=fk(i);if(FAVS[k])delete FAVS[k];else FAVS[k]=1;lsSet('iptv_fav',FAVS);updFav();updPvFav()}
function updFav(){const e=document.querySelector('#cats [data-c=__fav]');if(e&&S.data[S.mode]){const n=favItems(S.mode).length;e.querySelector('b').textContent=n}}
function refStar(i){$$('.card').forEach(c=>{if(c._i===i){const s=c.querySelector('.star');if(s){s.classList.toggle('on',isFav(i));s.innerHTML=ic(isFav(i)?'starf':'star')}}})}
function fillNow(el,i,sub,bar){epgLazy(el,i,L=>{const n=nowNext(L);if(sub)sub.textContent=n.now?n.now.title:n.next?'Luego: '+n.next.title:'';if(bar){bar.style.width=n.pct+'%';bar.parentNode.classList.toggle('on',!!n.now)}})}
function mkCard(i,n,o){o=o||{};const live=i.type==='live',d=h('div','card f');d.tabIndex=0;d._i=i;d._k=n;
 if(live&&o.row){d.classList.add('lv');d.appendChild(picOf(i));d.appendChild(h('span','t',i.name));const np=h('small','np');d.appendChild(np);fillNow(d,i,np,null)}
 else if(live){d.classList.add('ch');d.appendChild(h('b','no',String(n+1)));d.appendChild(picOf(i));
  const nm=h('div','nm'),np=h('small','np'),g=h('u','pgb'),s=h('s');g.appendChild(s);nm.appendChild(h('span','t',i.name));nm.appendChild(np);nm.appendChild(g);d.appendChild(nm);d.appendChild(starEl(i));fillNow(d,i,np,s);
  if(S.pvItem===i)d.classList.add('pvon')}
 else{d.classList.add('pc');const pc=picOf(i),he=HIST[i.url],pr=o.hist&&he&&!he.live&&he.t>10?he:null;
  d.appendChild(pc);if(+i.rating)d.appendChild(h('em','rt',String(Math.round(i.rating*10)/10)));
  d.appendChild(h('span','t',i.name));if(pr)d.appendChild(h('small','np',fmtDur(pr.t)+(pr.d?' de '+fmtDur(pr.d):'')));
  if(pr&&pr.d){const g=h('u','pgb'),s=h('s');s.style.width=Math.min(100,100*pr.t/pr.d)+'%';g.appendChild(s);d.appendChild(g)}
  if(i.type!=='ep')d.appendChild(starEl(i))}
 d.onclick=()=>pickItem(i,o);if(S.combo&&i.src!=null)d.appendChild(VIPX.badge(i.src));return d}
function mkRow(r){const s=h('section','rw'),rs=h('div','rs');const t=h('h3','',r.t);if(r.total)t.appendChild(h('small','',' '+fmtN(r.total)));s.appendChild(t);s.appendChild(rs);
 r.a.forEach((i,k)=>rs.appendChild(mkCard(i,k,{hist:r.hist,row:true})));
 if(r.more&&(r.total||0)>r.a.length||r.more&&r.force){const m=h('div','card f more');m.tabIndex=0;m.appendChild(h('span','','Ver todo'));m.appendChild(h('small','',r.total?fmtN(r.total)+' en total':''));m.onclick=r.more;rs.appendChild(m)}return s}
function emptyBox(title,text,btnT,fn){const b=h('div','empty');b.appendChild(h('h3','',title));if(text)b.appendChild(h('p','',text));if(btnT){const x=h('button','f go',btnT);x.onclick=fn;b.appendChild(x)}return b}

/* ---------- Inicio ---------- */
function acctCard(){if(S.acct&&S.acct.combined&&window.VIPX)return VIPX.comboCard();const A=acctSummary(S.acct,Date.now()),c=h('div','acard f');c.tabIndex=0;
 const a=S.acct||{},name=a.type==='X'?a.user:hostOf(a.url||'');
 const top=h('div','at');top.appendChild(h('b','',name||'Cuenta'));
 if(A.kind==='X'){const st=A.level==='bad'?(A.days!==null&&A.days<0?'Vencida':A.status||'Revisar'):A.level==='warn'?'Por vencer':'Activa';top.appendChild(h('span','pill '+A.level,A.trial?st+' · prueba':st))}
 c.appendChild(top);c.appendChild(h('p','ax',A.text));
 if(A.kind==='X'){const g=h('u','pgb lv-'+A.level),s=h('s');s.style.width=A.pct+'%';g.appendChild(s);c.appendChild(g)}
 const ct=a.counts||{};c.appendChild(h('p','dm',(A.conn?'Conexiones en uso: '+A.conn+'  ·  ':'')+fmtN(ct.live||0)+' canales · '+fmtN(ct.movie||0)+' películas · '+fmtN(ct.series||0)+' series'));
 c.onclick=()=>showPage('profile',{focus:true});return c}
function resumeCard(){const nh=newestHist(HIST),c=h('div','rcard f');c.tabIndex=0;
 if(!nh){const art=h('div','rart');art.innerHTML=ic('play');c.appendChild(art);const tx=h('div','rtx');tx.appendChild(h('small','','Bienvenido'));tx.appendChild(h('h2','','Empieza por un canal'));tx.appendChild(h('p','dm','Cuando veas algo, aquí aparece para seguir justo donde quedaste.'));
  const go=h('span','rgo');setIc(go,'tv','Ver TV en vivo');tx.appendChild(go);c.appendChild(tx);c.onclick=()=>showPage('live',{focus:true});return c}
 const e=Object.assign({url:nh.k},nh.e),it=histEntryItem(e),live=!!e.live;
 const art=picOf(it,'rart'+(live?' lv':''));c.appendChild(art);
 const tx=h('div','rtx');tx.appendChild(h('small','',live?'Último canal':e.type==='ep'?'Seguir con tu serie':'Seguir viendo'));tx.appendChild(h('h2','',it.name));
 const sub=h('p','dm',live?(it.cat&&it.cat!=='Recientes'?it.cat:'En vivo'):'Quedan '+Math.max(1,Math.round(((e.d||0)-(e.t||0))/60))+' min  ·  vas en '+fmtDur(e.t||0));tx.appendChild(sub);
 if(live){const np=h('p','np');tx.appendChild(np);epgLazy(c,it,L=>{const n=nowNext(L);np.textContent=n.now?'Ahora: '+n.now.title:''})}
 else if(e.d){const g=h('u','pgb'),s=h('s');s.style.width=Math.min(100,100*e.t/e.d)+'%';g.appendChild(s);tx.appendChild(g)}
 const go=h('span','rgo');setIc(go,'play','Reanudar');tx.appendChild(go);c.appendChild(tx);
 c.onclick=()=>{S.last=c;if(live)playLiveFrom(it);else if(e.type==='ep'&&e.sid){resumeSeries(e.sid,e.url).then(ok=>{if(!ok)openItem(it)})}else{S.cur=it;S.epq=null;S.zap=-1;play(it.url,it.name,false,null,playMeta(it,e.type==='ep'?'ep':'movie'))}};return c}
function renderStart(){const box=$('#hm');box.textContent='';box.scrollTop=0;
 const g=h('div','greet'),n=Date.now();g.appendChild(h('h1','',(new Date(n).getHours()<12?'Buenos días':new Date(n).getHours()<20?'Buenas tardes':'Buenas noches')));{const dl=fmtDayLong(n);g.appendChild(h('p','dm',dl.charAt(0).toUpperCase()+dl.slice(1)))}box.appendChild(g);
 const hero=h('div','hero');hero.appendChild(resumeCard());hero.appendChild(acctCard());box.appendChild(hero);
 const tl=h('div','tiles');
 [['live','tv','TV en vivo',S.data.live.length,'canales'],['movie','film','Películas',S.data.movie.length,'títulos'],['series','series','Series',S.data.series.length,'series']].forEach(t=>{
  if(!t[3])return;const d=h('div','tile f t-'+t[0]);d.tabIndex=0;const i=h('span','ti'),bd=h('div','tl-body'),fc=h('i','tl-face');i.innerHTML=ic(t[1]);fc.appendChild(h('i','tl-sp'));
  bd.appendChild(h('i','tl-ed'));bd.appendChild(fc);bd.appendChild(i);bd.appendChild(h('b','',t[2]));bd.appendChild(h('small','',fmtN(t[3])+' '+t[4]));d.appendChild(h('i','tl-sh'));d.appendChild(bd);d.onclick=()=>{window.FX&&FX.dive(d);showPage(t[0],{focus:true})};tl.appendChild(d)});
 box.appendChild(tl);
 const rows=[],hv=vodHist().filter(i=>!hidden(i)),hl=histItems('live').filter(i=>!hidden(i)),fav=favItems('live').slice(0,8).concat(favItems('movie').slice(0,8),favItems('series').slice(0,8));
 if(hv.length)rows.push({t:'Continuar viendo',a:hv.slice(0,ROWN),hist:1});
 if(hl.length)rows.push({t:'Canales recientes',a:hl.slice(0,ROWN)});
 if(fav.length)rows.push({t:'Tus favoritos',a:fav,more:()=>showPage('favs',{focus:true}),force:1});const lt=window.VIPX&&VIP.on()?VIPX.laterItems():[];if(lt.length)rows.push({t:'Ver más tarde',a:lt.slice(0,ROWN),force:1});
 const mv=S.data.movie.filter(i=>!hidden(i));if(mv.some(i=>i.added))rows.push({t:'Películas agregadas hace poco',a:sortItems(mv,'new').slice(0,ROWN),total:mv.length,more:()=>showPage('movie',{focus:true})});
 const sr=S.data.series.filter(i=>!hidden(i));if(sr.some(i=>i.added))rows.push({t:'Series actualizadas',a:sortItems(sr,'new').slice(0,ROWN),total:sr.length,more:()=>showPage('series',{focus:true})});
 rows.forEach(r=>box.appendChild(mkRow(r)));box.appendChild(h('p','ft',APPT));window.FX&&FX.bind(box)}

/* ---------- Favoritos ---------- */
function renderFavs(){const box=$('#fv');box.textContent='';box.scrollTop=0;box.appendChild(h('h1','pgt','Favoritos'));
 const L=[['live','Canales'],['movie','Películas'],['series','Series']];let any=false;
 L.forEach(x=>{const a=favItems(x[0]);if(!a.length)return;any=true;box.appendChild(mkRow({t:x[1],a:a.slice(0,ROWN),total:a.length,more:()=>showPage(x[0],{cat:'__fav',focus:true})}))});
 if(!any)box.appendChild(emptyBox('Aún no tienes favoritos',TOUCH?'Toca la estrella de un canal, película o serie para guardarlo aquí.':'Mantén pulsado OK sobre un canal, película o serie (o usa el botón amarillo) para guardarlo aquí.','Explorar TV en vivo',()=>showPage('live',{focus:true})))}

/* ---------- Listado ---------- */
function updateTabs(){window.VIPX&&VIPX.srcBtn();const s=SORTS.filter(x=>x[0]===CFG.sort)[0]||SORTS[0];setIc($('#sortb'),'sliders','Orden: '+s[1]);
 const pb=$('#p-browse');['live','movie','series'].forEach(m=>pb.classList.toggle('m-'+m,m===S.mode))}
function catInfo(m){const all=S.data[m].filter(i=>!hidden(i)),g=groupByCat(all,S.data.catOrder[m]);let names=g.names;
 if(CFG.sort==='az')names=names.slice().sort((a,b)=>{a=searchNorm(a);b=searchNorm(b);return a<b?-1:a>b?1:0});return{all:all,names:names,by:g.by}}
function renderCats(){
 const I=catInfo(S.mode),hc=histItems(S.mode).filter(i=>!hidden(i)).length,c=$('#cats');c.textContent='';const first=[];
 if(S.mode!=='live')first.push(['__home','Inicio',0]);first.push(['*',catLabel('*',S.mode),I.all.length],['__fav','Favoritos',I.all.filter(isFav).length]);
 if(hc)first.push(['__hist',catLabel('__hist',S.mode),hc]);
 first.concat(I.names.map(k=>[k,k,I.by[k].length])).forEach(a=>{const d=h('div','f cat'+(S.cat===a[0]?' on':'')),t=h('span','',a[1]);d.appendChild(t);if(a[0]!=='__home')d.appendChild(h('b','',String(a[2])));d.tabIndex=0;d.setAttribute('data-c',a[0]);d.onclick=()=>setCat(a[0]);c.appendChild(d)})}
function setCat(k){S.cat=k;CFG.lc[S.mode]=k;saveCfg();$$('#cats .cat').forEach(x=>x.classList.toggle('on',x.getAttribute('data-c')===k));renderList();updBt()}
function filterItems(cat,q,mode){mode=mode||S.mode;q=searchNorm((q||'').trim());let a;
 if(!q&&cat==='__hist')a=histItems(mode).filter(i=>!hidden(i));
 else a=sortItems(S.data[mode].filter(i=>!hidden(i)&&(S.srcF==null||i.src===S.srcF)&&(q?(i._n||(i._n=searchNorm(i.name))).indexOf(q)>=0:(cat==='*'||cat==='__home'||(cat==='__fav'?isFav(i):i.cat===cat)))),CFG.sort);
 return a}
function updBt(){const n=S.home?0:S.view.length;$('#bt-t').textContent=catLabel(S.cat,S.mode)+(S.cat==='__home'?'':'  ·  '+fmtN(n));$('#sortb').classList.toggle('hidden',S.cat==='__home'||S.cat==='__hist')}
function refreshBrowse(){updateTabs();renderCats();renderList();updBt();placeDock();setPvIdle()}
function renderList(){
 const l=$('#list');l.textContent='';l.scrollTop=0;S.home=null;
 if(S.mode!=='live'&&S.cat==='__home'){l.className='home sc';renderVodHome();updBt();return}
 const a=filterItems(S.cat,'');S.view=a;S.shown=0;l.className=(S.mode==='live'?'live':'grid')+' sc';addCards();
 if(!a.length){const fav=S.cat==='__fav';l.appendChild(emptyBox(fav?'Sin favoritos aquí':'No hay nada para mostrar',fav?(TOUCH?'Toca la estrella de un elemento para guardarlo.':'Mantén pulsado OK sobre un elemento (o el botón amarillo) para guardarlo.'):(S.data[S.mode].length?'Prueba otra categoría o revisa las categorías ocultas en Perfil.':'Esta cuenta o lista no tiene contenido en esta sección.')))}
 showFi(null);epgSoon()}
function addCards(){const l=$('#list'),a=S.view,to=Math.min(a.length,S.shown+PAGE),hist=S.cat==='__hist';for(let k=S.shown;k<to;k++)l.appendChild(mkCard(a[k],k,{hist:hist}));S.shown=to}
function renderVodHome(){const m=S.mode,I=catInfo(m),hist=histItems(m).filter(i=>!hidden(i));S.view=[];
 const rows=buildHomeRows(I.all,I.names,hist,isFav,ROWN);rows.forEach(r=>{if(r.cat){const c=r.cat;r.more=()=>setCat(c)}});S.home={rows:rows,n:0};moreRows(3);
 if(!rows.length)$('#list').appendChild(emptyBox('Sin contenido','Esta sección está vacía o todas sus categorías están ocultas.'));{const c=$('#list .card');showFi(c&&c._i||null)}}
function moreRows(k){const H=S.home,l=$('#list');if(!H)return;const to=Math.min(H.rows.length,H.n+k);for(;H.n<to;H.n++)l.appendChild(mkRow(H.rows[H.n]))}
function maybeMore(c){const l=$('#list');
 if(S.home){const rw=c.closest('.rw'),rows=l.querySelectorAll('.rw'),n=rows.length;if(rw&&(rows[n-1]===rw||rows[n-2]===rw))moreRows(3)}
 else if(S.view&&c._k!=null&&S.shown<S.view.length&&c._k>=S.shown-12)addCards()}
/* carga más al desplazarse con el dedo / rueda, y pide la guía de lo visible */
function epgSoon(){clearTimeout(scT);scT=setTimeout(()=>{$$('#list .card.ch').forEach(c=>{if(c._i&&!c._g){const r=c.getBoundingClientRect(),b=$('#list').getBoundingClientRect();if(r.bottom>b.top-200&&r.top<b.bottom+300){c._g=1;const np=c.querySelector('.np'),s=c.querySelector('.pgb s');fillNow(c,c._i,np,s)}}})},120)}
$('#list').addEventListener('scroll',()=>{const l=$('#list');if(S.view&&S.shown<S.view.length&&l.scrollTop+l.clientHeight>l.scrollHeight-900)addCards();if(S.home&&l.scrollTop+l.clientHeight>l.scrollHeight-600)moreRows(2);epgSoon()});
$('#list').addEventListener('focusin',e=>{const t=e.target,c=t.closest&&t.closest('.card');if(!c||!c._i)return;
 if(c._i.type==='live'&&S.page==='live')schedulePreview(c._i);else if(S.page!=='live'){clearTimeout(fcT);const it=c._i;fcT=setTimeout(()=>showFi(it),110)}maybeMore(c)});
/* ---------- franja de información (películas / series) ---------- */
const INFO={},ik=i=>i.vid+(i.src!=null?'@'+i.src:'');
const metaLine=(i,x)=>{x=x||{};const a=[i.cat];const y=i.year||String(x.releasedate||x.releaseDate||'').slice(0,4);if(y)a.push(y);const r=+(i.rating||x.rating)||0;if(r)a.push('★ '+(Math.round(r*10)/10));if(x.duration&&x.duration!=='00:00:00')a.push(x.duration);if(x.genre)a.push(x.genre);return a.filter(Boolean).join('  ·  ')};
function showFi(i,again){const b=$('#fi');clearTimeout(fiT);S.fi=i||null;if(!i||i.type==='live'||i.type==='ep'){b.classList.add('ghost');b.textContent='';return}
 b.classList.remove('ghost');b.textContent='';const x=INFO[ik(i)]||{};b.appendChild(h('h2','',i.name));
 b.appendChild(h('p','dm',metaLine(i,{genre:i.genre||x.genre,duration:x.duration,releasedate:x.releasedate||x.releaseDate})));
 b.appendChild(h('p','fp',i.plot||x.plot||x.description||''));
 if(!again&&i.type==='movie'&&i.vid&&xtOf(i)&&!INFO[ik(i)])fiT=setTimeout(async()=>{try{const d=await xtOf(i).api('get_vod_info&vod_id='+i.vid);INFO[ik(i)]=d.info||{}}catch(e){INFO[ik(i)]={}}if(S.fi===i)showFi(i,1)},400)}

/* ---------- vista previa de canales (el mismo <video> pasa a pantalla completa) ---------- */
const canDock=()=>S.page==='live'&&!$('#app').classList.contains('hidden')&&(narrow()||!!CFG.pv);
const dockFirst=()=>narrow()||TOUCH;
function epgBlock(box,L){box.textContent='';const n=nowNext(L);if(!n.now&&!n.next){box.appendChild(h('p','dm','Sin guía disponible para este canal'));return}
 const rows=n.list.slice(0,3);rows.forEach((x,k)=>{const cur=k===0&&n.now,r=h('div','en'+(cur?'':' nx'));r.appendChild(h('b','',(cur?'Ahora ':'')+hm(x.start)+' – '+hm(x.end)));r.appendChild(h('span','',x.title));box.appendChild(r);
  if(cur){const g=h('u','pgb'),s=h('s');s.style.width=n.pct+'%';g.appendChild(s);box.appendChild(g)}})}
function showPvInfo(i){clearTimeout(piT);const b=$('#pvi');b.textContent='';S.focusItem=i||null;updPvFav();if(!i)return;
 const t=h('div','pvt');if(i.logo){const im=h('img');im.src=mx(i.logo);im.onerror=()=>im.remove();t.appendChild(im)}
 const d=h('div','');d.appendChild(h('h2','',i.name));d.appendChild(h('p','dm',i.cat+'  ·  canal '+(S.view.indexOf(i)+1)+' de '+S.view.length));t.appendChild(d);b.appendChild(t);
 const ep=h('div','epg2');ep.appendChild(h('p','dm','Cargando guía…'));b.appendChild(ep);epgFor(i).then(L=>{if(S.focusItem===i)epgBlock(ep,L)})}
function updPvFav(){const b=$('#pvs'),i=S.focusItem;if(b)setIc(b,i&&isFav(i)?'starf':'star',i&&isFav(i)?'En favoritos':'Favorito');setIc($('#pvf'),'expand','Pantalla completa')}
function setPvIdle(){$('#pvp').classList.toggle('idle',!S.pv)}
function schedulePreview(i){clearTimeout(pvT);clearTimeout(piT);piT=setTimeout(()=>showPvInfo(i),90);if(!canDock()||S.skipPv||dockFirst())return;if(S.pv&&S.pvItem===i)return;pvT=setTimeout(()=>previewNow(i),650)}
function previewNow(i){clearTimeout(pvT);if(!canDock())return;S.pvItem=i;S.cur=i;S.epq=null;S.zl=S.view;S.zcat=S.cat;S.zap=S.view.indexOf(i);
 $('#pvh').textContent='';showPvInfo(i);$('#pvp').classList.remove('idle');play(i.url,i.name,true,null,liveMeta(i),undefined,false,true);markPv()}
function markPv(){$$('#list .card.ch').forEach(c=>c.classList.toggle('pvon',!!c._i&&c._i===S.pvItem&&!$('#pl').classList.contains('hidden')))}
function focusCardOf(i){const l=$('#list');let c=$$('#list .card').filter(x=>x._i===i)[0];
 if(!c&&S.view){const k=S.view.indexOf(i);if(k>=0){while(S.shown<=k)addCards();c=$$('#list .card').filter(x=>x._i===i)[0]}}
 if(c){if(!TOUCH){S.skipPv=true;c.focus();S.skipPv=false}showPvInfo(i)}}
function pickItem(i,o){
 if(i.type==='live'&&S.page==='live'&&dockFirst()&&canDock()&&!(S.pv&&S.pvItem===i&&!$('#pl').classList.contains('hidden'))){S.focusItem=i;previewNow(i);return}
 openItem(i,o)}
function openItem(i,o){S.last=document.activeElement;
 if(i.type==='live'){const dk=S.pv&&S.pvItem===i&&!$('#pl').classList.contains('hidden');
  if(dk){S.cur=i;S.zl=S.view;S.zcat=S.cat;S.zap=S.view.indexOf(i);if(goFull())return}
  return playLiveFrom(i,S.page==='live'&&S.view.indexOf(i)>=0?S.view:null)}
 if(i.type==='ep'){S.cur=i;S.epq=null;S.zap=-1;return play(i.url,i.name,false,null,{name:i.name,logo:i.logo,type:'ep',cat:i.cat,sid:i.sid,sn:i.sn})}
 showDetail(i,o)}
function playLiveFrom(i,list){S.last=S.last||document.activeElement;list=list||filterItems('*','','live');S.cur=i;S.epq=null;S.zl=list;S.zcat='*';S.zap=list.indexOf(i);S.pvItem=i;clearTimeout(pvT);
 play(i.url,i.name,true,null,liveMeta(i),undefined,false,false)}
