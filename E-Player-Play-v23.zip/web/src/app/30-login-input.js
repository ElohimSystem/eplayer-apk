/* ===== v4 — acceso, cuentas guardadas, conexión, teclado/control remoto e inicio ===== */
const acctId=c=>c.t==='X'?'X|'+normalizeHost(c.host)+'|'+c.user:'M|'+c.url;
const acctName=c=>c.t==='X'?c.user+' @ '+hostOf(normalizeHost(c.host)):'Lista M3U · '+hostOf(c.url);
function saveAcct(c,exp){const id=acctId(c);ACCTS=ACCTS.filter(a=>a.id!==id);ACCTS.unshift({id:id,name:acctName(c),cfg:c,exp:exp||0});ACCTS=ACCTS.slice(0,30);lsSet('iptv_accts',ACCTS)}
/* ---------- login v12: tarjeta de dos caras (acceso <-> cuentas guardadas) ---------- */
let lgBack=false,lgT=0,lgQ='';
function lgFace(back,instant){
 const F=$('#lgF'),B=$('#lgB'),x=$('#lgx');if(!F||!B||!x)return;
 if(back&&!ACCTS.length)back=false;
 if(back===lgBack&&!instant)return;
 lgBack=back;clearTimeout(lgT);
 const show=back?B:F,hide=back?F:B;
 if(!instant){x.classList.add('noanim');x.classList.remove('settled');void x.offsetWidth;x.classList.remove('noanim')}
 show.classList.remove('hidden');void x.offsetWidth;
 x.classList.toggle('flip',back);
 const fin=()=>{if(lgBack===back){hide.classList.add('hidden');x.classList.add('settled')}};
 if(instant)fin();else lgT=setTimeout(fin,850);
 const ti=$('#lgxin'),te=e=>{if(e.target===ti&&e.propertyName&&/transform/.test(e.propertyName)){ti.removeEventListener('transitionend',te);clearTimeout(lgT);fin()}};ti.addEventListener('transitionend',te)
 setTimeout(()=>{try{const t=back?($('#accts .amain')||$('#lgAdd')):$('#tX');if(t&&!$('#login').classList.contains('hidden'))t.focus()}catch(e){}},instant?0:480)}
const acctHue=n=>{let k=0;for(let i=0;i<n.length;i++)k=(k*31+n.charCodeAt(i))%360;return k};
function acctView(a){const c=a.cfg||{};
 const title=c.t==='M'?'Lista M3U':(c.user||a.name),host=c.t==='M'?hostOf(c.url||''):hostOf(normalizeHost(c.host||''));
 let st=['','m'],ex='';
 if(a.exp){const dl=Math.ceil((a.exp*1000-Date.now())/864e5);
  if(dl<0){st=['Vencida','bad'];ex='Venció el '+fmtDateEs(a.exp*1000)}
  else{st=dl<=7?[dl+(dl===1?' día':' días'),'warn']:['Activa','ok'];ex='Vence el '+fmtDateEs(a.exp*1000)}}
 else st=[c.t==='M'?'M3U':'Xtream','m'];
 return{title:title,sub:host+(ex?' · '+ex:''),st:st}}
function renderAccts(){const b=$('#accts'),n=ACCTS.length;if(!b)return;b.textContent='';b.classList.remove('busy');
 const pill=$('#lgToAccts');if(pill){pill.classList.toggle('hidden',!n);$('#lgN').textContent=n}
 const qw=$('#lgQw');if(qw)qw.classList.toggle('hidden',n<=5);if(n<=5)lgQ='';
 const sub=$('#lgSub');if(sub)sub.textContent=n?(n+(n===1?' cuenta guardada':' cuentas guardadas')):'Aún no hay cuentas guardadas';
 if(!n){if(lgBack)lgFace(false);return}
 const q=lgQ.trim().toLowerCase(),list=ACCTS.filter(a=>!q||a.name.toLowerCase().indexOf(q)>=0);
 if(!list.length){b.appendChild(h('p','dm lg-none','Ninguna cuenta coincide con «'+lgQ.trim()+'»'));return}
 list.forEach(a=>{const v=acctView(a),r=h('div','arow'),m=h('div','amain f');m.tabIndex=0;
  const av=h('div','avatar',initial(v.title));const hu=acctHue(a.name);av.style.background='linear-gradient(135deg,hsl('+hu+',72%,56%),hsl('+((hu+48)%360)+',72%,42%))';m.appendChild(av);
  const t=h('div','at2');t.appendChild(h('b','',v.title));t.appendChild(h('small','dm',v.sub));m.appendChild(t);
  m.appendChild(h('span','apill '+v.st[1],v.st[0]));
  m.onclick=()=>{if(b.classList.contains('busy'))return;b.classList.add('busy');r.classList.add('go2');fillForm(a.cfg);connect(a.cfg)};r.appendChild(m);
  const x=h('button','f ib adel');x.type='button';setIc(x,'trash');x.setAttribute('aria-label','Quitar cuenta');let ask=0,tm=0;
  x.onclick=()=>{if(!ask){ask=1;x.classList.add('ask');setIc(x,'trash','¿Quitar?');tm=setTimeout(()=>{ask=0;x.classList.remove('ask');setIc(x,'trash')},3200);return}
   clearTimeout(tm);ACCTS=ACCTS.filter(z=>z!==a);lsSet('iptv_accts',ACCTS);renderAccts();if(ACCTS.length){const f=$('#accts .amain');f&&f.focus()}};
  r.appendChild(x);b.appendChild(r)})}
(function(){const bk=$('#lgToLogin');if(bk)setIc(bk,'left');
 $('#lgToAccts').onclick=()=>lgFace(true);$('#lgToLogin').onclick=()=>lgFace(false);$('#lgAdd').onclick=()=>{lgFace(false)};
 $('#lgq').oninput=e=>{lgQ=e.target.value;renderAccts()};
 /* inclinación suave de la tarjeta según el puntero (solo con mouse y equipos con fuerza) */
 const L=$('#login'),w=$('#lgx');
 if(L&&w&&!document.documentElement.classList.contains('fx-lite')&&!(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches)){
  L.addEventListener('pointermove',e=>{if(e.pointerType==='touch'||L.classList.contains('hidden'))return;const r=L.getBoundingClientRect();
   w.style.transform='perspective(2000px) rotateY('+((e.clientX/r.width-.5)*3).toFixed(2)+'deg) rotateX('+((.5-e.clientY/r.height)*2).toFixed(2)+'deg)'});
  L.addEventListener('pointerleave',()=>{w.style.transform=''})}})();
IC.eye='<path d="M2.5 12S6 6 12 6s9.5 6 9.5 6-3.5 6-9.5 6S2.5 12 2.5 12z"/><circle cx="12" cy="12" r="2.8"/>';
/* ojito: alterna la contraseña entre oculta y visible (mouse, toque y control remoto) */
function setEye(on){const i=$('#pass'),b=$('#eye');if(!i||!b)return;i.type=on?'text':'password';b.setAttribute('aria-pressed',on?'true':'false');b.setAttribute('aria-label',on?'Ocultar contraseña':'Mostrar contraseña');b.title=b.getAttribute('aria-label');setIc(b,on?'eyeoff':'eye')}
setEye(false);$('#eye').onmousedown=e=>e.preventDefault();$('#eye').onclick=e=>{e.preventDefault();setEye($('#pass').type==='password')};
function fillForm(c){if(c.t==='D')return tab('X');tab(c.t||'X');if(c.t==='X'){$('#host').value=c.host||'';$('#user').value=c.user||'';$('#pass').value=c.pass||''}else $('#murl').value=c.url||''}
function tab(t){srcType=t;$('#tX').classList.toggle('on',t==='X');$('#tM').classList.toggle('on',t==='M');$('#fX').classList.toggle('hidden',t!=='X');$('#fM').classList.toggle('hidden',t==='X')}
let booted=false;
/* carga UNA cuenta (Xtream, M3U o demo) y devuelve sus datos; d.xt / d.acct / d.from describen de dónde salieron */
async function loadAny(cfg,force){let d=null;
  if(cfg.t==='X'){if(!cfg.host||!cfg.user)throw Error('Completa servidor y usuario');d=await loadXtream(normalizeHost(cfg.host),cfg.user.trim(),cfg.pass,force)}
  else if(cfg.t==='D'){S.xt=null;d=parseM3U(DEMO_M3U,'');d.catOrder={};S.acct=d.acct={type:'M',url:'demo',epg:'',skipped:0,counts:{live:d.live.length,movie:d.movie.length,series:d.series.length}};S.fromCache=d.from=0;d.xt=null}
  else{if(!cfg.url)throw Error('Escribe la URL de la lista');const xu=parseXtreamUrl(cfg.url);
   if(xu){try{d=await loadXtream(xu.host,xu.user,xu.pass,force)}catch(e){if(e.acct)throw e;d=null}}
   if(!d){S.xt=null;const r=await get(cfg.url);if(!r.ok)throw Error('HTTP '+r.status);const t=await rtext(r);
    if(!looksLikeM3U(t))throw Error(/^\s*</.test(t)?'El servidor devolvió una página web, no una lista M3U (¿enlace vencido, incorrecto o requiere iniciar sesión?)':'La respuesta no es una lista M3U/M3U8 válida');
    d=isHlsPlaylist(t)?{live:[{name:hostOf(cfg.url),cat:'Directo',type:'live',url:cfg.url}],movie:[],series:[],epg:'',skipped:0}:parseM3U(t,cfg.url);d.catOrder={};
    if(!d.live.length&&!d.movie.length&&!d.series.length){if(/#EXT-X-/.test(t))d.live.push({name:'Stream',cat:'Directo',type:'live',url:cfg.url});else throw Error('La lista no contiene canales válidos')}
    S.acct=d.acct={type:'M',url:cfg.url,epg:d.epg,skipped:d.skipped,counts:{live:d.live.length,movie:d.movie.length,series:d.series.length}};S.fromCache=d.from=0;d.xt=null}}
  if(!d.live.length&&!d.movie.length&&!d.series.length)throw Error('La cuenta no tiene contenido');
  return d}
async function connect(cfg,force,boot){
 if(CINE.busy)return;
 msg('Conectando… (las listas grandes pueden tardar)');S.cfg=cfg;const wasApp=!$('#app').classList.contains('hidden'),pg=S.page;
 const fx=!wasApp&&!boot&&!$('#login').classList.contains('hidden')&&(cfg.t==='D'||(cfg.t==='X'?!!(cfg.host&&cfg.user):!!cfg.url))&&CINE.start();
 if(wasApp)toast('Actualizando contenido…',4000);
 try{const isC=!!(cfg.combo&&cfg.combo.length>1);let d=isC?await VIPX.combine(cfg.combo,force):await loadAny(cfg,force);
  if(!isC){S.xts=null;S.combo=null;S.srcF=null}
  S.data=d;S.idx=null;S.epgUrl=CFG.epg||d.epg||'';S.xmlP=null;S.unlocked=false;try{localStorage.setItem(KEY,JSON.stringify(cfg))}catch(e){}
  const ui=S.acct.info&&S.acct.info.user_info;if(cfg.t!=='D'&&!isC)saveAcct(cfg,ui&&+ui.exp_date||0);setTimeout(()=>{window.VIPX&&VIPX.syncAlerts()},2500);
  if(fx)await CINE.ready();
  msg('');$('#login').classList.add('hidden');$('#app').classList.remove('hidden');BRAND.top&&BRAND.top();if(fx)CINE.reveal();S.zl=[];S.zap=-1;S.q='';
  const keep=wasApp&&force;showPage(keep?pg:'home',{focus:!keep});
  const w=S.acct.combined?VIPX.describeCombo(S.acct):describeAccount(S.acct,Date.now());if(w.warns.length)toast('⚠ '+w.warns[0],9000);else if(S.fromCache&&!keep)toast('Catálogo desde caché. Perfil > Recargar contenido para actualizar.',4000);else if(keep)toast('Contenido actualizado',2500);
  if(boot&&CFG.start==='last'&&LAST.cur&&S.data.live.length){const lc=LAST.cur,it=idx('live')[lc.url];if(it&&!hidden(it))playLiveFrom(it)}}
 catch(e){if(fx)CINE.fail();msg('Error: '+(/Failed to fetch|NetworkError|TypeError/i.test(e.message)?(PROXY?'no se pudo conectar. Revisa tu internet y la URL del servidor. Versión web: además el proxy debe estar disponible y permitir este sitio ('+location.origin+'); si lo abres desde localhost usa «npm start», que trae su propio proxy.':'no se pudo conectar (revisa la URL y la red; el servidor podría bloquear la app)'):e.message));if(!wasApp){$('#login').classList.remove('hidden');$('#app').classList.add('hidden')}else toast('No se pudo actualizar: '+e.message);renderAccts();$('#accts').classList.remove('busy');if(!wasApp)lgFace(false)}}
$('#demo').onclick=()=>connect({t:'D'});$('#tX').onclick=()=>tab('X');$('#tM').onclick=()=>tab('M');
$('#go').onclick=()=>connect(srcType==='X'?{t:'X',host:$('#host').value,user:$('#user').value.trim(),pass:$('#pass').value}:{t:'M',url:$('#murl').value.trim()});
$('#sortb').onclick=()=>{const k=SORTS.map(s=>s[0]);CFG.sort=k[(k.indexOf(CFG.sort)+1)%k.length];saveCfg();refreshBrowse()};

/* ---------- atrás ---------- */
window.goBack=()=>{
 if(lgBack&&!$('#login').classList.contains('hidden')){lgFace(false);return true}
 const top=S.ovs[S.ovs.length-1],full=playerFull(),appOn=!$('#app').classList.contains('hidden');
 if(top&&top.id==='#vp'&&window.VIPUI&&VIPUI.back())return true;
 if(top&&(top.up||!full)){const e=$(top.id);if(top.id==='#pin'&&e._c){e._c();return true}ovClose(top.id);return true}
 if(D.open){closeDrawer();return true}
 if(full){exitFull();return true}
 if(S.pv&&!$('#pl').classList.contains('hidden')){S.pf=document.activeElement;stop();return true}
 if(appOn&&S.page!=='home'){const prev=S.page;showPage('home');const t=document.querySelector('#hm .tile.t-'+prev)||document.querySelector('#hm .f');t&&t.focus();return true}
 /* versión web: Atrás NUNCA saca de la página; en el inicio simplemente no hace nada */
 return true};
/* siempre queda una entrada de historial por delante: el botón Atrás del navegador/TV no puede abandonar la app */
const keepIn=()=>{try{history.pushState({n:0},'')}catch(e){}};
window.addEventListener('popstate',()=>{window.goBack();keepIn()});
try{history.replaceState({n:0},'')}catch(e){}keepIn();

/* ---------- mantener a la vista lo enfocado ---------- */
function ensureVis(el){const rw=el.closest('.rw'),cont=el.closest('.sc,.ovl');if(!cont)return;const a=(rw||el).getBoundingClientRect(),b=cont.getBoundingClientRect(),pad=24;
 if(a.bottom>b.bottom-pad)cont.scrollTop+=a.bottom-b.bottom+pad;else if(a.top<b.top+pad)cont.scrollTop-=b.top-a.top+pad;
 const rs=el.closest('.rs');if(rs){const x=el.getBoundingClientRect(),y=rs.getBoundingClientRect();if(x.right>y.right-pad)rs.scrollLeft+=x.right-y.right+pad*2;else if(x.left<y.left+pad)rs.scrollLeft-=y.left-x.left+pad*2}}
document.addEventListener('focusin',e=>ensureVis(e.target));

/* ---------- Mando: navegación espacial ---------- */
const DIR={37:'l',38:'u',39:'r',40:'d'};
function vis(e){return e.offsetWidth>0&&!(e.closest('.hidden'))}
/* solo los elementos de la pantalla activa (antes se recorrían también las pantallas ocultas) */
function focusables(md){if(md)return $$('.f',md);const r=[];['#top','#bn','#login',S.page==='home'?'#p-home':S.page==='favs'?'#p-favs':S.page==='profile'?'#p-profile':'#p-browse','#cd'].forEach(s=>{const e=$(s);if(e&&e.offsetWidth>0)r.push.apply(r,$$('.f',e))});return r.length?r:$$('.f')}
function move(d){const md=activeOv(),cur=document.activeElement;
 const cf=S.cf&&!md&&!D.open&&playerFull(),els=(cf?$$('#ctl .pb,#bar'):focusables(md)).filter(e=>vis(e)&&(!md||md.contains(e)));
 if(els.indexOf(cur)<0){els[0]&&els[0].focus();return}
 const r=cur.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;let best=null,bs=1e9;
 els.forEach(e=>{if(e===cur)return;const b=e.getBoundingClientRect(),dx=b.left+b.width/2-cx,dy=b.top+b.height/2-cy;
  const p=d==='l'?-dx:d==='r'?dx:d==='u'?-dy:dy,s=(d==='l'||d==='r')?dy:dx;if(p<=2)return;if(cf&&(d==='l'||d==='r')&&Math.abs(dy)>r.height*.8)return;const sc=p+2.5*Math.abs(s);if(sc<bs){bs=sc;best=e}});
 if(best)best.focus()}
const isNum=k=>(k>=48&&k<=57)||(k>=96&&k<=105),numOf=k=>String(k>=96?k-96:k-48);
let kBusy=0;
document.addEventListener('keydown',e=>{const k=e.keyCode,v=$('#v'),inp=e.target.tagName==='INPUT',md=activeOv();
 if(e.repeat&&DIR[k]){if(kBusy){e.preventDefault();return}kBusy=1;requestAnimationFrame(()=>{kBusy=0})}
 if(TOUCH&&DIR[k]){TOUCH=false;document.body.classList.remove('touch')}
 if(S.forcedMute&&playerFull())unforce();
 if(md){if([461,10009,27].indexOf(k)>=0||(k===8&&!inp)){e.preventDefault();window.goBack();return}
  if(DIR[k]){if(inp&&(k===37||k===39))return;e.preventDefault();move(DIR[k])}
  else if(k===13){if(inp){e.preventDefault();move('d')}else{const a=document.activeElement;if(a&&a.classList.contains('f')&&a.tagName!=='BUTTON'){e.preventDefault();if(!e.repeat)a.click()}}}
  return}
 if(D.open){drRst();const ci=e.target.id==='cdq';
  if([461,10009,27].indexOf(k)>=0||(k===8&&!ci)){e.preventDefault();closeDrawer();return}
  if(ci){if(k===40||k===13){e.preventDefault();e.target.blur()}return}
  if(k===38){e.preventDefault();drMove(-1)}else if(k===40){e.preventDefault();drMove(1)}
  else if(k===33||k===427){e.preventDefault();drMove(-8)}else if(k===34||k===428){e.preventDefault();drMove(8)}
  else if(k===37){e.preventDefault();drCat(-1)}else if(k===39){e.preventDefault();drCat(1)}
  else if(k===13||k===415){e.preventDefault();drPick(D.vl.sel)}
  return}
 if(playerFull()){
  if([461,10009,27,8,413,4].indexOf(k)>=0){e.preventDefault();if(S.cf)ctlOff();else exitFull();return}
  if(k===405){e.preventDefault();S.cur&&S.cur.type!=='ep'&&toggleFav(S.cur);osd();return}
  if(k===406){e.preventDefault();qualityMenu();return}
  if(k===404&&S.live){e.preventDefault();prevChannel();return}
  if(k===403||k===457||k===82){e.preventDefault();playerMenu();return}
  if(S.cf&&!S.live){
   if(DIR[k]){e.preventDefault();const a=document.activeElement;if(a&&a.id==='bar'&&(k===37||k===39))seekBy(k===39?10:-10);else move(DIR[k]);showCtl();return}
   if(k===13){e.preventDefault();const a=document.activeElement;if(!e.repeat){if(a&&a.id==='bar')toggleP();else if(a&&a.tagName==='BUTTON')a.click()}showCtl();return}
   if(k===415||k===19||k===179||k===85){e.preventDefault();toggleP();showCtl();return}}
  if(S.live){
   if(k===13){e.preventDefault();if(numS)numGo();else openDrawer()}
   else if(k===37){e.preventDefault();openDrawer()}else if(k===39){e.preventDefault();playerMenu()}
   else if(k===38||k===33||k===427){e.preventDefault();zap(-1)}else if(k===40||k===34||k===428){e.preventDefault();zap(1)}
   else if(isNum(k)){e.preventDefault();numKey(numOf(k))}
   else if([415,19,179,85].indexOf(k)>=0){e.preventDefault();v.paused?v.play():v.pause()}
   return}
  if(k===13&&!$('#nx').classList.contains('hidden')){e.preventDefault();playNext();return}
  if(k===13||k===415||k===19||k===179||k===85){e.preventDefault();v.paused?v.play():v.pause();osd()}
  else if(k===39||k===37||k===417||k===412){e.preventDefault();v.currentTime+=(k===39||k===417?1:-1)*(k>400?30:10);osd()}
  else if(k===38||k===40){e.preventDefault();ctlOn()}
  return}
 if([461,10009,27].indexOf(k)>=0||(k===8&&!inp)){if(window.goBack())e.preventDefault();return}
 if(k===406&&!inp&&!$('#app').classList.contains('hidden')){e.preventDefault();openSearch(isBrowse(S.page)?S.page:'all');return}
 if((k===405||k===70)&&!inp){const a=document.activeElement;if(a&&a._i&&a._i.type!=='ep'){toggleFav(a._i);refStar(a._i)}return}
 if(DIR[k]){if(inp&&(k===37||k===39))return;e.preventDefault();move(DIR[k])}
 else if(k===13){const a=document.activeElement;if(inp){e.preventDefault();move('d')}else if(a&&a.classList.contains('f')&&a.tagName!=='BUTTON'){e.preventDefault();if(a._i&&a._i.type!=='ep'){if(e.repeat){if(!S.ld){S.ld=1;toggleFav(a._i);refStar(a._i);toast(isFav(a._i)?'Agregado a favoritos':'Quitado de favoritos',1800)}}else{S.dn=a;S.ld=0}}else if(!e.repeat)a.click()}}});
document.addEventListener('keyup',e=>{if(e.keyCode===13&&S.dn){const a=S.dn;S.dn=null;if(!S.ld&&document.body.contains(a))a.click();S.ld=0}});

/* ---------- PWA: instalar como app (Chrome/Edge/Android; el navegador de la TV LG no permite instalar) ---------- */
const PWA_ON=()=>!!(window.matchMedia&&matchMedia('(display-mode:standalone)').matches||navigator.standalone);
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();window.PWA_EV=e;if(S.page==='profile')renderProfile()});
window.addEventListener('appinstalled',()=>{window.PWA_EV=null;toast('App instalada',2500)});
if('serviceWorker' in navigator&&/^https?:$/.test(location.protocol)&&!WEBOS&&!window.PalmServiceBridge&&!/;\s*wv\)/.test(navigator.userAgent)){window.addEventListener('load',()=>{navigator.serviceWorker.register('sw.js').catch(()=>{})})}

/* ---------- inicio ---------- */
buildNav();updClock();setInterval(updClock,20000);
try{const c=JSON.parse(localStorage.getItem(KEY));renderAccts();tab(c&&c.t||'X');
 if(c){fillForm(c);connect(c,false,true)}else $('#tX').focus()}catch(e){$('#tX').focus()}
