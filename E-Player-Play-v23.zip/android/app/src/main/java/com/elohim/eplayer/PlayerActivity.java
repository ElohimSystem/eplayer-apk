package com.elohim.eplayer;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PictureInPictureParams;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Rational;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.OptIn;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.common.Tracks;
import androidx.media3.common.text.Cue;
import androidx.media3.common.text.CueGroup;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.analytics.AnalyticsListener;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.extractor.DefaultExtractorsFactory;
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;
import androidx.media3.ui.SubtitleView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Reproductor nativo de E-Player (Media3 / ExoPlayer).
 * - Películas y series: lista de capítulos con siguiente automático, anterior/siguiente.
 * - Elegir audio y subtítulos (se recuerda el idioma), retraso de subtítulos, formato de pantalla.
 * - Gestos: deslizar (izquierda = brillo, derecha = volumen), doble toque (-10 s / +10 s / pausa).
 * - Imagen en imagen (PiP), progreso guardado cada 10 s, aviso si falta el decodificador de audio.
 * El progreso se guarda en SharedPreferences y la web lo recoge al volver (takeProgress).
 */
@OptIn(markerClass = UnstableApi.class)
public class PlayerActivity extends Activity {

    static final String X_ITEMS = "items", X_INDEX = "index", X_START = "start", X_LIVE = "live";
    private static final String UA =
            "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36";
    private static final int TEAL = 0xFF40E0C8;

    private SharedPreferences sp;
    private ExoPlayer player;
    private PlayerView view;
    private SubtitleView subs;
    private GestureFrame root;
    private LinearLayout top, errBox;
    private TextView tit, bAudio, bSubs, bSync, bAspect, bPip, banner, indicator, errMsg;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Handler cueH = new Handler(Looper.getMainLooper());

    private JSONArray items;
    private boolean live;
    private final List<List<String>> vars = new ArrayList<List<String>>();
    private int[] vi;
    private int curIdx;
    private long lastPos, lastDur;
    private int blw;
    private boolean fatal, audioWarned, finishedAll, inPip;
    /* nombres de los decodificadores realmente usados (hardware del equipo o FFmpeg): solo para el diagnóstico */
    private String audioDec = "", videoDec = "";
    /* reconexión automática en vivo: wasReady = ya reprodujo bien esta variante; liveTry = intentos seguidos */
    private boolean wasReady;
    private int liveTry;
    private long subDelay;
    private int arMode;
    private JSONObject prog = new JSONObject();
    private boolean locked, night;
    private String pendingSub;
    private View lockLayer;
    private TextView unlockPill, bLock, bMore;
    private android.media.audiofx.DynamicsProcessing dyn;
    private static final int REQ_SUB = 7001;

    private static final Pattern XVOD = Pattern.compile("^(.*/(?:movie|series)/[^/]+/[^/]+/\\d+)\\.([A-Za-z0-9]+)([?#].*)?$");
    private static final Pattern XLIVE = Pattern.compile("^(.*/live/[^/]+/[^/]+/\\d+)(?:\\.([A-Za-z0-9]+))?([?#].*)?$");

    /** Variantes de la misma URL que se prueban en orden si la primera falla (Xtream Codes: archivo -> HLS; en vivo: ts <-> m3u8). */
    private static List<String> variantes(String u) {
        List<String> r = new ArrayList<String>();
        r.add(u);
        Matcher m = XVOD.matcher(u);
        if (m.matches()) {
            if (!"m3u8".equalsIgnoreCase(m.group(2))) r.add(m.group(1) + ".m3u8" + (m.group(3) == null ? "" : m.group(3)));
            return r;
        }
        m = XLIVE.matcher(u);
        if (m.matches()) {
            String ext = m.group(2) == null ? "" : m.group(2).toLowerCase();
            String q = m.group(3) == null ? "" : m.group(3);
            if (ext.equals("ts")) r.add(m.group(1) + ".m3u8" + q);
            else if (ext.equals("m3u8")) r.add(m.group(1) + ".ts" + q);
            else { r.add(m.group(1) + ".m3u8" + q); r.add(m.group(1) + ".ts" + q); }
            return r;
        }
        /* Cualquier otra URL (listas M3U normales): si no tiene extensión de video conocida puede ser HLS sin ".m3u8"
           (se prueba como HLS); si dice .m3u8 pero en realidad es TS/MP4, se prueba con detección automática. */
        String lo = u.toLowerCase();
        if (lo.matches("^[^?#]*\\.m3u8([?#].*)?$") || lo.contains("type=m3u8")) r.add(u + AUTO_MARK);
        else if (!MEDIA_EXT.matcher(u).matches()) r.add(u + HLS_MARK);
        return r;
    }

    /* Marcas internas (van en el fragmento #..., que nunca se envía al servidor):
       HLS_MARK = tratar la URL como HLS aunque no termine en .m3u8; AUTO_MARK = que ExoPlayer detecte el formato solo. */
    private static final String HLS_MARK = "#__hls", AUTO_MARK = "#__auto";
    private static final Pattern MEDIA_EXT = Pattern.compile(
            "^[^?#]*\\.(mp4|mkv|avi|mov|wmv|flv|webm|m4v|mpg|mpeg|ts|m2ts|mts|3gp|mp3|aac|m4a|ogg|opus|flac|wav)([?#].*)?$",
            Pattern.CASE_INSENSITIVE);

    private static String stripMark(String u) {
        if (u.endsWith(HLS_MARK)) return u.substring(0, u.length() - HLS_MARK.length());
        if (u.endsWith(AUTO_MARK)) return u.substring(0, u.length() - AUTO_MARK.length());
        return u;
    }

    private MediaItem item(String u) {
        boolean forceHls = u.endsWith(HLS_MARK), auto = u.endsWith(AUTO_MARK);
        String c = stripMark(u);
        MediaItem.Builder b = new MediaItem.Builder().setUri(c);
        String l = c.toLowerCase();
        if (forceHls || (!auto && (l.matches("^[^?#]*\\.m3u8([?#].*)?$") || l.contains("type=m3u8")))) {
            b.setMimeType(MimeTypes.APPLICATION_M3U8);
        }
        return b.build();
    }

    /** Flujos MPEG-TS de IPTV: muchos no traen delimitadores de acceso ni empiezan en IDR; sin estas banderas se ve negro con audio. */
    private static DefaultExtractorsFactory tsTolerant() {
        return new DefaultExtractorsFactory()
                .setConstantBitrateSeekingEnabled(true)
                .setTsExtractorFlags(DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES
                        | DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS);
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    /* ---------------------------------------------------------------- ciclo de vida */
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        sp = getSharedPreferences("np", MODE_PRIVATE);
        try {
            prog = new JSONObject(sp.getString("prog", "{}"));
        } catch (Throwable t) {
            prog = new JSONObject();
        }

        try {
            items = new JSONArray(getIntent().getStringExtra(X_ITEMS));
        } catch (Throwable t) {
            items = null;
        }
        if (items == null || items.length() == 0) {
            finish();
            return;
        }
        live = getIntent().getBooleanExtra(X_LIVE, false);
        curIdx = Math.max(0, Math.min(items.length() - 1, getIntent().getIntExtra(X_INDEX, 0)));
        long startMs = Math.max(0, getIntent().getLongExtra(X_START, 0)) * 1000L;
        arMode = sp.getInt("ar", 0);

        buildUi();

        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setUserAgent(UA)
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(30000)
                .setDefaultRequestProperties(Collections.singletonMap("Accept", "*/*"));
        /* EXTENSION_RENDERER_MODE_ON: los decodificadores del equipo van primero; si el equipo NO puede decodificar un
           audio (AC3, E-AC3, DTS, TrueHD...), entra la extensión FFmpeg de Media3 como respaldo por software.
           Si la librería (android/app/libs/*.aar, ver LEEME-FFMPEG.md) no está incluida, Media3 la omite sin error
           y todo funciona como antes. La extensión se compila SIN GPL (solo LGPL). */
        DefaultRenderersFactory rf = new DefaultRenderersFactory(this)
                .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
                .setEnableDecoderFallback(true);
        /* Buffer: "Largo" (Perfil) guarda más video por adelantado: mejor con internet lenta. */
        boolean longBuf = "l".equals(sp.getString("buf", "n"));
        DefaultLoadControl lc = longBuf
                ? new DefaultLoadControl.Builder().setBufferDurationsMs(60000, 180000, 3000, 8000).build()
                : new DefaultLoadControl.Builder().build();
        night = "1".equals(sp.getString("night", "0"));
        player = new ExoPlayer.Builder(this)
                .setRenderersFactory(rf)
                .setLoadControl(lc)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(new DefaultDataSource.Factory(this, http), tsTolerant()))
                .setSeekBackIncrementMs(10000)
                .setSeekForwardIncrementMs(10000)
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(C.USAGE_MEDIA)
                        .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                        .build(), true)
                .build();
        player.addAnalyticsListener(analytics);
        view.setPlayer(player);
        applyPrefs();
        applyAspect();

        List<MediaItem> list = new ArrayList<MediaItem>();
        vi = new int[items.length()];
        try {
            for (int i = 0; i < items.length(); i++) {
                String u = items.getJSONObject(i).getString("u");
                List<String> v = variantes(u);
                vars.add(v);
                list.add(item(v.get(0)));
            }
        } catch (Throwable t) {
            finish();
            return;
        }
        refreshTitle();
        player.addListener(listener);
        player.setMediaItems(list, curIdx, startMs > 0 ? startMs : C.TIME_UNSET);
        player.prepare();
        player.setPlayWhenReady(true);
        h.postDelayed(tick, 10000);
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (player == null) return;
            snap();
            saveProg(curIdx, lastPos, lastDur, false);
            h.postDelayed(this, 10000);
        }
    };

    @Override
    protected void onStart() {
        super.onStart();
        immersive();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) {
            snap();
            saveProg(curIdx, lastPos, lastDur, false);
            player.pause();
        }
    }

    @Override
    protected void onDestroy() {
        h.removeCallbacksAndMessages(null);
        cueH.removeCallbacksAndMessages(null);
        releaseNight();
        releaseEq();
        if (player != null) {
            try {
                player.release();
            } catch (Throwable ignored) { }
            player = null;
        }
        super.onDestroy();
    }

    @Override
    public void finish() {
        if (player != null && !finishedAll && !fatal) {
            snap();
            saveProg(curIdx, lastPos, lastDur, false);
        }
        setResult(RESULT_OK);
        super.finish();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) immersive();
    }

    @SuppressWarnings("deprecation")
    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    /* ---------------------------------------------------------------- imagen en imagen */
    private boolean pipOk() {
        return Build.VERSION.SDK_INT >= 26 && getPackageManager().hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE);
    }

    private void enterPip() {
        if (!pipOk() || player == null) return;
        try {
            Rational r = new Rational(16, 9);
            Format f = player.getVideoFormat();
            if (f != null && f.width > 0 && f.height > 0) {
                float ar = (float) f.width / f.height;
                if (ar >= 0.45f && ar <= 2.3f) r = new Rational(f.width, f.height);
            }
            enterPictureInPictureMode(new PictureInPictureParams.Builder().setAspectRatio(r).build());
        } catch (Throwable t) {
            Toast.makeText(this, "No se pudo activar imagen en imagen", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (player != null && player.isPlaying() && !fatal) enterPip();
    }

    @Override
    public void onPictureInPictureModeChanged(boolean isInPip, Configuration cfg) {
        super.onPictureInPictureModeChanged(isInPip, cfg);
        inPip = isInPip;
        view.setUseController(!isInPip);
        top.setVisibility(isInPip ? View.GONE : View.VISIBLE);
        banner.setVisibility(View.GONE);
        if (!isInPip) immersive();
    }

    /* ---------------------------------------------------------------- interfaz */
    private TextView pill(String text, final Runnable run) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        t.setSingleLine(true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(11), dp(7), dp(11), dp(7));
        GradientDrawable n = new GradientDrawable();
        n.setCornerRadius(dp(20));
        n.setColor(0xB3101826);
        n.setStroke(dp(1), 0x33FFFFFF);
        GradientDrawable f = new GradientDrawable();
        f.setCornerRadius(dp(20));
        f.setColor(0xFF1C3A44);
        f.setStroke(dp(2), TEAL);
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_focused}, f);
        sl.addState(new int[]{android.R.attr.state_pressed}, f);
        sl.addState(new int[]{}, n);
        t.setBackground(sl);
        t.setFocusable(true);
        t.setClickable(true);
        t.setContentDescription(text);
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                run.run();
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = dp(6);
        t.setLayoutParams(lp);
        return t;
    }

    private void buildUi() {
        root = new GestureFrame(this);
        root.setBackgroundColor(Color.BLACK);

        view = new PlayerView(this);
        view.setShowSubtitleButton(false);              /* los subtítulos se eligen con nuestro botón */
        view.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);
        view.setControllerShowTimeoutMs(4000);
        view.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        View own = view.getSubtitleView();               /* usamos nuestro propio dibujo de subtítulos (para el retraso) */
        if (own != null) own.setVisibility(View.GONE);
        root.addView(view, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        subs = new SubtitleView(this);
        subs.setUserDefaultStyle();
        subs.setUserDefaultTextSize();
        applySubStyle();
        subs.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        root.addView(subs, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        /* barra superior */
        top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(12), dp(8), dp(12), dp(18));
        top.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xC0000000, 0x00000000}));
        TextView back = new TextView(this);
        back.setText("\u2190");
        back.setTextColor(Color.WHITE);
        back.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        back.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(0x99101826);
        back.setBackground(bg);
        back.setFocusable(true);
        back.setClickable(true);
        back.setContentDescription("Volver");
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        top.addView(back, new LinearLayout.LayoutParams(dp(42), dp(42)));
        tit = new TextView(this);
        tit.setTextColor(Color.WHITE);
        tit.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        tit.setSingleLine(true);
        tit.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tl.leftMargin = dp(12);
        top.addView(tit, tl);
        bAudio = pill("Audio", new Runnable() { public void run() { pickTrack(C.TRACK_TYPE_AUDIO); } });
        bSubs = pill("Subtítulos", new Runnable() { public void run() { pickTrack(C.TRACK_TYPE_TEXT); } });
        bSync = pill("Sinc. 0.0 s", new Runnable() { public void run() { nextDelay(); } });
        bSync.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                setDelay(0);
                return true;
            }
        });
        bAspect = pill("Ajustar", new Runnable() { public void run() { arMode = (arMode + 1) % 3; sp.edit().putInt("ar", arMode).apply(); applyAspect(); flash(aspectName()); } });
        bPip = pill("PiP", new Runnable() { public void run() { enterPip(); } });
        bLock = pill("Bloquear", new Runnable() { public void run() { setLocked(true); } });
        bMore = pill("Más \u22EE", new Runnable() { public void run() { showMore(); } });
        top.addView(bAudio);
        top.addView(bSubs);
        /* el bloqueo de toques solo tiene sentido con pantalla táctil (no en Android TV) */
        if (getPackageManager().hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN)) top.addView(bLock);
        top.addView(bMore);
        root.addView(top, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP));
        view.setControllerVisibilityListener(new PlayerView.ControllerVisibilityListener() {
            @Override
            public void onVisibilityChanged(int visibility) {
                top.setVisibility(inPip || locked ? View.GONE : (visibility == View.VISIBLE ? View.VISIBLE : View.GONE));
            }
        });

        /* aviso (audio sin decodificador) */
        banner = new TextView(this);
        banner.setTextColor(Color.WHITE);
        banner.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        banner.setGravity(Gravity.CENTER);
        banner.setPadding(dp(16), dp(10), dp(16), dp(10));
        GradientDrawable bb = new GradientDrawable();
        bb.setCornerRadius(dp(14));
        bb.setColor(0xF0402030);
        bb.setStroke(dp(1), 0xFFFF8FA3);
        banner.setBackground(bb);
        banner.setVisibility(View.GONE);
        banner.setClickable(true);
        banner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                banner.setVisibility(View.GONE);
                pickTrack(C.TRACK_TYPE_AUDIO);
            }
        });
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        bp.bottomMargin = dp(86);
        root.addView(banner, bp);

        /* bloqueo de toques */
        lockLayer = new View(this);
        lockLayer.setClickable(true);
        lockLayer.setVisibility(View.GONE);
        lockLayer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                unlockPill.setVisibility(View.VISIBLE);
                h.removeCallbacks(hideUnlock);
                h.postDelayed(hideUnlock, 3000);
            }
        });
        root.addView(lockLayer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        unlockPill = pill("\uD83D\uDD13  Toca para desbloquear", new Runnable() { public void run() { setLocked(false); } });
        unlockPill.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        unlockPill.setPadding(dp(18), dp(10), dp(18), dp(10));
        unlockPill.setVisibility(View.GONE);
        FrameLayout.LayoutParams up = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        up.bottomMargin = dp(28);
        root.addView(unlockPill, up);

        /* indicador de gestos (brillo, volumen, saltos) */
        indicator = new TextView(this);
        indicator.setTextColor(Color.WHITE);
        indicator.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        indicator.setGravity(Gravity.CENTER);
        indicator.setPadding(dp(22), dp(12), dp(22), dp(12));
        GradientDrawable ib = new GradientDrawable();
        ib.setCornerRadius(dp(16));
        ib.setColor(0xCC101826);
        indicator.setBackground(ib);
        indicator.setVisibility(View.GONE);
        root.addView(indicator, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        /* error con acciones */
        errBox = new LinearLayout(this);
        errBox.setOrientation(LinearLayout.VERTICAL);
        errBox.setGravity(Gravity.CENTER);
        errBox.setPadding(dp(24), dp(16), dp(24), dp(16));
        errBox.setBackgroundColor(0xEA070A11);
        errBox.setVisibility(View.GONE);
        errMsg = new TextView(this);
        errMsg.setTextColor(0xFFFF8FA3);
        errMsg.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        errMsg.setGravity(Gravity.CENTER);
        errBox.addView(errMsg, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rp.topMargin = dp(14);
        errBox.addView(row, rp);
        row.addView(pill("Reintentar", new Runnable() { public void run() { retry(); } }));
        row.addView(pill("Abrir en VLC / otro", new Runnable() { public void run() { external(); } }));
        row.addView(pill("Copiar enlace", new Runnable() { public void run() { copyLink(); } }));
        row.addView(pill("Cerrar", new Runnable() { public void run() { finish(); } }));
        /* segunda fila: informe para soporte (sin enlaces ni contraseñas) */
        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams rp2 = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rp2.topMargin = dp(8);
        errBox.addView(row2, rp2);
        row2.addView(pill("Copiar diagnóstico", new Runnable() { public void run() { copyDiag(); } }));
        root.addView(errBox, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        setContentView(root);
    }

    private final Runnable hideUnlock = new Runnable() {
        @Override
        public void run() {
            unlockPill.setVisibility(View.GONE);
        }
    };

    private void setLocked(boolean on) {
        locked = on;
        lockLayer.setVisibility(on ? View.VISIBLE : View.GONE);
        unlockPill.setVisibility(on ? View.VISIBLE : View.GONE);
        h.removeCallbacks(hideUnlock);
        if (on) {
            view.hideController();
            view.setUseController(false);
            top.setVisibility(View.GONE);
            banner.setVisibility(View.GONE);
            h.postDelayed(hideUnlock, 3000);
            Toast.makeText(this, "Toques bloqueados. Toca la pantalla para ver cómo desbloquear.", Toast.LENGTH_SHORT).show();
        } else {
            view.setUseController(true);
            view.showController();
        }
    }

    private void flash(String s) {
        indicator.setText(s);
        indicator.setVisibility(View.VISIBLE);
        h.removeCallbacks(hideInd);
        h.postDelayed(hideInd, 900);
    }

    private final Runnable hideInd = new Runnable() {
        @Override
        public void run() {
            indicator.setVisibility(View.GONE);
        }
    };

    private String aspectName() {
        return arMode == 0 ? "Ajustar" : arMode == 1 ? "Zoom (recortar)" : "Estirar";
    }

    private void applyAspect() {
        view.setResizeMode(arMode == 0 ? AspectRatioFrameLayout.RESIZE_MODE_FIT
                : arMode == 1 ? AspectRatioFrameLayout.RESIZE_MODE_ZOOM : AspectRatioFrameLayout.RESIZE_MODE_FILL);
        bAspect.setText(arMode == 0 ? "Ajustar" : arMode == 1 ? "Zoom" : "Estirar");
    }

    private void refreshTitle() {
        try {
            tit.setText(items.getJSONObject(curIdx).optString("t", ""));
        } catch (Throwable ignored) { }
    }

    /* ---------------------------------------------------------------- gestos */
    private class GestureFrame extends FrameLayout {
        private final GestureDetector gd;
        private float sx, sy, startVal;
        private boolean zone, swiping, left;

        GestureFrame(Context c) {
            super(c);
            gd = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onDoubleTap(MotionEvent e) {
                    doubleTap(e.getX(), getWidth());
                    return true;
                }
            });
        }

        @Override
        public boolean dispatchTouchEvent(MotionEvent e) {
            if (locked) return super.dispatchTouchEvent(e);
            gd.onTouchEvent(e);
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                sx = e.getX();
                sy = e.getY();
                float hgt = getHeight();
                zone = !inPip && sy > hgt * 0.2f && sy < hgt * 0.74f;
                swiping = false;
                left = sx < getWidth() / 2f;
            } else if (a == MotionEvent.ACTION_MOVE && zone) {
                float dy = sy - e.getY(), dx = e.getX() - sx;
                if (!swiping && Math.abs(dy) > dp(18) && Math.abs(dy) > Math.abs(dx) * 1.6f) {
                    swiping = true;
                    startVal = left ? curBrightness() : curVolume();
                    MotionEvent c = MotionEvent.obtain(e);
                    c.setAction(MotionEvent.ACTION_CANCEL);
                    super.dispatchTouchEvent(c);
                    c.recycle();
                }
                if (swiping) {
                    float f = Math.max(0f, Math.min(1f, startVal + dy / (getHeight() * 0.7f)));
                    if (left) setBrightness(f);
                    else setVolume(f);
                    return true;
                }
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                if (swiping) {
                    swiping = false;
                    return true;
                }
            }
            return super.dispatchTouchEvent(e);
        }
    }

    private void doubleTap(float x, int w) {
        if (player == null || inPip) return;
        long pos = player.getCurrentPosition(), dur = player.getDuration();
        if (x < w / 3f) {
            player.seekTo(Math.max(0, pos - 10000));
            flash("\u2212 10 s");
        } else if (x > w * 2f / 3f) {
            long t = pos + 10000;
            if (dur != C.TIME_UNSET && dur > 0) t = Math.min(t, dur - 1000);
            player.seekTo(Math.max(0, t));
            flash("+ 10 s");
        } else if (player.isPlaying()) {
            player.pause();
            flash("Pausa");
        } else {
            player.play();
            flash("Reproducir");
        }
    }

    private float curBrightness() {
        float b = getWindow().getAttributes().screenBrightness;
        if (b < 0) {
            try {
                b = Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS) / 255f;
            } catch (Throwable t) {
                b = 0.5f;
            }
        }
        return b;
    }

    private void setBrightness(float f) {
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.screenBrightness = Math.max(0.02f, f);
        getWindow().setAttributes(lp);
        flash("Brillo " + Math.round(f * 100) + "%");
    }

    private float curVolume() {
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        int max = Math.max(1, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        return am.getStreamVolume(AudioManager.STREAM_MUSIC) / (float) max;
    }

    private void setVolume(float f) {
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        int max = Math.max(1, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(f * max), 0);
        flash("Volumen " + Math.round(f * 100) + "%");
    }


    /* ---------------------------------------------------------------- menú "Más" */
    private void showMore() {
        final List<String> names = new ArrayList<String>();
        final List<Runnable> acts = new ArrayList<Runnable>();
        names.add("Calidad de video\u2026");
        acts.add(new Runnable() { public void run() { pickQuality(); } });
        names.add("Formato de pantalla: " + aspectName());
        acts.add(new Runnable() { public void run() { arMode = (arMode + 1) % 3; sp.edit().putInt("ar", arMode).apply(); applyAspect(); flash(aspectName()); } });
        names.add("Retraso de subtítulos: " + (subDelay == 0 ? "ninguno" : String.format(Locale.US, "+%.1f s", subDelay / 1000f)) + "  (toca para sumar 0,5 s)");
        acts.add(new Runnable() { public void run() { nextDelay(); } });
        names.add("Subtítulos desde un archivo (.srt, .vtt, .ass)\u2026");
        acts.add(new Runnable() { public void run() { pickSubFile(); } });
        names.add("Modo noche de audio: " + (night ? "activado" : "desactivado"));
        acts.add(new Runnable() { public void run() { toggleNight(); } });
        if (pipOk()) {
            names.add("Imagen en imagen");
            acts.add(new Runnable() { public void run() { enterPip(); } });
        }
        new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle("Más opciones")
                .setItems(names.toArray(new String[0]), new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        acts.get(w).run();
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    /* ---------------------------------------------------------------- calidad de video */
    private void pickQuality() {
        if (player == null) return;
        final List<Tracks.Group> gs = new ArrayList<Tracks.Group>();
        final List<Integer> ts = new ArrayList<Integer>();
        List<String> names = new ArrayList<String>();
        names.add("Automática (recomendada)");
        gs.add(null);
        ts.add(-1);
        boolean forced = false;
        int checked = 0;
        List<int[]> order = new ArrayList<int[]>();
        List<Tracks.Group> groups = new ArrayList<Tracks.Group>();
        for (Tracks.Group g : player.getCurrentTracks().getGroups()) {
            if (g.getType() != C.TRACK_TYPE_VIDEO) continue;
            groups.add(g);
            for (int i = 0; i < g.length; i++) order.add(new int[]{groups.size() - 1, i, g.getTrackFormat(i).height, g.getTrackFormat(i).bitrate});
        }
        java.util.Collections.sort(order, new java.util.Comparator<int[]>() {
            @Override
            public int compare(int[] a, int[] b) {
                return b[2] != a[2] ? b[2] - a[2] : b[3] - a[3];
            }
        });
        for (int[] o : order) {
            Tracks.Group g = groups.get(o[0]);
            if (!g.isTrackSupported(o[1])) continue;
            Format f = g.getTrackFormat(o[1]);
            String label = (f.height > 0 ? f.height + "p" : "Video")
                    + (f.bitrate > 0 ? "  \u00B7  " + String.format(Locale.US, "%.1f Mbps", f.bitrate / 1000000f) : "");
            names.add(label);
            gs.add(g);
            ts.add(o[1]);
            if (g.isTrackSelected(o[1]) && player.getTrackSelectionParameters().overrides.containsKey(g.getMediaTrackGroup())) {
                checked = names.size() - 1;
                forced = true;
            }
        }
        if (names.size() <= 2) {
            Toast.makeText(this, "Este video solo tiene una calidad disponible", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle("Calidad de video")
                .setSingleChoiceItems(names.toArray(new String[0]), forced ? checked : 0, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        if (player == null) {
                            d.dismiss();
                            return;
                        }
                        TrackSelectionParameters.Builder b = player.getTrackSelectionParameters().buildUpon();
                        if (gs.get(w) == null) b.clearOverridesOfType(C.TRACK_TYPE_VIDEO);
                        else b.setOverrideForType(new TrackSelectionOverride(gs.get(w).getMediaTrackGroup(), ts.get(w)));
                        player.setTrackSelectionParameters(b.build());
                        d.dismiss();
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    /* ---------------------------------------------------------------- modo noche (compresor de audio) */
    private android.media.audiofx.Equalizer eqz;

    private void releaseEq() {
        try {
            if (eqz != null) eqz.release();
        } catch (Throwable ignored) { }
        eqz = null;
    }

    /** Ecualizador elegido en la web (ElohimVIP > Ecualizador): 5 bandas en dB, p. ej. "3,1,-1,2,4". */
    private void applyEq() {
        releaseEq();
        String s = sp.getString("eq", "");
        if (s == null || s.length() == 0 || player == null) return;
        int sid = player.getAudioSessionId();
        if (sid == C.AUDIO_SESSION_ID_UNSET || sid == 0) return;
        try {
            String[] g = s.split(",");
            eqz = new android.media.audiofx.Equalizer(0, sid);
            short bands = eqz.getNumberOfBands();
            short[] r = eqz.getBandLevelRange();
            for (short b = 0; b < bands; b++) {
                /* las 5 bandas de la web se reparten entre las que tenga el equipo */
                int gi = bands <= 1 ? 0 : Math.round(b * (g.length - 1f) / (bands - 1f));
                float db = Float.parseFloat(g[Math.min(gi, g.length - 1)].trim());
                int mb = Math.max(r[0], Math.min(r[1], Math.round(db * 100f)));
                eqz.setBandLevel(b, (short) mb);
            }
            eqz.setEnabled(true);
        } catch (Throwable t) {
            releaseEq();
        }
    }

    /** Estilo de subtítulos elegido en la web (ElohimVIP > Subtítulos): "tamaño%,color,fondo,borde". */
    private void applySubStyle() {
        try {
            String[] a = sp.getString("sub", "100,0,1,1").split(",");
            int z = Integer.parseInt(a[0].trim());
            int c = Integer.parseInt(a[1].trim());
            int b = Integer.parseInt(a[2].trim());
            int e = Integer.parseInt(a[3].trim());
            int[] cols = {0xFFFFFFFF, 0xFFFFE45C, 0xFF7FE3FF, 0xFF8DFF9B};
            int fg = cols[Math.max(0, Math.min(3, c))];
            int bg = b == 0 ? 0x00000000 : (b == 1 ? 0x8C000000 : 0xE6000000);
            int edge = e == 0 ? androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_NONE
                    : (e == 1 ? androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW
                    : androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_OUTLINE);
            subs.setStyle(new androidx.media3.ui.CaptionStyleCompat(fg, bg, 0x00000000, edge, 0xFF000000, null));
            subs.setFractionalTextSize(androidx.media3.ui.SubtitleView.DEFAULT_TEXT_SIZE_FRACTION * Math.max(50, Math.min(250, z)) / 100f);
        } catch (Throwable ignored) { }
    }

    private void releaseNight() {
        if (dyn != null) {
            try {
                dyn.setEnabled(false);
                dyn.release();
            } catch (Throwable ignored) { }
            dyn = null;
        }
    }

    /** Reduce los picos de volumen (explosiones) y sube los diálogos. Necesita Android 9 o superior. */
    private void applyNight() {
        releaseNight();
        if (!night || player == null) return;
        if (Build.VERSION.SDK_INT < 28) {
            night = false;
            return;
        }
        int sid = player.getAudioSessionId();
        if (sid == C.AUDIO_SESSION_ID_UNSET || sid == 0) return;
        try {
            android.media.audiofx.DynamicsProcessing.Config cfg = new android.media.audiofx.DynamicsProcessing.Config.Builder(
                    android.media.audiofx.DynamicsProcessing.VARIANT_FAVOR_TIME_RESOLUTION, 2,
                    false, 0, false, 0, false, 0, true).build();
            dyn = new android.media.audiofx.DynamicsProcessing(0, sid, cfg);
            for (int ch = 0; ch < 2; ch++) {
                dyn.setLimiterByChannelIndex(ch, new android.media.audiofx.DynamicsProcessing.Limiter(
                        true, true, 0, 2f, 120f, 8f, -18f, 9f));
            }
            dyn.setEnabled(true);
        } catch (Throwable t) {
            dyn = null;
            night = false;
            flash("Modo noche no disponible en este equipo");
        }
    }

    private void toggleNight() {
        if (Build.VERSION.SDK_INT < 28) {
            Toast.makeText(this, "El modo noche necesita Android 9 o superior", Toast.LENGTH_LONG).show();
            return;
        }
        night = !night;
        sp.edit().putString("night", night ? "1" : "0").apply();
        applyNight();
        flash(night ? "Modo noche activado" : "Modo noche desactivado");
    }

    /* ---------------------------------------------------------------- subtítulos desde un archivo */
    private void pickSubFile() {
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/x-subrip", "text/vtt", "text/plain", "text/x-ssa", "application/octet-stream", "text/*"});
            startActivityForResult(i, REQ_SUB);
        } catch (Throwable t) {
            Toast.makeText(this, "No se pudo abrir el selector de archivos", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_SUB || res != RESULT_OK || data == null || data.getData() == null || player == null) return;
        Uri u = data.getData();
        String name = "subtítulos";
        try {
            Cursor c = getContentResolver().query(u, null, null, null, null);
            if (c != null) {
                if (c.moveToFirst()) {
                    int ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (ix >= 0) name = c.getString(ix);
                }
                c.close();
            }
        } catch (Throwable ignored) { }
        String l = name.toLowerCase(Locale.ROOT), mime = MimeTypes.APPLICATION_SUBRIP;
        if (l.endsWith(".vtt")) mime = MimeTypes.TEXT_VTT;
        else if (l.endsWith(".ass") || l.endsWith(".ssa")) mime = MimeTypes.TEXT_SSA;
        else if (l.endsWith(".ttml") || l.endsWith(".xml") || l.endsWith(".dfxp")) mime = MimeTypes.APPLICATION_TTML;
        try {
            MediaItem cur = player.getCurrentMediaItem();
            if (cur == null) return;
            pendingSub = "Archivo: " + name;
            MediaItem.SubtitleConfiguration sc = new MediaItem.SubtitleConfiguration.Builder(u)
                    .setMimeType(mime)
                    .setLabel(pendingSub)
                    .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                    .build();
            int idx = player.getCurrentMediaItemIndex();
            long pos = Math.max(player.getCurrentPosition(), 0);
            player.replaceMediaItem(idx, cur.buildUpon().setSubtitleConfigurations(Collections.singletonList(sc)).build());
            player.seekTo(idx, pos);
            player.prepare();
            player.play();
            Toast.makeText(this, "Cargando " + name + "\u2026", Toast.LENGTH_SHORT).show();
        } catch (Throwable t) {
            pendingSub = null;
            Toast.makeText(this, "No se pudo cargar ese archivo de subtítulos", Toast.LENGTH_LONG).show();
        }
    }

    /** Cuando el archivo de subtítulos ya está en las pistas, se activa solo. */
    private void selectPendingSub(Tracks tracks) {
        if (pendingSub == null || player == null) return;
        for (Tracks.Group g : tracks.getGroups()) {
            if (g.getType() != C.TRACK_TYPE_TEXT) continue;
            for (int i = 0; i < g.length; i++) {
                Format f = g.getTrackFormat(i);
                if (f.label != null && f.label.equals(pendingSub)) {
                    pendingSub = null;
                    player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon()
                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                            .setOverrideForType(new TrackSelectionOverride(g.getMediaTrackGroup(), i)).build());
                    flash("Subtítulos del archivo activados");
                    return;
                }
            }
        }
    }

    /* ---------------------------------------------------------------- subtítulos: retraso */
    private void nextDelay() {
        long d = subDelay + 500;
        if (d > 10000) d = 0;
        setDelay(d);
        if (d > 0) Toast.makeText(this, "Los subtítulos aparecen " + (d / 1000f) + " s más tarde. "
                + "(Solo se pueden retrasar, no adelantar.) Mantén pulsado para reiniciar.", Toast.LENGTH_LONG).show();
    }

    private void setDelay(long d) {
        subDelay = d;
        bSync.setText(String.format(Locale.US, "Sinc. +%.1f s", d / 1000f));
        flash(d == 0 ? "Subtítulos sin retraso" : String.format(Locale.US, "Subtítulos +%.1f s", d / 1000f));
    }

    /* ---------------------------------------------------------------- audio y subtítulos */
    private String codecName(String mime) {
        if (mime == null) return "";
        if (mime.equals(MimeTypes.AUDIO_AC3)) return "AC3";
        if (mime.equals(MimeTypes.AUDIO_E_AC3) || mime.equals(MimeTypes.AUDIO_E_AC3_JOC)) return "E-AC3";
        if (mime.startsWith("audio/vnd.dts")) return "DTS";
        if (mime.equals(MimeTypes.AUDIO_TRUEHD)) return "TrueHD";
        if (mime.equals(MimeTypes.AUDIO_AAC)) return "AAC";
        if (mime.equals(MimeTypes.AUDIO_MPEG)) return "MP3";
        if (mime.equals(MimeTypes.AUDIO_OPUS)) return "Opus";
        if (mime.equals(MimeTypes.AUDIO_FLAC)) return "FLAC";
        return "";
    }

    private String channels(int n) {
        if (n == 1) return "1.0";
        if (n == 2) return "2.0";
        if (n == 6) return "5.1";
        if (n == 8) return "7.1";
        return n > 0 ? n + "ch" : "";
    }

    private String trackLabel(Format f, int n, int type) {
        String name = null;
        if (f.label != null && f.label.length() > 0) {
            name = f.label;
        } else if (f.language != null && !"und".equals(f.language)) {
            String d = Locale.forLanguageTag(f.language).getDisplayLanguage(new Locale("es"));
            if (d != null && d.length() > 0 && !d.equalsIgnoreCase(f.language)) name = Character.toUpperCase(d.charAt(0)) + d.substring(1);
            else name = f.language;
        }
        if (name == null) name = (type == C.TRACK_TYPE_AUDIO ? "Audio " : "Subtítulo ") + n;
        if (type == C.TRACK_TYPE_AUDIO) {
            String c = codecName(f.sampleMimeType), ch = channels(f.channelCount);
            if (c.length() > 0 || ch.length() > 0) name += "  \u00B7  " + (c + " " + ch).trim();
        } else if ((f.roleFlags & C.ROLE_FLAG_CAPTION) != 0) {
            name += "  (CC)";
        } else if ((f.selectionFlags & C.SELECTION_FLAG_FORCED) != 0) {
            name += "  (forzados)";
        }
        return name;
    }

    private void pickTrack(final int type) {
        if (player == null) return;
        final List<Tracks.Group> gs = new ArrayList<Tracks.Group>();
        final List<Integer> ts = new ArrayList<Integer>();
        final List<Boolean> ok = new ArrayList<Boolean>();
        List<String> names = new ArrayList<String>();
        int checked = -1, n = 0;
        if (type == C.TRACK_TYPE_TEXT) {
            names.add("Desactivados");
            gs.add(null);
            ts.add(-1);
            ok.add(Boolean.TRUE);
            if (player.getTrackSelectionParameters().disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)) checked = 0;
        }
        for (Tracks.Group g : player.getCurrentTracks().getGroups()) {
            if (g.getType() != type) continue;
            for (int i = 0; i < g.length; i++) {
                n++;
                boolean sup = g.isTrackSupported(i);
                names.add(trackLabel(g.getTrackFormat(i), n, type) + (sup ? "" : "  (no compatible)"));
                gs.add(g);
                ts.add(i);
                ok.add(sup);
                if (g.isTrackSelected(i) && checked == -1) checked = names.size() - 1;
            }
        }
        if (n == 0) {
            Toast.makeText(this, type == C.TRACK_TYPE_TEXT ? "Este contenido no trae subtítulos"
                    : "Este contenido no trae pistas de audio para elegir", Toast.LENGTH_SHORT).show();
            return;
        }
        if (checked == -1 && type == C.TRACK_TYPE_TEXT) checked = 0;
        new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle(type == C.TRACK_TYPE_AUDIO ? "Audio" : "Subtítulos")
                .setSingleChoiceItems(names.toArray(new String[0]), checked, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        if (player == null) {
                            d.dismiss();
                            return;
                        }
                        if (!ok.get(w)) {
                            Toast.makeText(PlayerActivity.this, "Este equipo no puede reproducir esa pista", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        TrackSelectionParameters.Builder b = player.getTrackSelectionParameters().buildUpon();
                        if (gs.get(w) == null) {
                            b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true);
                        } else {
                            b.setTrackTypeDisabled(type, false);
                            b.setOverrideForType(new TrackSelectionOverride(gs.get(w).getMediaTrackGroup(), ts.get(w)));
                        }
                        player.setTrackSelectionParameters(b.build());
                        d.dismiss();
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    /** Idioma de audio y subtítulos recordados de la vez anterior. */
    private void applyPrefs() {
        TrackSelectionParameters.Builder b = player.getTrackSelectionParameters().buildUpon();
        String al = sp.getString("al", null), tl = sp.getString("tl", null);
        if (al != null) b.setPreferredAudioLanguage(al);
        if ("off".equals(tl)) {
            b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true);
        } else if (tl != null) {
            b.setPreferredTextLanguage(tl);
            b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false);
        }
        player.setTrackSelectionParameters(b.build());
    }

    private void rememberTracks(TrackSelectionParameters p) {
        SharedPreferences.Editor e = sp.edit();
        boolean ch = false;
        for (TrackSelectionOverride o : p.overrides.values()) {
            if (o.trackIndices.isEmpty()) continue;
            Format f = o.mediaTrackGroup.getFormat(o.trackIndices.get(0));
            if (f.language == null || "und".equals(f.language)) continue;
            if (o.getType() == C.TRACK_TYPE_AUDIO) {
                e.putString("al", f.language);
                ch = true;
            } else if (o.getType() == C.TRACK_TYPE_TEXT) {
                e.putString("tl", f.language);
                ch = true;
            }
        }
        if (p.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)) {
            e.putString("tl", "off");
            ch = true;
        }
        if (ch) e.apply();
    }

    /* ---------------------------------------------------------------- progreso */
    private void snap() {
        if (player == null) return;
        long pos = player.getCurrentPosition(), dur = player.getDuration();
        if (pos >= 0) lastPos = pos;
        if (dur != C.TIME_UNSET && dur > 0) lastDur = dur;
    }

    private void saveProg(int i, long posMs, long durMs, boolean ended) {
        if (live || items == null || i < 0 || i >= items.length()) return;
        try {
            JSONObject it = items.getJSONObject(i);
            String k = it.optString("k", "");
            if (k.length() == 0) return;
            JSONObject e = new JSONObject();
            e.put("p", posMs / 1000);
            e.put("d", durMs / 1000);
            e.put("e", ended ? 1 : 0);
            e.put("m", it);
            prog.put(k, e);
            sp.edit().putString("prog", prog.toString()).apply();
        } catch (Throwable ignored) { }
    }

    /* ---------------------------------------------------------------- errores y reintentos */
    private void retry() {
        if (player == null) return;
        errBox.setVisibility(View.GONE);
        fatal = false;
        liveTry = 0;
        player.prepare();
        player.play();
    }

    private String curUrl() {
        try {
            return stripMark(vars.get(curIdx).get(vi[curIdx]));
        } catch (Throwable t) {
            return "";
        }
    }

    private void external() {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(Uri.parse(curUrl()), "video/*");
            i.putExtra("title", items.getJSONObject(curIdx).optString("t", ""));
            startActivity(Intent.createChooser(i, "Abrir con"));
        } catch (Throwable t) {
            Toast.makeText(this, "No hay otro reproductor instalado (instala VLC)", Toast.LENGTH_LONG).show();
        }
    }

    private void copyLink() {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("enlace", curUrl()));
            Toast.makeText(this, "Enlace copiado", Toast.LENGTH_SHORT).show();
        } catch (Throwable t) {
            Toast.makeText(this, "No se pudo copiar", Toast.LENGTH_SHORT).show();
        }
    }

    private void copyDiag() {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("diagnóstico", PlaybackDiag.report(this)));
            Toast.makeText(this, "Diagnóstico copiado (no incluye enlaces)", Toast.LENGTH_SHORT).show();
        } catch (Throwable t) {
            Toast.makeText(this, "No se pudo copiar", Toast.LENGTH_SHORT).show();
        }
    }

    /** Qué decodificadores se estaban usando. Nunca incluye la URL (lleva usuario y contraseña). */
    private void diagFill(JSONObject o) throws Exception {
        Format a = player.getAudioFormat(), v = player.getVideoFormat();
        if (a != null) {
            o.put("aMime", a.sampleMimeType);
            o.put("aCodecs", a.codecs);
            o.put("aCh", a.channelCount);
        }
        if (v != null) {
            o.put("vMime", v.sampleMimeType);
            o.put("vCodecs", v.codecs);
            o.put("vW", v.width);
            o.put("vH", v.height);
        }
        o.put("aDec", audioDec);
        o.put("vDec", videoDec);
        o.put("ffmpeg", PlaybackDiag.ffmpegAvailable());
    }

    private void logFail(PlaybackException e) {
        try {
            JSONObject o = new JSONObject();
            o.put("code", e.getErrorCodeName());
            o.put("live", live);
            o.put("variant", (curIdx >= 0 && curIdx < vi.length) ? vi[curIdx] : -1);
            o.put("wasReady", wasReady);
            diagFill(o);
            PlaybackDiag.record(this, "error", o);
        } catch (Throwable ignored) { }
    }

    private void logAudioUnsupported(Tracks tracks) {
        try {
            JSONObject o = new JSONObject();
            JSONArray mimes = new JSONArray();
            for (Tracks.Group g : tracks.getGroups()) {
                if (g.getType() != C.TRACK_TYPE_AUDIO) continue;
                for (int i = 0; i < g.length; i++) mimes.put(g.getTrackFormat(i).sampleMimeType);
            }
            o.put("audioTracks", mimes);
            diagFill(o);
            PlaybackDiag.record(this, "audio_unsupported", o);
        } catch (Throwable ignored) { }
    }

    /** Qué decodificador eligió Media3 (p. ej. "c2.android..." = hardware; "ffmpeg..." = software). */
    private final AnalyticsListener analytics = new AnalyticsListener() {
        @Override
        public void onAudioDecoderInitialized(AnalyticsListener.EventTime t, String name, long ts, long dur) {
            audioDec = name == null ? "" : name;
        }

        @Override
        public void onVideoDecoderInitialized(AnalyticsListener.EventTime t, String name, long ts, long dur) {
            videoDec = name == null ? "" : name;
        }
    };

    /** Errores de red/servidor/tiempo agotado: vale la pena reintentar. (Decodificador o formato dañado: no.) */
    private static boolean retryable(PlaybackException e) {
        switch (e.errorCode) {
            case PlaybackException.ERROR_CODE_IO_UNSPECIFIED:
            case PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED:
            case PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT:
            case PlaybackException.ERROR_CODE_IO_INVALID_HTTP_CONTENT_TYPE:
            case PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS:
            case PlaybackException.ERROR_CODE_TIMEOUT:
                return true;
            default:
                return false;
        }
    }

    /** Reconecta el canal en vivo con espera creciente (1,5 s, 3 s, 4,5 s… hasta 8 s) y lo avisa en pantalla. */
    private void liveReconnect() {
        liveTry++;
        final int n = liveTry;
        banner.setText("Reconectando… (" + n + ")");
        banner.setVisibility(View.VISIBLE);
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (player == null || fatal) return;
                banner.setVisibility(View.GONE);
                player.prepare();
                player.play();
            }
        }, Math.min(8000L, 1500L * n));
    }

    private final Player.Listener listener = new Player.Listener() {
        @Override
        public void onPlaybackStateChanged(int state) {
            if (state == Player.STATE_READY) {
                errBox.setVisibility(View.GONE);
                blw = 0;
                wasReady = true;
                liveTry = 0;
            } else if (state == Player.STATE_ENDED) {
                snap();
                saveProg(curIdx, lastDur > 0 ? lastDur : lastPos, lastDur, true);
                finishedAll = true;
                finish();
            }
        }

        @Override
        public void onMediaItemTransition(MediaItem m, int reason) {
            if (player == null) return;
            curIdx = player.getCurrentMediaItemIndex();
            wasReady = false;
            lastPos = 0;
            lastDur = 0;
            audioWarned = false;
            audioDec = "";
            videoDec = "";
            subDelay = 0;
            bSync.setText("Sinc. 0.0 s");
            cueH.removeCallbacksAndMessages(null);
            subs.setCues(Collections.<Cue>emptyList());
            errBox.setVisibility(View.GONE);
            banner.setVisibility(View.GONE);
            refreshTitle();
        }

        @Override
        public void onPositionDiscontinuity(Player.PositionInfo o, Player.PositionInfo n, int reason) {
            cueH.removeCallbacksAndMessages(null);
            subs.setCues(Collections.<Cue>emptyList());
            if (o.mediaItemIndex == n.mediaItemIndex) return;
            if (reason == Player.DISCONTINUITY_REASON_AUTO_TRANSITION) {
                saveProg(o.mediaItemIndex, lastDur > 0 ? lastDur : o.positionMs, lastDur, true);
            } else {
                saveProg(o.mediaItemIndex, o.positionMs, lastDur, false);
            }
        }

        @Override
        public void onCues(CueGroup g) {
            final List<Cue> c = g.cues;
            if (subDelay <= 0) {
                cueH.removeCallbacksAndMessages(null);
                subs.setCues(c);
            } else {
                cueH.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        subs.setCues(c);
                    }
                }, subDelay);
            }
        }

        @Override
        public void onTrackSelectionParametersChanged(TrackSelectionParameters p) {
            rememberTracks(p);
        }

        @Override
        public void onAudioSessionIdChanged(int audioSessionId) {
            if (night) applyNight();
            applyEq();
        }

        @Override
        public void onTracksChanged(Tracks tracks) {
            selectPendingSub(tracks);
            if (night && dyn == null) applyNight();
            if (eqz == null) applyEq();
            boolean hasA = false, okA = false;
            for (Tracks.Group g : tracks.getGroups()) {
                if (g.getType() == C.TRACK_TYPE_AUDIO) {
                    hasA = true;
                    if (g.isSupported()) okA = true;
                }
            }
            if (hasA && !okA && !audioWarned) {
                audioWarned = true;
                logAudioUnsupported(tracks);
                banner.setText(PlaybackDiag.ffmpegAvailable()
                        ? "Este equipo no puede reproducir el audio de este video, ni con el decodificador por software.\nToca aquí para elegir otra pista de audio."
                        : "Este equipo no puede reproducir el audio de este video (AC3/DTS).\nToca aquí para elegir otra pista de audio.");
                banner.setVisibility(View.VISIBLE);
                h.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        banner.setVisibility(View.GONE);
                    }
                }, 12000);
            }
        }

        @Override
        public void onPlayerError(PlaybackException e) {
            if (player == null) return;
            logFail(e);
            /* En vivo: la transmisión se quedó atrás de la ventana disponible. */
            if (e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW && blw++ < 3) {
                player.seekToDefaultPosition();
                player.prepare();
                return;
            }
            /* En vivo: si ya se estaba viendo bien y se cortó la red, reconectar la MISMA variante (con espera creciente). */
            if (live && wasReady && liveTry < 6 && retryable(e)) {
                liveReconnect();
                return;
            }
            /* Probar la siguiente variante de la URL del contenido actual. */
            int i = curIdx;
            if (i >= 0 && i < vars.size() && vi[i] + 1 < vars.get(i).size()) {
                vi[i]++;
                long pos = Math.max(player.getCurrentPosition(), lastPos);
                player.replaceMediaItem(i, item(vars.get(i).get(vi[i])));
                player.seekTo(i, pos);
                player.prepare();
                player.play();
                return;
            }
            /* En vivo, agotadas las variantes: unos reintentos más antes de mostrar el error. */
            if (live && liveTry < 3 && retryable(e)) {
                liveReconnect();
                return;
            }
            fatal = true;
            String m;
            switch (e.errorCode) {
                case PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED:
                case PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT:
                    m = "No se pudo conectar con el servidor. Revisa tu internet o intenta de nuevo.";
                    break;
                case PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS:
                    m = "El servidor rechazó la conexión (puede estar caído o haber llegado al máximo de conexiones).";
                    break;
                case PlaybackException.ERROR_CODE_DECODER_INIT_FAILED:
                case PlaybackException.ERROR_CODE_DECODING_FAILED:
                case PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES:
                case PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED:
                    m = "Este equipo no puede decodificar el video o el audio de este archivo.";
                    break;
                case PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED:
                case PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED:
                    m = "El archivo está dañado o su formato no es compatible.";
                    break;
                default:
                    m = "No se pudo reproducir este contenido.";
            }
            errMsg.setText(m + "\n(" + e.getErrorCodeName() + ")");
            errBox.setVisibility(View.VISIBLE);
            top.setVisibility(View.VISIBLE);
        }
    };
}
