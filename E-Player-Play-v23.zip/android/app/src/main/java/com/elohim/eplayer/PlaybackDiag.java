package com.elohim.eplayer;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Registro LOCAL de fallas de reproducción, para decidir con datos (por equipo, códec y contenedor) qué arreglar.
 * - Guarda solo las últimas {@link #MAX} entradas en SharedPreferences del propio dispositivo.
 * - NUNCA guarda enlaces: las URL de Xtream llevan usuario y contraseña. {@link #report} además
 *   elimina cualquier http(s):// que pudiera colarse.
 * - No envía nada por red: el usuario decide si copia el informe y se lo manda a soporte.
 */
final class PlaybackDiag {
    private static final String PREFS = "np_diag", KEY = "log";
    private static final int MAX = 40;
    private static Boolean ffmpeg;

    private PlaybackDiag() { }

    /** ¿Está presente y cargada la extensión FFmpeg de Media3 (decodificador de audio por software)? */
    static synchronized boolean ffmpegAvailable() {
        if (ffmpeg == null) {
            boolean ok = false;
            try {
                Class<?> c = Class.forName("androidx.media3.decoder.ffmpeg.FfmpegLibrary");
                ok = Boolean.TRUE.equals(c.getMethod("isAvailable").invoke(null));
            } catch (Throwable ignored) {
                /* sin la librería (o sin su .so): se reproduce solo con los decodificadores del equipo */
            }
            ffmpeg = ok;
        }
        return ffmpeg;
    }

    static synchronized void record(Context c, String event, JSONObject fields) {
        try {
            SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            JSONArray old = new JSONArray(sp.getString(KEY, "[]"));
            JSONArray out = new JSONArray();
            for (int i = Math.max(0, old.length() - (MAX - 1)); i < old.length(); i++) out.put(old.get(i));
            JSONObject o = fields == null ? new JSONObject() : fields;
            o.put("t", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()));
            o.put("ev", event);
            out.put(o);
            sp.edit().putString(KEY, out.toString()).apply();
        } catch (Throwable ignored) {
            /* el diagnóstico nunca debe romper la reproducción */
        }
    }

    static synchronized String report(Context c) {
        StringBuilder b = new StringBuilder();
        try {
            String ver = "?";
            try {
                PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
                ver = pi.versionName;
            } catch (Throwable ignored) { }
            b.append("E-Player ").append(ver).append('\n');
            b.append("Equipo: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
                    .append(" (").append(Build.DEVICE).append(")\n");
            b.append("Android ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
            b.append("ABI: ").append(android.text.TextUtils.join(",", Build.SUPPORTED_ABIS)).append('\n');
            b.append("FFmpeg (audio por software): ").append(ffmpegAvailable() ? "sí" : "no").append("\n\n");
            JSONArray a = new JSONArray(c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]"));
            if (a.length() == 0) b.append("(sin fallas registradas)\n");
            for (int i = 0; i < a.length(); i++) b.append(a.get(i).toString()).append('\n');
        } catch (Throwable t) {
            b.append("(no se pudo leer el registro)\n");
        }
        return b.toString().replaceAll("(?i)https?://\\S+", "[enlace]");
    }
}
