/* ===== Licencia (prueba de 30 días, bloqueo con QR) y actualizaciones. Solo dentro de la app Android. ===== */
(function(){
var A=window.AndroidApp,L=window.LIC;if(!A||!L||!L.api)return;
var DAY=864e5,KEY='ep_lic',id=A.deviceId(),cur=A.versionCode(),st=null,locked=false,lockEl=null,lockT=0,big=0,upd=null,updMust=false,updBtn=null,ready=0;
var css=document.createElement('style');
css.textContent='.ep-o{position:fixed;left:0;top:0;right:0;bottom:0;display:flex;align-items:center;justify-content:center;text-align:center;color:#eaf0fa;font-family:system-ui,Roboto,sans-serif;padding:24px;box-sizing:border-box}'
+'.ep-lk{z-index:99990;background:#070a11}.ep-up{z-index:99995;background:#070a11f2}.ep-bg{z-index:99980;background:#070a11e6;cursor:pointer}'
+'.ep-b{position:fixed;top:calc(env(safe-area-inset-top,0px) + 6px);left:50%;transform:translateX(-50%);z-index:99970;background:#0f1522e6;border:1px solid #e9c46a66;color:#e9c46a;border-radius:99px;padding:3px 14px;font:600 .8rem system-ui,sans-serif;pointer-events:none;white-space:nowrap}'
+'.ep-o h1{font:600 clamp(1.6rem,5vw,2.6rem)/1.15 Georgia,serif;margin:0 0 10px}.ep-o p{color:#93a0b8;margin:6px 0;max-width:42ch}'
+'.ep-n{font:600 clamp(5rem,22vw,9rem)/1 Georgia,serif;color:#e9c46a}.ep-cd{font:600 clamp(1.8rem,6vw,2.6rem) Georgia,serif;letter-spacing:.14em;color:#40e0c8;margin:8px 0}'
+'.ep-qr{background:#fff;border-radius:14px;padding:8px;width:clamp(150px,34vh,260px);height:auto;image-rendering:pixelated}'
+'.ep-row{display:flex;gap:min(5vw,44px);align-items:center;justify-content:center;flex-wrap:wrap}.ep-bt{background:#40e0c8;color:#05211d;border:0;border-radius:14px;padding:14px 30px;font:600 1.1rem system-ui,sans-serif;margin:14px 8px 0;cursor:pointer}'
+'.ep-bt.g{background:none;color:#eaf0fa;border:1px solid #243049}.ep-bt:focus{outline:3px solid #fff;outline-offset:3px}';
document.head.appendChild(css);
function el(c,h){var d=document.createElement('div');d.className='ep-o '+c;d.innerHTML=h||'';document.body.appendChild(d);return d}
function rm(e){if(e&&e.parentNode)e.parentNode.removeChild(e)}
function plural(n){return n+(n===1?' día':' días')}
function save(d){try{localStorage.setItem(KEY,JSON.stringify({estado:d.estado,hasta:d.hasta,vida:d.vida}))}catch(e){}}
function cached(){try{var c=JSON.parse(localStorage.getItem(KEY));if(!c)return null;c.dias=Math.max(0,Math.ceil((c.hasta-Date.now())/DAY));if(c.hasta<=Date.now())c.estado='vencido';return c}catch(e){return null}}
function ask(nuevo){
 return Promise.race([fetch(L.api+'/estado?equipo='+id+(nuevo?'&nuevo=1':'')).then(function(r){return r.json()}),new Promise(function(_,j){setTimeout(j,12000)})])
 .then(function(d){if(!d||!d.estado)throw 0;if(d.estado!=='desconocido')save(d);apply(d)})
 .catch(function(){var c=cached();if(c)apply(c)})}
function apply(d){st=d;
 if(d.estado==='vencido'||(d.estado!=='activo'&&d.estado!=='prueba'&&d.estado!=='desconocido'))lock(d);else unlock();
 banner();
 if(d.estado==='prueba'&&d.dias<=3&&!big){big=1;var b=el('ep-bg','<div><div class="ep-n">'+d.dias+'</div><h1>'+(d.dias===1?'Queda 1 día':'Quedan '+d.dias+' días')+' de tu prueba gratis</h1><p>Activa tu TV para no perder el acceso.</p></div>');
  var q=function(){rm(b)};b.onclick=q;setTimeout(q,4000)}}
var bn=null;
function banner(){if(!st||st.estado!=='prueba'||locked){rm(bn);bn=null;return}
 var d=Math.max(0,Math.ceil((st.hasta-Date.now())/DAY));if(!bn){bn=document.createElement('div');bn.className='ep-b';document.body.appendChild(bn)}
 bn.textContent='Prueba gratis · quedan '+plural(d)}
function lock(d){if(locked)return;locked=true;rm(bn);bn=null;
 var url=L.tienda+'/activar?equipo='+id,t=d&&d.bloqueado?'Este equipo está bloqueado':'Tu prueba gratis terminó';
 lockEl=el('ep-lk','<div><h1>'+t+'</h1><p>Escanea el código con tu celular, elige un plan y paga. Esta pantalla se desbloquea sola.</p><div class="ep-row"><img class="ep-qr" id="ep-qi" alt="QR de activación"><div><p>Código de tu TV</p><div class="ep-cd">'+id+'</div><p>o entra a<br><b>'+L.tienda.replace(/^https?:\/\//,'')+'/activar</b></p></div></div></div>');
 try{var q=qrcode(0,'M');q.addData(url);q.make();document.getElementById('ep-qi').src=q.createDataURL(8,2)}catch(e){var i=document.getElementById('ep-qi');if(i)i.style.display='none'}
 try{var v=document.querySelector('video');v&&v.pause()}catch(e){}
 lockT=setInterval(function(){try{var v=document.querySelector('video');v&&v.pause()}catch(e){}ask(false)},6000)}
function unlock(){if(!locked)return;locked=false;clearInterval(lockT);rm(lockEl);lockEl=null;
 var o=el('ep-bg','<div><h1>Tu TV ya está activa</h1><p>Disfruta E-Player.</p></div>');setTimeout(function(){rm(o)},2500)}
/* ---- actualizaciones ---- */
function checkUpd(){fetch(L.tienda+'/version.json?_='+Date.now()).then(function(r){return r.json()}).then(function(v){if(v&&v.code>cur&&!upd)showUpd(v)}).catch(function(){})}
function showUpd(v){upd=el('ep-up','<div><h1>Nueva versión disponible</h1><p id="ep-un">'+(v.notas||'Mejoras y correcciones.')+'</p><div><button class="ep-bt" id="ep-ub">Actualizar ahora</button>'+(v.obligatoria?'':'<button class="ep-bt g" id="ep-ul">Más tarde</button>')+'</div></div>');
 updMust=!!v.obligatoria;updBtn=document.getElementById('ep-ub');var n=document.getElementById('ep-un');
 updBtn.onclick=function(){n.textContent='Descargando…';updBtn.disabled=true;A.installApk(v.url)};
 var l=document.getElementById('ep-ul');if(l)l.onclick=function(){rm(upd);upd=null;setTimeout(function(){},0)};
 window.__upd=function(k,p){if(k==='prog')n.textContent='Descargando… '+p+'%';
  else if(k==='perm'){n.textContent='Activa el permiso “Instalar apps desconocidas” para E-Player y vuelve a tocar Actualizar.';updBtn.disabled=false}
  else if(k==='err'){n.textContent='No se pudo descargar. Revisa tu internet y vuelve a intentar.';updBtn.disabled=false}
  else if(k==='done'){n.textContent='Confirma la instalación en la pantalla que aparece.';updBtn.disabled=false}};
 setTimeout(function(){updBtn.focus()},50)}
/* con el control remoto: mientras hay bloqueo o actualización obligatoria, la app de abajo no recibe teclas */
window.addEventListener('keydown',function(e){var o=(upd&&updMust)?upd:(locked?lockEl:null);if(!o)return;
 if(o.contains(document.activeElement)&&(e.key==='Enter'||e.key===' '))return;
 e.stopImmediatePropagation();e.preventDefault();if(upd&&updMust&&updBtn)updBtn.focus()},true);
ask(true);checkUpd();
setInterval(banner,60000);setInterval(checkUpd,30*60000);setInterval(function(){if(!locked)ask(false)},15*60000);
})();
