/* ===== IPTV Player v4 — núcleo: estado, almacenamiento, red, Xtream, historial, guía (EPG) ===== */
/* Compatible Chromium 53 (webOS 4): nada de padStart, Object.values/entries, finally, AbortController, :focus-within */
var $=function(s){return document.querySelector(s)};
var $$=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s))};
var KEY='iptv_cfg',PAGE=36,PORT=18765,TTL=6*3600*1000,VER='6.2.0-pwa',WEBOS=/web0s|webos/i.test(navigator.userAgent),PROXY=!!window.IPTV_PROXY;
var S={page:'home',mode:'live',cat:'*',q:'',data:{live:[],movie:[],series:[],catOrder:{}},xt:null,view:[],zap:-1,pv:false,pvItem:null,zl:[],zcat:'*',focusItem:null,fi:null,home:null,shown:0,live:false,url:'',epq:null,epi:-1,last:null,acct:null,meta:{},cur:null,unlocked:false,epgUrl:'',xmlP:null,idx:null,rc:0,ovs:[],cfg:null,sleepAt:0,prev:null};
var proxyBase=null,hls=null,mp=null,ttl=0,stall=0,srcType='X',lastSave=0,wt=0,okT=0,ctlT=0,toastT=0;
const h=(t,c,x)=>{const e=document.createElement(t);if(c)e.className=c;if(x!=null)e.textContent=x;return e};
const msg=t=>{$('#msg').textContent=t||''};
/* Proxy (Cloud Function de Firebase): PX() arma la URL; mx() manda por el proxy lo http:// (una página https no puede cargarlo directo) */
const PX=u=>(window.IPTV_PROXY_URL||'/proxy')+'?url='+encodeURIComponent(u);
const mx=u=>PROXY&&/^http:/i.test(u||'')?PX(u):u;
const lsGet=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))||d}catch(e){return d}},lsSet=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}};

/* ---------- Iconos (SVG en línea: no dependen de las fuentes del televisor) ---------- */
const IC={
 skipb:'<path d="M6 5v14"/><path fill="currentColor" stroke="none" d="M19 5.6v12.8a.7.7 0 0 1-1.1.6l-9-6.4a.7.7 0 0 1 0-1.2l9-6.4a.7.7 0 0 1 1.1.6z"/>',
 skipf:'<path d="M18 5v14"/><path fill="currentColor" stroke="none" d="M5 5.6v12.8a.7.7 0 0 0 1.1.6l9-6.4a.7.7 0 0 0 0-1.2l-9-6.4A.7.7 0 0 0 5 5.6z"/>',
 shrink:'<path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/>',
 globe:'<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.6 2.4 3.8 5.3 3.8 8.5s-1.2 6.1-3.8 8.5c-2.6-2.4-3.8-5.3-3.8-8.5S9.4 5.9 12 3.5z"/>',
 link:'<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
 home:'<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10v9.5H10v-5.5h4v5.5h4.5V10"/>',
 tv:'<rect x="3" y="7" width="18" height="12.5" rx="2.5"/><path d="m8 3 4 4 4-4"/>',
 film:'<rect x="3.5" y="4" width="17" height="16" rx="2"/><path d="M8 4v16M16 4v16M3.5 9h4.5M3.5 15h4.5M16 9h4.5M16 15h4.5"/>',
 series:'<rect x="3" y="8.5" width="18" height="11.5" rx="2"/><path d="M7 4.5h10M5 6.5h14"/><path d="m10.5 12.5 4 2.3-4 2.2z"/>',
 star:'<path d="m12 3.6 2.6 5.3 5.8.9-4.2 4.1 1 5.8L12 16.9l-5.2 2.8 1-5.8L3.6 9.8l5.8-.9z"/>',
 starf:'<path fill="currentColor" d="m12 3.6 2.6 5.3 5.8.9-4.2 4.1 1 5.8L12 16.9l-5.2 2.8 1-5.8L3.6 9.8l5.8-.9z"/>',
 search:'<circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/>',
 user:'<circle cx="12" cy="8.5" r="3.8"/><path d="M4.5 20c.8-4 3.8-6 7.5-6s6.7 2 7.5 6"/>',
 sliders:'<path d="M4 7h9M17 7h3M4 17h3M11 17h9"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>',
 play:'<path fill="currentColor" stroke="none" d="M8 5.2v13.6a.8.8 0 0 0 1.2.7l11-6.8a.8.8 0 0 0 0-1.4L9.2 4.5A.8.8 0 0 0 8 5.2z"/>',
 pause:'<rect fill="currentColor" stroke="none" x="6" y="5" width="4.2" height="14" rx="1.2"/><rect fill="currentColor" stroke="none" x="13.8" y="5" width="4.2" height="14" rx="1.2"/>',
 back10:'<path d="M4.5 12a7.5 7.5 0 1 0 2.4-5.5"/><path d="M4.5 4v4.5H9"/><text x="12" y="15.4" font-size="7.2" text-anchor="middle" fill="currentColor" stroke="none" font-weight="700">10</text>',
 fwd10:'<path d="M19.5 12a7.5 7.5 0 1 1-2.4-5.5"/><path d="M19.5 4v4.5H15"/><text x="12" y="15.4" font-size="7.2" text-anchor="middle" fill="currentColor" stroke="none" font-weight="700">10</text>',
 list:'<path d="M9 6h11M9 12h11M9 18h11"/><path d="M4 6h.01M4 12h.01M4 18h.01" stroke-width="3"/>',
 more:'<path d="M5 12h.01M12 12h.01M19 12h.01" stroke-width="3.2"/>',
 close:'<path d="M6 6l12 12M18 6 6 18"/>',
 expand:'<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
 right:'<path d="m9 5 7 7-7 7"/>',left:'<path d="m15 5-7 7 7 7"/>',
 up:'<path d="m5 15 7-7 7 7"/>',down:'<path d="m5 9 7 7 7-7"/>',
 moon:'<path d="M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5z"/>',
 aspect:'<rect x="3" y="6" width="18" height="12" rx="1.8"/><path d="M7 10.5v-2h2M17 13.5v2h-2"/>',
 power:'<path d="M12 3.5v8"/><path d="M6.6 6.8a8 8 0 1 0 10.8 0"/>',
 clock:'<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
 swap:'<path d="M4 8h13l-3-3M20 16H7l3 3"/>',
 guide:'<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M8 9h8M8 13h8M8 17h5"/>',
 speed:'<path d="M4.5 18a8.5 8.5 0 1 1 15 0"/><path d="m12 13 4-4"/>',
 audio:'<path d="M4 10v4h3.5L12 18V6L7.5 10z"/><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11"/>',
 check:'<path d="m5 12.5 4.5 4.5L19 7.5"/>',
 refresh:'<path d="M20 11a8 8 0 1 0-2 5.5"/><path d="M20 4v7h-7"/>',
 eyeoff:'<path d="M3 3l18 18"/><path d="M6.7 7.7A14.5 14.5 0 0 0 2.5 12c1 1.5 4.5 6 9.5 6 1.4 0 2.6-.3 3.8-.8M10.5 6.2A9 9 0 0 1 12 6c5 0 8.5 4.5 9.5 6a14 14 0 0 1-2.2 2.8"/>',
 lock:'<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
 trash:'<path d="M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13"/>',
 users:'<path d="M16 3.5l4 4-4 4M20 7.5H9M8 20.5l-4-4 4-4M4 16.5h11"/>',
 info:'<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5M12 8h.01" stroke-width="2.4"/>',
 hist:'<path d="M4 12a8 8 0 1 0 2.5-5.8"/><path d="M4 4.5V9h4.5"/><path d="M12 8v4.5l3 1.5"/>'};
const ic=n=>'<svg class="ic" viewBox="0 0 24 24" aria-hidden="true">'+(IC[n]||'')+'</svg>';
const setIc=(el,n,t)=>{el.innerHTML=ic(n);if(t!=null){const s=document.createElement('span');s.textContent=t;el.appendChild(s)}return el};

/* ---------- Ajustes y datos guardados ---------- */
const FAVS=lsGet('iptv_fav',{}),HIST=lsGet('iptv_hist',{}),SEEN=lsGet('iptv_seen',{}),LAST=lsGet('iptv_last',{});let ACCTS=lsGet('iptv_accts',[]);
const CFG=Object.assign({fx:'auto',pin:'',epg:'',fmt:'auto',sort:'orig',pv:1,pvs:0,start:'home',ar:'fit',h12:0,hide:{},lc:{}},lsGet('iptv_set',{}));
['live','movie','series'].forEach(m=>{if(!Array.isArray(CFG.hide[m]))CFG.hide[m]=[]});
const saveCfg=()=>lsSet('iptv_set',CFG);
/* ---------- v6 rendimiento: «modo ligero» (sin desenfoques ni animaciones pesadas) en TV y equipos modestos ---------- */
const TVUA=WEBOS||/smart-?tv|tizen|bravia|hbbtv|googletv|android tv|crkey|\baft[a-z]+\b/i.test(navigator.userAgent)||(/android/i.test(navigator.userAgent)&&!('ontouchstart' in window)&&!navigator.maxTouchPoints);
const isLite=()=>CFG.fx==='lite'||(CFG.fx!=='full'&&(TVUA||(navigator.hardwareConcurrency||8)<=4));
const applyFx=()=>document.body.classList.toggle('lite',isLite());applyFx();
let HS={};const rebuildHide=()=>{HS={live:hideSet(CFG.hide.live),movie:hideSet(CFG.hide.movie),series:hideSet(CFG.hide.series)}};rebuildHide();
const markSeen=u=>{SEEN[u]=Date.now();const ks=Object.keys(SEEN);if(ks.length>800){ks.sort((a,b)=>SEEN[a]-SEEN[b]).slice(0,200).forEach(k=>delete SEEN[k])}lsSet('iptv_seen',SEEN)};
const fk=i=>i.type==='series'?'series|'+(i.sid||i.name):i.type+'|'+(i.url||i.sid||i.name);
const isFav=i=>!!FAVS[fk(i)];
const DEMO_M3U='#EXTM3U\n'+
'#EXTINF:-1 tvg-id="demo1" tvg-type="live" group-title="Demostración TV",Canal de prueba 1 (Big Buck Bunny)\nhttps://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8\n'+
'#EXTINF:-1 tvg-id="demo2" tvg-type="live" group-title="Demostración TV",Canal de prueba 2 (Tears of Steel)\nhttps://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8\n'+
'#EXTINF:-1 tvg-type="movie" group-title="Películas de demostración",Big Buck Bunny (2008)\nhttps://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8\n'+
'#EXTINF:-1 tvg-type="movie" group-title="Películas de demostración",Tears of Steel (2012)\nhttps://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8\n'+
'#EXTINF:-1 tvg-type="series" group-title="Series de demostración",Serie de prueba S01E01\nhttps://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8\n'+
'#EXTINF:-1 tvg-type="series" group-title="Series de demostración",Serie de prueba S01E02\nhttps://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8\n';
const hidden=i=>{if(!S.unlocked&&(i.adult||isAdult(i.cat,i.name)))return true;const hs=HS[i.type];return!!(hs&&hs[i.cat])};
const favItems=m=>S.data[m].filter(i=>!hidden(i)&&isFav(i));
const favCount=()=>favItems('live').length+favItems('movie').length+favItems('series').length;
const liveMeta=i=>({name:i.name,logo:i.logo,type:'live',sid:i.sid,tid:i.tid,cat:i.cat});
const tmo=(p,ms)=>new Promise((res,rej)=>{const t=setTimeout(()=>rej(Error('Tiempo de espera agotado')),ms);p.then(v=>{clearTimeout(t);res(v)},e=>{clearTimeout(t);rej(e)})});
const acctErr=m=>{const e=Error(m);e.acct=true;return e};
function toast(t,ms){const e=$('#toast');e.textContent=t;e.classList.remove('hidden');clearTimeout(toastT);toastT=setTimeout(()=>e.classList.add('hidden'),ms||5000)}
const nav=()=>{try{history.pushState({n:1},'')}catch(e){}};
const narrow=()=>window.innerWidth<900;
let TOUCH=false;window.addEventListener('touchstart',()=>{TOUCH=true;document.body.classList.add('touch')},{passive:true});

/* ---------- Capas (overlays): pila para que «Atrás» cierre siempre la de arriba ---------- */
const playerFull=()=>!$('#pl').classList.contains('hidden')&&!S.pv;
function ovOpen(id,onClose){const e=$(id);if(e.classList.contains('hidden'))nav();e.textContent='';e.classList.remove('hidden');e._from=document.activeElement;e._close=onClose||null;
 S.ovs=S.ovs.filter(x=>x.id!==id);S.ovs.push({id:id,up:playerFull()});return e}
function ovClose(id){const e=$(id);if(!e||e.classList.contains('hidden'))return;e.classList.add('hidden');S.ovs=S.ovs.filter(x=>x.id!==id);
 const f=e._from,c=e._close;e._from=null;e._close=null;if(c)c();
 if(f&&document.body.contains(f)&&f.offsetWidth>0&&!f.closest('.hidden'))f.focus()}
/* capa que recibe el control ahora (si el video está en pantalla completa, solo cuentan las capas abiertas por encima) */
function activeOv(){const t=S.ovs[S.ovs.length-1];if(!t)return null;return(t.up||!playerFull())?$(t.id):null}

/* ---------- Red: directo -> (si falla) proxy local webOS / proxy de pruebas ---------- */
const startProxy=()=>new Promise(res=>{if(proxyBase)return res(proxyBase);
 try{const b=new PalmServiceBridge();b.onservicecallback=m=>{try{const r=JSON.parse(m);if(r.returnValue)proxyBase='http://127.0.0.1:'+(r.port||PORT)+'/p?u='}catch(e){}res(proxyBase)};
  b.call('luna://com.elohimsystem.player.service/start','{}');setTimeout(()=>res(proxyBase),10000)}catch(e){res(null)}});
async function get(u){
 if(PROXY)return tmo(fetch(PX(u)),60000);
 try{return await tmo(fetch(u),45000)}catch(e){const p=WEBOS?await startProxy():null;if(!p)throw e;return tmo(fetch(p+encodeURIComponent(u)),60000)}}
async function jget(u){const r=await get(u);if(!r.ok)throw Error('HTTP '+r.status);const t=(await r.text()).replace(/^﻿/,'');try{return JSON.parse(t)}catch(e){throw Error('El servidor no respondió con datos válidos (¿URL/puerto incorrectos?)')}}

/* ---------- Caché del catálogo (IndexedDB) ---------- */
const idb=()=>new Promise((res,rej)=>{try{const r=indexedDB.open('iptv',1);r.onupgradeneeded=()=>r.result.createObjectStore('c');r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)}catch(e){rej(e)}});
const cacheGet=k=>idb().then(d=>new Promise(res=>{const q=d.transaction('c').objectStore('c').get(k);q.onsuccess=()=>res(q.result||null);q.onerror=()=>res(null)})).catch(()=>null);
const cacheSet=(k,v)=>idb().then(d=>{d.transaction('c','readwrite').objectStore('c').put(v,k)}).catch(()=>{});

/* ---------- Xtream Codes ---------- */
async function loadXtream(base,u,p,force){
 const E=encodeURIComponent,api=a=>jget(base+'/player_api.php?username='+E(u)+'&password='+E(p)+(a?'&action='+a:''));
 const info=await api('');const ui=info&&info.user_info;
 if(!ui||+ui.auth!==1)throw acctErr('Usuario o contraseña inválidos');
 if(/banned|disabled/i.test(ui.status||''))throw acctErr('Cuenta '+ui.status+' (contacta a tu proveedor)');
 if(/expired/i.test(ui.status||''))throw acctErr('Cuenta vencida'+(+ui.exp_date?' el '+fmtDay(+ui.exp_date*1000):'')+' (contacta a tu proveedor)');
 const key='x|'+base+'|'+u,acts=['get_live_categories','get_live_streams','get_vod_categories','get_vod_streams','get_series_categories','get_series'];
 let c=force?null:await cacheGet(key),L,from=0;
 if(c&&c.L&&Date.now()-c.ts<TTL){L=c.L;from=c.ts}
 else{let done=0,errs=0;L=await Promise.all(acts.map(a=>api(a).catch(()=>{errs++;return[]}).then(r=>{msg('Cargando contenido… '+(++done)+'/6');return r})));
  if(errs===acts.length)throw Error('No se pudo leer el catálogo del servidor');cacheSet(key,{ts:Date.now(),L:L})}
 const fm=pickFormat(ui.allowed_output_formats,CFG.fmt),d=mapXtream({L:L},base,u,p,fm);
 S.xt={base:base,u:u,p:p,api:api};S.fromCache=from;
 S.acct={type:'X',info:info,host:base,user:u,counts:{live:d.live.length,movie:d.movie.length,series:d.series.length}};return d}
async function seriesEps(it){
 if(it.eps)return it;const d=await S.xt.api('get_series_info&series_id='+it.sid);
 const e=mapEpisodes(d,S.xt.base,S.xt.u,S.xt.p);if(!Object.keys(e).length)throw Error('Sin episodios disponibles');
 it.eps=e;it.meta=d.info||{};return it}

/* ---------- Historial / continuar viendo ---------- */
const pos=u=>{const e=HIST[u];return e&&!e.live?e.t||0:0};
function pruneHist(){const ks=Object.keys(HIST).sort((a,b)=>HIST[b].ts-HIST[a].ts);let l=0,v=0;ks.forEach(k=>{if(HIST[k].live){if(++l>40)delete HIST[k]}else if(++v>60)delete HIST[k]})}
function saveHist(k,o){HIST[k]=Object.assign({ts:Date.now()},o);pruneHist();lsSet('iptv_hist',HIST)}
function idx(mode){if(!S.idx)S.idx={};if(!S.idx[mode]){const o={};S.data[mode].forEach(i=>{if(i.url)o[i.url]=i});S.idx[mode]=o}return S.idx[mode]}
function histEntryItem(e){
 if(e.live)return idx('live')[e.url]||{name:e.name,logo:e.logo,cat:'Recientes',type:'live',url:e.url,tid:e.tid,sid:e.sid};
 if(e.type==='ep')return{name:e.name,logo:e.logo,cat:'Continuar viendo',type:'ep',url:e.url};
 return idx('movie')[e.url]||{name:e.name,logo:e.logo,cat:'Continuar viendo',type:'movie',url:e.url}}
function histItems(mode){
 return Object.keys(HIST).map(k=>Object.assign({url:k},HIST[k])).filter(e=>mode==='live'?e.live:!e.live&&(mode==='series'?e.type==='ep':e.type!=='ep'))
  .sort((a,b)=>b.ts-a.ts).slice(0,40).map(histEntryItem)}
/* «Continuar viendo» del inicio: películas y episodios mezclados, lo más reciente primero */
function vodHist(){return Object.keys(HIST).map(k=>Object.assign({url:k},HIST[k])).filter(e=>!e.live&&e.t>10).sort((a,b)=>b.ts-a.ts).slice(0,30).map(histEntryItem)}
function saveLast(i){const m=liveMeta(i);m.url=i.url;if(LAST.cur&&LAST.cur.url!==m.url)LAST.prev=LAST.cur;LAST.cur=m;lsSet('iptv_last',LAST)}

/* ---------- Guía (EPG): caché de 2 min, cola de 3 en paralelo para no saturar al proveedor ---------- */
const EPGC={},INFL={},EQ=[],EPGTTL=120000;let eact=0;
const epgKey=i=>i.sid?'s'+i.sid:i.tid?'t'+i.tid:'';
function epgPeek(i){const k=epgKey(i),c=k&&EPGC[k];return c&&Date.now()-c.ts<EPGTTL?c.L.filter(x=>x.end>Date.now()):null}
function epgFor(i){const k=epgKey(i);if(!k)return Promise.resolve([]);const p=epgPeek(i);if(p)return Promise.resolve(p);
 if(INFL[k])return INFL[k];
 const pr=epgRaw(i).then(L=>{EPGC[k]={ts:Date.now(),L:L};delete INFL[k];return L},()=>{delete INFL[k];EPGC[k]={ts:Date.now(),L:[]};return[]});INFL[k]=pr;return pr}
async function epgRaw(i){const now=Date.now();
 if(S.xt&&i.sid){try{const d=await S.xt.api('get_short_epg&stream_id='+i.sid+'&limit=5');return(d.epg_listings||[]).map(x=>({title:b64u(x.title),desc:b64u(x.description||''),start:+x.start_timestamp*1000,end:+x.stop_timestamp*1000})).filter(x=>x.end>now)}catch(e){return[]}}
 if(i.tid&&S.epgUrl){S.xmlP=S.xmlP||(async()=>{try{const r=await get(S.epgUrl);return r.ok?await r.text():''}catch(e){return''}})();const x=await S.xmlP;if(x)return epgFromXml(x,i.tid,now)}
 return[]}
/* pide la guía solo de lo que se ve en pantalla */
function epgLazy(el,i,cb){const p=epgPeek(i);if(p){cb(p);return}if(!epgKey(i))return;EQ.push({el:el,i:i,cb:cb});pump()}
function pump(){while(eact<3&&EQ.length){const j=EQ.shift();if(!document.body.contains(j.el))continue;
  const r=j.el.getBoundingClientRect();if(r.bottom<-window.innerHeight||r.top>window.innerHeight*2)continue;
  eact++;epgFor(j.i).then(L=>{if(document.body.contains(j.el))j.cb(L)}).then(()=>{eact--;pump()},()=>{eact--;pump()})}}
const hm=t=>fmtClock(t,CFG.h12);
