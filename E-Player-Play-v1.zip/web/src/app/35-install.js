/* ===== v6.2 — banner de instalación (PWA) =====
   Aparece solo cuando se puede instalar (Chrome/Edge/Android: evento beforeinstallprompt; iPhone/iPad: instrucciones de Safari).
   No aparece: ya instalada, en TV/webOS, mientras ves video o escribes, ni tras cerrarlo (3 días, luego 14, y a la 3.ª vez nunca). */
IC.dl='<path d="M12 4v10m0 0-4-4m4 4 4-4M5 19.5h14"/>';
IC.share='<path d="M12 15V4m0 0L8.5 7.5M12 4l3.5 3.5M8 10H6.5a1 1 0 0 0-1 1v8.5a1 1 0 0 0 1 1h11a1 1 0 0 0 1-1V11a1 1 0 0 0-1-1H16"/>';
const PWB={k:'iptv_pwa',el:null,closed:0,t:0};
const IOS=/iphone|ipad|ipod/i.test(navigator.userAgent)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1);
const pwSt=()=>lsGet(PWB.k,{n:0,ts:0,done:0});
function pwEligible(){
 if(PWA_ON()||TVUA||WEBOS)return false;
 if(!/^https?:$/.test(location.protocol)||/;\s*wv\)/.test(navigator.userAgent))return false;
 const s=pwSt();if(s.done||s.n>=3)return false;
 if(s.ts&&Date.now()-s.ts<(s.n>=2?14:3)*864e5)return false;
 return !!window.PWA_EV||IOS}
const pwBusy=()=>playerFull()||S.ovs.length>0||(document.activeElement&&document.activeElement.tagName==='INPUT');
function pwHide(kind){const el=PWB.el;if(!el)return;PWB.el=null;PWB.closed=1;clearInterval(PWB.t);
 if(kind==='no'){const s=pwSt();s.n=(s.n||0)+1;s.ts=Date.now();lsSet(PWB.k,s)}
 el.classList.add('out');setTimeout(()=>{if(el.parentNode)el.parentNode.removeChild(el)},420)}
function pwDone(){const el=PWB.el;lsSet(PWB.k,{n:0,ts:0,done:1});if(!el)return;
 const c=el.querySelector('.pwab-card');c.className='pwab-card ok';c.textContent='';c.appendChild(h('i','pwab-sheen'));
 const o=h('div','pwab-okb');o.innerHTML='<svg class="pwab-chk" viewBox="0 0 52 52" aria-hidden="true"><circle cx="26" cy="26" r="23"/><path d="M15 27l8 8 14-16"/></svg>';
 const t=h('div','pwab-tx');t.appendChild(h('b','','¡Instalada!'));t.appendChild(h('span','','Búscala en tu pantalla de inicio o en tus apps.'));o.appendChild(t);c.appendChild(o);
 setTimeout(()=>pwHide('done'),2600)}
function pwGo(){const ev=window.PWA_EV;if(!ev)return;window.PWA_EV=null;
 try{ev.prompt();Promise.resolve(ev.userChoice).then(r=>{if(r&&r.outcome==='accepted')pwDone();else pwHide('no')},()=>pwHide('no'))}catch(e){pwHide('no')}}
function pwShow(){
 if(PWB.el)return;const ios=!window.PWA_EV&&IOS;
 const w=h('div','pwab'),c=h('div','pwab-card');w.setAttribute('role','dialog');w.setAttribute('aria-label','Instalar ElohimPlayer');
 c.appendChild(h('i','pwab-sheen'));
 const x=h('button','pwab-x');x.setAttribute('aria-label','Cerrar');x.innerHTML=ic('close');x.onclick=()=>pwHide('no');c.appendChild(x);
 const hd=h('div','pwab-hd'),ico=h('div','pwab-ico');ico.appendChild(h('i','pwab-ring'));ico.appendChild(h('i','pwab-ring r2'));
 const im=h('img');im.src='icon-192.png';im.alt='';ico.appendChild(im);hd.appendChild(ico);
 const tx=h('div','pwab-tx');tx.appendChild(h('b','','Instala ElohimPlayer'));tx.appendChild(h('span','',ios?'Añádela a tu pantalla de inicio y ábrela como una app.':'Tu TV, películas y series como una app de verdad.'));hd.appendChild(tx);c.appendChild(hd);
 if(ios){const st=h('ol','pwab-st');
  const a=h('li');a.appendChild(h('span','',"Toca "));const s1=h('u');s1.innerHTML=ic('share');a.appendChild(s1);a.appendChild(h('span','',' Compartir'));st.appendChild(a);
  st.appendChild(h('li','','Elige «Añadir a pantalla de inicio»'));c.appendChild(st)}
 else{const ul=h('ul','pwab-ft');['Pantalla completa','Acceso directo','Abre al instante'].forEach(t=>{const li=h('li');li.innerHTML=ic('check');li.appendChild(h('span','',t));ul.appendChild(li)});c.appendChild(ul)}
 const ac=h('div','pwab-ac'),go=h('button','pwab-go');
 if(ios){go.appendChild(h('span','','Entendido'));go.onclick=()=>pwHide('no')}
 else{go.innerHTML=ic('dl');go.appendChild(h('span','','Instalar app'));go.onclick=pwGo}
 ac.appendChild(go);if(!ios){const no=h('button','pwab-no','Ahora no');no.onclick=()=>pwHide('no');ac.appendChild(no)}c.appendChild(ac);
 w.appendChild(c);document.body.appendChild(w);PWB.el=w}
PWB.t=setInterval(()=>{
 if(PWB.closed){clearInterval(PWB.t);return}
 if(PWB.el){PWB.el.classList.toggle('away',!!playerFull());return}
 if(performance.now()<3500||!pwEligible()||pwBusy())return;pwShow()},1000);
window.addEventListener('appinstalled',()=>{if(PWB.el)pwDone();else lsSet(PWB.k,{n:0,ts:0,done:1})});
document.addEventListener('keydown',e=>{if(PWB.el&&e.keyCode===27){e.stopPropagation();pwHide('no')}},true);
