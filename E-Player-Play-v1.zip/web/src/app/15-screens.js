/* ===== v4 — búsqueda, detalle, perfil, categorías ocultas y PIN ===== */
const btn=(p,t,fn,c,icon)=>{const b=h('button','f'+(c?' '+c:''));if(icon)setIc(b,icon,t);else b.textContent=t;b.onclick=fn;p.appendChild(b);return b};
const msgC=t=>{const m=$('#pfm');if(m)m.textContent=t};

/* ---------- Búsqueda global ---------- */
function openSearch(scope){
 const p=ovOpen('#sr');S.sr={scope:scope||'all'};
 const hd=h('div','srh'),inp=h('input','f');inp.id='srq';inp.placeholder='Buscar canales, películas y series…';inp.setAttribute('autocapitalize','off');inp.setAttribute('autocorrect','off');
 const cl=h('button','f ib');setIc(cl,'close');cl.setAttribute('aria-label','Cerrar');cl.onclick=()=>ovClose('#sr');hd.appendChild(inp);hd.appendChild(cl);p.appendChild(hd);
 const chips=h('div','chips');[['all','Todo'],['live','TV en vivo'],['movie','Películas'],['series','Series']].forEach(c=>{const b=h('button','f chip'+(S.sr.scope===c[0]?' on':''),c[1]);b.onclick=()=>{S.sr.scope=c[0];$$('.chip',chips).forEach(x=>x.classList.toggle('on',x===b));runSearch()};chips.appendChild(b)});p.appendChild(chips);
 const res=h('div','srr');res.id='srr';p.appendChild(res);let t=0;inp.oninput=()=>{clearTimeout(t);t=setTimeout(runSearch,160)};runSearch();inp.focus()}
function runSearch(){const inp=$('#srq');if(!inp)return;const q=inp.value||'',box=$('#srr');box.textContent='';
 if(!q.trim()){box.appendChild(h('p','dm','Escribe el nombre de un canal, película o serie.'));return}
 const R=searchLists(S.data,q,S.sr.scope,hidden,60);
 if(!R.live.length&&!R.movie.length&&!R.series.length){box.appendChild(emptyBox('Sin resultados para «'+q.trim()+'»','Prueba con menos letras, o revisa que su categoría no esté oculta.'));return}
 [['live','Canales'],['movie','Películas'],['series','Series']].forEach(x=>{const a=R[x[0]];if(a.length)box.appendChild(mkRow({t:x[1],a:a,total:a.length}))})}

/* ---------- Detalle (películas / series) ---------- */
function setMeta(m,txt){m.textContent='';String(txt||'').split(/\s+·\s+/).filter(Boolean).forEach(x=>m.appendChild(h('span','mc'+(x.charAt(0)==='★'?' cr':''),x)))}
function setBack(p,url,sharp){if(!url||typeof url!=='string')return;let b=p.querySelector('.dbg');if(!b){b=h('div','dbg');p.insertBefore(b,p.firstChild)}
 const im=document.createElement('img');im.onload=()=>{b.classList.toggle('sharp',!!sharp);b.appendChild(im);setTimeout(()=>{$$('img',b).forEach(x=>{if(x!==im&&x.parentNode)x.parentNode.removeChild(x)})},1300)};im.onerror=()=>{};im.src=mx(url)}
function detHead(p,i){setBack(p,i.logo,false);const d=h('div','dh');if(i.logo){const w=h('div','dpw'),im=h('img','dp');im.src=mx(i.logo);im.onerror=()=>w.remove();w.appendChild(im);w.appendChild(h('u','sh'));d.appendChild(w)}
 const t=h('div','dt'),m=h('p','dm chips'),pl=h('p','dpl',i.plot||'Cargando información…'),acts=h('div','acts');setMeta(m,metaLine(i,{genre:i.genre}));
 t.appendChild(h('h2','',i.name));t.appendChild(m);t.appendChild(pl);t.appendChild(acts);d.appendChild(t);p.appendChild(d);return{m:m,pl:pl,t:t,acts:acts}}
const playMeta=(i,type,name)=>({name:name||i.name,logo:i.logo,type:type,cat:i.cat,sid:type==='ep'?i.sid:undefined,sn:type==='ep'?i.name:undefined});
function flatEps(i){const E=i.eps,seasons=Object.keys(E).sort((a,b)=>a-b),flat=[];seasons.forEach(s=>{E[s].sort((a,b)=>a.n-b.n).forEach(e=>{e.s=s;e.fullTitle=i.name+' - T'+s+' '+e.title;flat.push(e)})});return{seasons:seasons,flat:flat}}
function playEpisode(i,flat,e){S.cur=i;S.epq=flat;S.epi=flat.indexOf(e);S.zap=-1;play(e.url,e.fullTitle,false,null,playMeta(i,'ep',e.fullTitle))}
async function resumeSeries(sid,url){const it=S.data.series.filter(x=>String(x.sid)===String(sid))[0];if(!it)return false;
 try{await seriesEps(it);const f=flatEps(it),e=f.flat.filter(x=>x.url===url)[0];if(!e)return false;playEpisode(it,f.flat,e);return true}catch(er){return false}}
async function showDetail(i){
 const p=ovOpen('#eps',()=>{S.detail=null}),H=detHead(p,i);S.detail=i;const acts=H.acts,favTxt=()=>isFav(i)?'En favoritos':'Agregar a favoritos',favIc=()=>isFav(i)?'starf':'star';
 const close=()=>ovClose('#eps');
 if(i.type==='movie'){
  const t=pos(i.url),go=s=>{S.cur=i;S.epq=null;S.zap=-1;play(i.url,i.name,false,null,playMeta(i,'movie'),s)};
  const first=t>10?btn(acts,'Continuar desde '+fmtDur(t),()=>go(t),'main','play'):null;btn(acts,t>10?'Desde el inicio':'Reproducir',()=>go(0),first?'':'main','play');
  const fb=btn(acts,favTxt(),()=>{toggleFav(i);setIc(fb,favIc(),favTxt())},'','star');setIc(fb,favIc(),favTxt());btn(acts,'Volver',close,'','left');(first||acts.querySelector('.f')).focus();
  if(S.xt&&i.vid){try{const d=await S.xt.api('get_vod_info&vod_id='+i.vid),x=d.info||{};INFO[i.vid]=x;setBack(p,[].concat(x.backdrop_path||[])[0],true);H.pl.textContent=x.plot||x.description||'Sin sinopsis disponible.';setMeta(H.m,metaLine(i,x));
   const ex=[x.director?'Director: '+x.director:'',x.cast?'Reparto: '+x.cast:''].filter(Boolean).join('\n');if(ex)H.t.insertBefore(h('p','dx',ex),acts)}catch(e){H.pl.textContent=''}}
  else H.pl.textContent='';return}
 /* serie */
 const fb=btn(acts,favTxt(),()=>{toggleFav(i);setIc(fb,favIc(),favTxt())},'','star');setIc(fb,favIc(),favTxt());btn(acts,'Volver',close,'','left');acts.querySelector('.f').focus();
 try{await seriesEps(i);const x=i.meta||{};setBack(p,[].concat(x.backdrop_path||[])[0],true);H.pl.textContent=i.plot||x.plot||'';setMeta(H.m,metaLine(i,x));
  const F=flatEps(i),E=i.eps,seasons=F.seasons,flat=F.flat;
  const sb=h('div','sb'),list=h('div','el');p.appendChild(sb);p.appendChild(list);
  const last=flat.filter(e=>HIST[e.url]).sort((a,b)=>HIST[b.url].ts-HIST[a.url].ts)[0],nxt=flat.filter(e=>!SEEN[e.url])[0]||flat[0],res=last||nxt;let cur=res.s;
  const rb=h('button','f main');setIc(rb,'play',(last?'Continuar T'+res.s+' · E'+res.n:'Ver T'+res.s+' · E'+res.n));rb.onclick=()=>playEpisode(i,flat,res);acts.insertBefore(rb,acts.firstChild);rb.focus();
  const draw=s=>{cur=s;sb.textContent='';seasons.forEach(k=>btn(sb,'Temporada '+k,()=>{draw(k);const f=list.querySelector('.f');f&&f.focus()},'chip'+(k===s?' on':'')));list.textContent='';
   E[s].forEach(e=>{const t=pos(e.url),he=HIST[e.url],r=h('div','ep f');r.tabIndex=0;r.appendChild(h('b','en','E'+e.n));r.appendChild(h('span','tt',e.title.replace(/^E\d+\s*-\s*/,'')||e.title));
    if(e.dur&&e.dur!=='00:00:00')r.appendChild(h('small','',e.dur));
    if(SEEN[e.url]){const o=h('span','ok');setIc(o,'check','Visto');r.appendChild(o)}else if(t>10)r.appendChild(h('small','',fmtDur(t)));
    if(he&&he.d&&t>10){const g=h('u','pgb'),w=h('s');w.style.width=Math.min(100,100*t/he.d)+'%';g.appendChild(w);r.appendChild(g)}
    r.onclick=()=>playEpisode(i,flat,e);list.appendChild(r)})};
  draw(cur)}
 catch(err){H.pl.textContent='No se pudieron cargar los episodios: '+err.message}}

/* ---------- PIN ---------- */
function pinPrompt(title){return new Promise(res=>{const p=ovOpen('#pin');p.appendChild(h('h2','',title));
 const i=h('input','f');i.type='password';i.maxLength=4;i.placeholder='PIN de 4 dígitos';i.setAttribute('inputmode','numeric');p.appendChild(i);
 let done=false;const fin=v=>{if(done)return;done=true;p._c=null;ovClose('#pin');res(v)};p._c=()=>fin(null);
 const row=h('div','acts');p.appendChild(row);btn(row,'Aceptar',()=>fin(i.value),'main');btn(row,'Cancelar',()=>fin(null));i.focus()})}

/* ---------- Categorías visibles ---------- */
function openCats(){S.cmMode=isBrowse(S.page)?S.page:(S.cmMode||'live');S.catsDirty=false;
 const p=ovOpen('#cm',()=>{if(S.catsDirty){S.catsDirty=false;rebuildHide();rerender()}});drawCats(p,0)}
function drawCats(p,fi){p.textContent='';const m=S.cmMode;p.appendChild(h('h1','pgt','Categorías visibles'));p.appendChild(h('p','dm lead','Oculta las categorías que no usas: desaparecen de las listas, del inicio y de la búsqueda.'));
 const chips=h('div','chips');MODES.forEach(x=>{const b=h('button','f chip'+(m===x[0]?' on':''),x[1]+(CFG.hide[x[0]].length?' ('+CFG.hide[x[0]].length+' ocultas)':''));b.onclick=()=>{S.cmMode=x[0];drawCats(p,0)};chips.appendChild(b)});p.appendChild(chips);
 const items=S.data[m].filter(i=>!(!S.unlocked&&(i.adult||isAdult(i.cat,i.name)))),g=groupByCat(items,S.data.catOrder[m]),list=h('div','slist');
 g.names.forEach(n=>{const off=!!HS[m][n],r=h('div','srow f'+(off?' off':''));r.tabIndex=0;r.appendChild(h('span','sl',n));r.appendChild(h('small','',String(g.by[n].length)));
  const v=h('span','sv');setIc(v,off?'eyeoff':'check',off?'Oculta':'Visible');r.appendChild(v);
  r.onclick=()=>{const k=$$('.f',p).indexOf(r);CFG.hide[m]=toggleIn(CFG.hide[m],n);saveCfg();rebuildHide();S.catsDirty=true;drawCats(p,k)};list.appendChild(r)});
 if(!g.names.length)list.appendChild(h('p','dm','Esta sección no tiene categorías.'));p.appendChild(list);
 const acts=h('div','acts');p.appendChild(acts);
 if(CFG.hide[m].length)btn(acts,'Mostrar todas',()=>{CFG.hide[m]=[];saveCfg();rebuildHide();S.catsDirty=true;drawCats(p,0)});
 btn(acts,'Listo',()=>ovClose('#cm'),'main','check');
 const fs=$$('.f',p);(fs[fi]||fs[0]).focus()}

/* ---------- Perfil: cuenta + ajustes + cuentas guardadas ---------- */
const keepIdx=()=>$$('.f',$('#pf')).indexOf(document.activeElement);
function srow(parent,label,value,fn,icon){const r=h('div','srow f');r.tabIndex=0;const l=h('span','sl');if(icon)l.innerHTML=ic(icon);l.appendChild(document.createTextNode(label));r.appendChild(l);if(value!=null)r.appendChild(h('span','sv',value));
 r.onclick=()=>{const k=keepIdx();const x=fn(r);if(x&&x.then)x.then(()=>renderProfile(k));else if(x!==false)renderProfile(k)};parent.appendChild(r);return r}
function renderProfile(fi){const box=$('#pf');box.textContent='';box.scrollTop=0;
 const w=h('div','pfw'),a=S.acct||{},A=acctSummary(a,Date.now()),nm=a.type==='X'?a.user:hostOf(a.url||'');
 /* —— columna cuenta —— */
 const L=h('div','pfa'),hd=h('div','pfh');hd.appendChild(h('div','avatar',initial(nm)));const ht=h('div','');ht.appendChild(h('h2','',nm||'Cuenta'));ht.appendChild(h('p','dm',a.type==='X'?'Xtream Codes  ·  '+hostOf(a.host||''):'Lista M3U / M3U8'));hd.appendChild(ht);L.appendChild(hd);
 if(A.kind==='X'){const big=h('div','pfx lv-'+A.level);big.appendChild(h('b','',A.days===null?'∞':A.days<0?'0':String(A.days)));big.appendChild(h('span','',A.days===null?'sin vencimiento':A.days<0?'cuenta vencida':A.days===1?'día restante':'días restantes'));L.appendChild(big);
  const g=h('u','pgb lv-'+A.level),s=h('s');s.style.width=A.pct+'%';g.appendChild(s);L.appendChild(g);L.appendChild(h('p','dm',A.text+(A.conn?'  ·  Conexiones: '+A.conn:'')))}
 const D=describeAccount(a,Date.now()),rows=h('div','rows');D.rows.forEach(r=>{const d=h('div','row');d.appendChild(h('span','rl',r[0]));d.appendChild(h('span','rv',r[1]));rows.appendChild(d)});L.appendChild(rows);
 D.warns.forEach(x=>L.appendChild(h('p','warn','⚠ '+x)));
 if(S.fromCache)L.appendChild(h('p','dm','Catálogo guardado el '+fmtDateTime(S.fromCache)+'. Usa «Recargar contenido» para actualizar.'));
 const ab=h('div','acts');L.appendChild(ab);
 if(a.type==='X')btn(ab,'Actualizar datos',async()=>{const k=keepIdx();try{a.info=await S.xt.api('');toast('Datos de la cuenta actualizados',2500);renderProfile(k)}catch(e){toast('No se pudo actualizar: '+e.message)}},'','refresh');
 btn(ab,'Recargar contenido',()=>{connect(S.cfg,true)},'','refresh');
 w.appendChild(L);
 /* —— columna ajustes —— */
 const R=h('div','pfs');
 R.appendChild(h('h3','sh','Mis cosas'));
 srow(R,'Favoritos',String(favCount()),()=>{showPage('favs',{focus:true});return false},'star');
 srow(R,'Categorías visibles',(CFG.hide.live.length+CFG.hide.movie.length+CFG.hide.series.length)?(CFG.hide.live.length+CFG.hide.movie.length+CFG.hide.series.length)+' ocultas':'Todas',()=>{openCats();return false},'eyeoff');
 srow(R,'Borrar historial','Seguir viendo y recientes',()=>{Object.keys(HIST).forEach(k=>delete HIST[k]);delete LAST.cur;delete LAST.prev;lsSet('iptv_last',LAST);lsSet('iptv_hist',HIST);msgC('Historial borrado')},'hist');
 R.appendChild(h('h3','sh','Reproducción'));
 srow(R,'Al abrir la app',CFG.start==='last'?'Último canal':'Pantalla de inicio',()=>{CFG.start=CFG.start==='last'?'home':'last';saveCfg()},'play');
 if(!narrow())srow(R,'Vista previa de canales',CFG.pv?'Sí':'No',()=>{CFG.pv=CFG.pv?0:1;saveCfg();if(!CFG.pv&&S.pv)stop()},'tv');
 if(!narrow())srow(R,'Sonido en la vista previa',CFG.pvs?'Con sonido':'En silencio',()=>{CFG.pvs=CFG.pvs?0:1;saveCfg();if(S.pv)$('#v').muted=!CFG.pvs},'audio');
 srow(R,'Relación de aspecto',aspectOf(CFG.ar)[1],()=>{CFG.ar=nextAspect(CFG.ar);saveCfg();applyAspect()},'aspect');
 srow(R,'Formato de TV (Xtream)',({auto:'Automático',m3u8:'m3u8 (HLS)',ts:'ts (MPEG-TS)'})[CFG.fmt],()=>{CFG.fmt=CFG.fmt==='auto'?'m3u8':CFG.fmt==='m3u8'?'ts':'auto';saveCfg();msgC('Se aplica al abrir el próximo canal.')},'sliders');
 if(FSAPI())srow(R,'Pantalla completa automática (celular)',CFG.fsa===0?'Desactivada':'Activada',()=>{CFG.fsa=CFG.fsa===0?1:0;saveCfg()},'expand');
 srow(R,'Reloj',CFG.h12?'12 horas':'24 horas',()=>{CFG.h12=CFG.h12?0:1;saveCfg();updClock()},'clock');
 R.appendChild(h('h3','sh','Rendimiento'));
 srow(R,'Efectos visuales',CFG.fx==='lite'?'Ligeros (más fluido)':CFG.fx==='full'?'Completos':'Automático · '+(isLite()?'ligeros':'completos'),()=>{CFG.fx=CFG.fx==='auto'?'lite':CFG.fx==='lite'?'full':'auto';saveCfg();applyFx()},'speed');
 if(window.PWA_EV&&!PWA_ON())srow(R,'Instalar ElohimPlayer','Icono en tu pantalla de inicio',()=>{const ev=window.PWA_EV;window.PWA_EV=null;ev.prompt();return ev.userChoice.then(()=>{})},'play');
 R.appendChild(h('h3','sh','Control parental'));
 if(!CFG.pin)srow(R,'Contenido adulto','Oculto · requiere PIN',async()=>{const n=await pinPrompt('Crea un PIN de 4 dígitos para poder ver contenido adulto');if(n&&/^\d{4}$/.test(n)){CFG.pin=n;saveCfg();S.unlocked=true;msgC('PIN creado. Contenido adulto visible hasta cerrar la app');rerenderBg()}else if(n!==null)msgC('El PIN debe tener 4 números')},'lock');
 else{srow(R,S.unlocked?'Contenido adulto':'Contenido adulto',S.unlocked?'Visible':'Oculto',async()=>{if(S.unlocked)S.unlocked=false;else{const o=await pinPrompt('PIN');if(o!==CFG.pin){msgC('PIN incorrecto');return}S.unlocked=true}rerenderBg()},'lock');
  srow(R,'Cambiar PIN','',async()=>{const o=await pinPrompt('PIN actual');if(o!==CFG.pin){msgC('PIN incorrecto');return}const n=await pinPrompt('Nuevo PIN (4 dígitos)');if(n&&/^\d{4}$/.test(n)){CFG.pin=n;saveCfg();msgC('PIN cambiado')}else if(n!==null)msgC('El PIN debe tener 4 números')},'lock');
  srow(R,'Quitar PIN','',async()=>{const o=await pinPrompt('PIN actual');if(o!==CFG.pin){msgC('PIN incorrecto');return}CFG.pin='';saveCfg();S.unlocked=false;msgC('PIN eliminado');rerenderBg()},'trash')}
 if(a.type!=='X'||true){R.appendChild(h('h3','sh','Guía de programación (XMLTV)'));
  const e=h('input','f');e.placeholder='URL de guía .xml para listas M3U';e.value=CFG.epg||'';R.appendChild(e);const eb=h('div','acts');R.appendChild(eb);
  btn(eb,'Guardar guía',()=>{CFG.epg=e.value.trim();saveCfg();S.epgUrl=CFG.epg||S.data.epg||'';S.xmlP=null;msgC('Guía guardada')},'','check')}
 R.appendChild(h('h3','sh','Cuentas'));
 ACCTS.forEach(ac=>{const cur=S.cfg&&acctId(S.cfg)===ac.id,r=h('div','arow2');const b=h('div','srow f'+(cur?' cur':''));b.tabIndex=0;const l=h('span','sl');l.innerHTML=ic('user');l.appendChild(document.createTextNode(ac.name));b.appendChild(l);
  b.appendChild(h('span','sv',cur?'En uso':ac.exp?(ac.exp<Date.now()/1000?'Vencida':'Vence '+fmtDateEs(ac.exp*1000)):'Cambiar'));b.onclick=()=>{if(!cur){fillForm(ac.cfg);connect(ac.cfg)}};r.appendChild(b);
  if(!cur){const x=h('button','f ib');setIc(x,'trash');x.setAttribute('aria-label','Quitar');x.onclick=()=>{const k=keepIdx();ACCTS=ACCTS.filter(z=>z!==ac);lsSet('iptv_accts',ACCTS);renderProfile(Math.max(0,k-1))};r.appendChild(x)}R.appendChild(r)});
 srow(R,'Agregar o cambiar de cuenta','',()=>{try{localStorage.removeItem(KEY)}catch(e){}location.reload();return false},'users');
 const m=h('p','pfm');m.id='pfm';R.appendChild(m);R.appendChild(h('p','ft','ElohimSystem® 2026'));R.appendChild(h('p','dm','ElohimPlayer v'+VER+'  ·  La app no incluye contenido: usa solo listas y cuentas que tengas derecho a usar.'));
 w.appendChild(R);box.appendChild(w);
 if(fi!=null&&fi>=0){const f=$$('.f',box)[fi];f&&f.focus()}}
/* tras cambiar PIN / adultos: las demás pantallas deben recalcularse */
function rerenderBg(){S.idx=null}
