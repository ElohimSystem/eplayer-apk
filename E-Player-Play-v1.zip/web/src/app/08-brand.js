/* ===== v5.2 — marca ElohimPlayer: glifo play/pausa + carrusel «ElohimPlayer» -> «EP» ===== */
const GLYPH='<span class="logo"><svg viewBox="0 0 48 48" aria-hidden="true"><path class="g-tri" d="M18 12.5v23a1.6 1.6 0 0 0 2.5 1.3l18-11.5a1.6 1.6 0 0 0 0-2.7l-18-11.5A1.6 1.6 0 0 0 18 12.5z"/><rect class="g-b1" x="15" y="12" width="7" height="24" rx="2"/><rect class="g-b2" x="26" y="12" width="7" height="24" rx="2"/></svg></span>';
/* EP: la «E» son tres brazos; la «P» es una barra de pausa cuya segunda barra se transforma en triángulo de play */
const EPSVG='<svg class="epm" viewBox="0 0 66 40" aria-label="EP"><g class="ep-e"><rect x="2" y="2" width="7" height="36" rx="2"/><rect x="2" y="2" width="22" height="7" rx="2"/><rect x="2" y="16.5" width="17" height="7" rx="2"/><rect x="2" y="31" width="22" height="7" rx="2"/></g><g class="ep-p"><rect x="36" y="2" width="7" height="36" rx="2"/><path class="ep-tri" d="M48 4.4v31.2a1.5 1.5 0 0 0 2.3 1.3L64 21.3a1.5 1.5 0 0 0 0-2.6L50.3 3.1A1.5 1.5 0 0 0 48 4.4z"/><rect class="ep-bar" x="49" y="2" width="7" height="36" rx="2"/></g></svg>';
function mkBrand(el,loop){
 const L=(t,d)=>t.split('').map((c,i)=>'<i style="animation-delay:'+(d+i*.045).toFixed(2)+'s">'+c+'</i>').join('');
 el.className=(el.className+' eb').trim();
 el.innerHTML=GLYPH+'<span class="eb-win"><span class="eb-roll"><span class="ln"><span class="in eb-name"><b>'+L('Elohim',.25)+'</b><em>'+L('Player',.55)+'</em></span></span><span class="ln"><span class="in">'+EPSVG+'</span></span></span></span>';
 const win=el.querySelector('.eb-win'),ins=el.querySelectorAll('.in');let T=[];
 const fit=()=>{const k=el.classList.contains('ep')?1:0;win.style.width=ins[k].offsetWidth+'px'};
 const clr=()=>{T.forEach(clearTimeout);T=[]};
 const to=(ep)=>{el.classList.toggle('ep',ep);fit()};
 const fresh=()=>{el.classList.remove('fresh');void el.offsetWidth;el.classList.add('fresh')};
 function seq(){clr();to(false);fresh();T.push(setTimeout(()=>to(true),3800));
  if(loop)T.push(setTimeout(seq,3800+3600))}
 fit();seq();
 window.addEventListener('resize',fit);try{document.fonts&&document.fonts.ready&&document.fonts.ready.then(fit)}catch(e){}
 setTimeout(fit,300);
 el.onclick=()=>{if(!loop)seq()};
 return seq}
const BRAND={top:mkBrand(document.getElementById('brandTop'),false),big:mkBrand(document.getElementById('brandBig'),true)};
$$('[data-ic]').forEach(e=>{e.insertAdjacentHTML('afterbegin',ic(e.getAttribute('data-ic')))});
