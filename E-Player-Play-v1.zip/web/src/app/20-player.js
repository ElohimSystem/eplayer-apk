/* ===== v4 — reproductor: nativo / hls.js / mpegts.js, mini-reproductor, zapping, temporizador, aspecto ===== */
const liveUrl=u=>CFG.fmt!=='auto'&&/\/live\/[^\/]+\/[^\/]+\/\d+\.(m3u8|ts)(\?.*)?$/.test(u)?u.replace(/\.(m3u8|ts)(\?.*)?$/,'.'+CFG.fmt):u;
/* v2: películas/series Xtream — si el archivo no se reproduce nativamente se prueba la versión HLS (.m3u8) del mismo título */
const vodHls=u=>u.replace(/\.(mkv|mp4|avi|mov|wmv|flv|webm|m4v|mpg|mpeg|ts)(\?.*)?$/i,'.m3u8');
const isXVod=u=>/\/(movie|series)\/[^\/]+\/[^\/]+\/\d+\.[a-z0-9]+(\?.*)?$/i.test(u);
/* v2: averigua POR QUÉ falla un archivo de video (estado HTTP del servidor/proxy o tipo real de contenedor) */
async function diagnose(u){
 try{
  const r=await tmo(fetch(mx(u),{headers:{Range:'bytes=0-2047'}}),14000),ct=(r.headers.get('content-type')||'').split(';')[0];
  if(!r.ok&&r.status!==206){let t='';try{t=(await r.text()).slice(0,90)}catch(e){}
   const hint=r.status===403&&/Proxy solo/.test(t)?' (el Worker rechaza tu dominio: revisa APP_HOSTS)':r.status===403||r.status===401?' (el servidor del proveedor rechazó la petición: cuenta vencida, sin permiso o bloqueo de IP de Cloudflare)':r.status===404?' (el archivo ya no existe en el servidor)':r.status===502?' (el Worker no logró conectar con el servidor; si usa un puerto raro, Cloudflare puede bloquearlo)':r.status===429||r.status===884?' (demasiadas conexiones a la vez: cierra otros dispositivos)':'';
   return 'el servidor respondió HTTP '+r.status+hint+(t&&!hint?' · '+t:'')}
  let b;if(r.body&&r.body.getReader){const rd=r.body.getReader(),x=await rd.read();b=x.value||new Uint8Array(0);try{rd.cancel()}catch(e){}}else b=new Uint8Array(await r.arrayBuffer());
  const A=(i,n)=>String.fromCharCode.apply(null,Array.prototype.slice.call(b,i,i+n));
  if(!b.length)return 'el servidor devolvió un archivo vacío';
  if(b[0]===0x1A&&b[1]===0x45&&b[2]===0xDF&&b[3]===0xA3)return 'el archivo es MKV/WebM (Matroska). Chrome del celular casi nunca lo reproduce (y menos con video HEVC/H.265 o audio AC3/DTS)';
  if(A(0,4)==='RIFF'&&A(8,4)==='AVI ')return 'el archivo es AVI, formato que el navegador no reproduce';
  if(A(4,4)==='ftyp'){const br=A(8,4);return 'el archivo es MP4 ('+br+'), pero el navegador no puede decodificarlo: probablemente usa video HEVC/H.265 o audio AC3/DTS que este equipo no soporta'}
  if(A(0,3)==='FLV')return 'el archivo es FLV, formato que el navegador no reproduce';
  if(b[0]===0x47)return 'el archivo es MPEG-TS';
  if(b[0]===0x3C||/^\s*#EXTM3U/.test(A(0,10))||/text|json|html/i.test(ct))return 'el servidor no devolvió un video sino texto/HTML ('+(ct||'sin tipo')+'): enlace caducado, error del panel o sesión rechazada';
  return 'formato no reconocido ('+(ct||'sin tipo')+')';
 }catch(e){return 'no se pudo consultar el archivo ('+(e&&e.message||e)+'). Si el servidor es https:// el navegador bloquea la lectura; si es http:// revisa que el Worker esté en línea'}}
function errActions(show){const x=$('#errx');if(!x)return;x.textContent='';if(!show||S.live||S.pv){x.classList.add('hidden');return}
 const u=S.master||S.url,m=/^(https?):\/\/(.+)$/i.exec(u);if(!m){x.classList.add('hidden');return}
 if(/android/i.test(navigator.userAgent)){const a=h('a','eb','Abrir en VLC / otro reproductor');a.href='intent://'+m[2]+'#Intent;scheme='+m[1].toLowerCase()+';type=video/*;S.title='+encodeURIComponent(S.title||'')+';end';a.onclick=e=>e.stopPropagation();x.appendChild(a)}
 const c=h('button','eb','Copiar enlace');c.onclick=e=>{e.stopPropagation();const done=()=>toast('Enlace copiado. Pégalo en VLC → Flujo de red',4000);
  if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(u).then(done,()=>toast(u,12000));else toast(u,12000)};x.appendChild(c);x.classList.remove('hidden')}
let ibT=0,numS='',numT=0,drT=0,tapT=0,tapX=0;
function cleanup(){const v=$('#v');clearTimeout(stall);clearTimeout(wt);if(hls){try{hls.destroy()}catch(e){}hls=null}
 if(mp){try{mp.pause();mp.unload();mp.detachMediaElement();mp.destroy()}catch(e){}mp=null}
 v.onerror=null;v.removeAttribute('src');try{v.load()}catch(e){}}
function updTime(){const v=$('#v'),ok=v.duration&&isFinite(v.duration)&&!S.live;$('#tm').textContent=ok?fmtDur(v.currentTime)+' / '+fmtDur(v.duration):S.live?'EN VIVO':fmtDur(v.currentTime);
 $('#pg2').style.width=ok?(100*v.currentTime/v.duration)+'%':'0';
 const nx=$('#nx');if(ok&&S.epq&&S.epi+1<S.epq.length&&v.currentTime>5&&v.duration-v.currentTime<=25){if(nx.classList.contains('hidden')){setIc(nx,'play','Siguiente: '+S.epq[S.epi+1].title);nx.classList.remove('hidden')}}else nx.classList.add('hidden')}
function placeDock(){const p=$('#pl');if(!S.pv||p.classList.contains('hidden'))return;const r=$('#pvbox').getBoundingClientRect();p.style.cssText='left:'+r.left+'px;top:'+r.top+'px;width:'+r.width+'px;height:'+r.height+'px'}
function applyAspect(){$('#v').style.objectFit=S.pv?'contain':aspectOf(CFG.ar)[2]}
function setMode(){const p=$('#pl'),er=$('#err');if(!er.classList.contains('hidden'))er.textContent=S.pv?'No se pudo cargar este canal':(S.errLong||'');p.classList.toggle('dock',!!S.pv);p.classList.toggle('full',!S.pv);
 $('#v').muted=S.forcedMute||(!!S.pv&&!CFG.pvs&&!narrow());applyAspect();if(S.pv)placeDock();else p.style.cssText=''}
function playEpAt(n){if(S.epq&&n>=0&&n<S.epq.length){S.epi=n;const x=S.epq[n];S.startAt=0;play(x.url,x.fullTitle||x.title,false,null,playMeta(S.cur||{},'ep',x.fullTitle||x.title),0);return true}return false}
function playNext(){return playEpAt((S.epi|0)+1)}
function playPrev(){return playEpAt((S.epi|0)-1)}
function updEpBtns(){const e=!!(S.epq&&!S.live);$('#ctl').classList.toggle('isep',e);$('#cpv').classList.toggle('hidden',!(e&&S.epi>0));$('#cne').classList.toggle('hidden',!(e&&S.epi+1<S.epq.length));
 if(e){$('#cpv').title=S.epi>0?S.epq[S.epi-1].title:'';$('#cne').title=S.epi+1<S.epq.length?S.epq[S.epi+1].title:''}}
const countsHist=()=>!S.pv||narrow();
function play(url,title,live,master,meta,startAt,auto,pv){
 const v=$('#v'),pl=$('#pl');if(!pv&&(pl.classList.contains('hidden')||S.pv)){S.pf=document.activeElement;nav()}
 url=live?liveUrl(url):url;S.url=url;S.master=master||url;S.live=live;S.title=title;if(meta)S.meta=meta;S.startAt=startAt;if(!auto){S.rc=0;S.forcedMute=false}S.err='';S.pv=!!pv;
 pl.classList.remove('hidden');if(!pv&&FSAPI()&&touchy()&&CFG.fsa!==0)fsOn(true);setMode();$('#err').classList.add('hidden');errActions(false);$('#wait').classList.remove('hidden');setWait();$('#ctl').classList.toggle('islive',!!live);pl.classList.toggle('islive',!!live);$('#nx').classList.add('hidden');updEpBtns();
 if(live){setIc($('#cb'),'up');setIc($('#cf'),'down');setIc($('#cl'),'list','Canales');$('#cb').setAttribute('aria-label','Canal anterior en la lista');$('#cf').setAttribute('aria-label','Canal siguiente en la lista')}
 else{setIc($('#cb'),'back10');setIc($('#cf'),'fwd10');$('#cb').setAttribute('aria-label','Retroceder 10 segundos');$('#cf').setAttribute('aria-label','Adelantar 10 segundos')}
 try{v.playbackRate=1}catch(e){}
 $('#ti').textContent=title;cleanup();
 if(live&&countsHist()){const m=S.meta||{};saveHist(S.master,{live:1,name:m.name||title,logo:m.logo||'',type:'live',sid:m.sid,tid:m.tid});saveLast({name:m.name||title,logo:m.logo||'',sid:m.sid,tid:m.tid,cat:m.cat,url:S.master})}
 if(!pv)osd();
 const isH=/\.m3u8(\?|$)|[?&]type=m3u8/i.test(url),isTS=!isH&&(/\.ts(\?|$)/i.test(url)||/\/live\/[^\/]+\/[^\/]+\/\d+(\?|$)/.test(url)),
  nat=v.canPlayType('application/vnd.apple.mpegurl')!=='',hj=!!window.Hls&&Hls.isSupported(),mj=!!window.mpegts&&mpegts.isSupported(),c=[];
 if(isH){if(WEBOS&&nat)c.push('n');if(hj)c.push('h');if(!WEBOS&&nat)c.push('n');if(live&&/\/live\//.test(url)&&mj)c.push('t');if(!c.length)c.push('n')}
 else if(isTS){if(WEBOS)c.push('n');if(mj)c.push('m');if(!WEBOS)c.push('n')}else{c.push('n');if(!live&&hj&&isXVod(url))c.push('v')}
 let i=0,nr=0,mr=0;const E=encodeURIComponent,next=()=>{
  if(i>=c.length){clearTimeout(stall);$('#wait').classList.add('hidden');S.errLong='No se pudo reproducir'+(S.err?' ('+S.err+')':'')+'. '+(live?'Causas frecuentes: canal caído, máximo de conexiones alcanzado o bloqueo del servidor. Prueba Perfil > Formato de TV (m3u8/ts). Pulsa Atrás.':'Analizando el archivo…');$('#err').textContent=S.pv?'No se pudo cargar este canal':S.errLong;$('#err').classList.remove('hidden');
   if(!live){const u0=S.url;diagnose(url).then(d=>{if(S.url!==u0||$('#err').classList.contains('hidden'))return;S.errLong='No se pudo reproducir'+(S.err?' ('+S.err+')':'')+'. Diagnóstico: '+d+'.';if(!S.pv)$('#err').textContent=S.errLong;errActions(true)})}return}
  const m=c[i++];cleanup();stall=setTimeout(next,20000);v.onerror=()=>{const e=v.error;S.err=e?'error de medio '+e.code:'';next()};
  if(m==='h'||m==='v'){nr=0;mr=0;hls=new Hls({maxBufferLength:30,fragLoadingMaxRetry:4,levelLoadingMaxRetry:3,manifestLoadingMaxRetry:2,xhrSetup:PROXY?(x,u)=>x.open('GET',PX(u),true):undefined});
   hls.on(Hls.Events.ERROR,(e,d)=>{if(!d.fatal)return;S.err=d.details;
    if(d.type===Hls.ErrorTypes.NETWORK_ERROR&&nr++<3){clearTimeout(stall);stall=setTimeout(next,20000);setTimeout(()=>{hls&&hls.startLoad()},1200*nr)}
    else if(d.type===Hls.ErrorTypes.MEDIA_ERROR&&mr++<2)hls.recoverMediaError();else next()});
   hls.loadSource(m==='v'?vodHls(url):url);hls.attachMedia(v)}
  else if(m==='m'||m==='t'){const u2=m==='t'?url.replace(/\.m3u8(\?.*)?$/i,'.ts'):url;
   mp=mpegts.createPlayer({type:'mpegts',isLive:!!live,url:PROXY?PX(u2):u2},{enableWorker:false,liveBufferLatencyChasing:!!live});
   mp.on(mpegts.Events.ERROR,(t,d)=>{S.err=d||t;next()});mp.attachMediaElement(v);mp.load()}
  else v.src=mx(url);
  const p=v.play();if(p&&p.catch)p.catch(er=>{if(er&&er.name==='NotAllowedError'&&!v.muted){S.forcedMute=true;v.muted=true;const q=v.play();q&&q.catch&&q.catch(()=>{});toast('Toca la pantalla para activar el sonido',4000)}})};
 v.onplaying=()=>{clearTimeout(wsT);clearTimeout(stall);clearTimeout(wt);$('#wait').classList.add('hidden');clearTimeout(okT);okT=setTimeout(()=>{S.rc=0},30000);setIc($('#cp'),'pause')};
 v.onpause=()=>setIc($('#cp'),'play');
 v.onwaiting=()=>{$('#wait').classList.remove('hidden');$('#wss').textContent='Cargando…';clearTimeout(okT);clearTimeout(wt);
  if(S.live)wt=setTimeout(()=>{if(S.live&&S.rc<5){S.rc++;if(!S.pv)toast('Reconectando… ('+S.rc+'/5)',3000);play(S.url,S.title,true,S.master,null,undefined,true,S.pv)}},15000)};
 v.onloadedmetadata=()=>{const p=live?0:(S.startAt!=null?S.startAt:pos(S.master));if(p>10&&v.duration&&p<v.duration-30)v.currentTime=p};
 v.ontimeupdate=()=>{updTime();if(!S.pv&&Date.now()-lastSave>10000&&saveProg())lastSave=Date.now()};
 v.onended=()=>{markSeen(S.master);delete HIST[S.master];lsSet('iptv_hist',HIST);if(!playNext())stop()};
 next()}
function saveProg(){const v=$('#v');if(S.live||$('#pl').classList.contains('hidden')||!v.duration||!isFinite(v.duration)||!(v.currentTime>10&&v.currentTime<v.duration-30))return false;
 const m=S.meta||{};if(v.duration-v.currentTime<60)markSeen(S.master);saveHist(S.master,{name:m.name||S.title,logo:m.logo||'',type:m.type||'movie',t:Math.floor(v.currentTime),d:Math.floor(v.duration),sid:m.sid,sn:m.sn});return true}
window.addEventListener('pagehide',saveProg);document.addEventListener('visibilitychange',()=>{if(document.hidden)saveProg()});
/* vista previa -> pantalla completa sin reconectar (misma conexión del proveedor) */
function goFull(){const p=$('#pl');if(p.classList.contains('hidden')||!S.pv||!$('#err').classList.contains('hidden'))return false;S.pv=false;if(FSAPI()&&touchy()&&CFG.fsa!==0)fsOn(true);S.pf=document.activeElement;nav();setMode();$('#v').muted=!!S.forcedMute;
 const m=S.meta||{};if(S.live&&!countsHist()){}if(S.live){saveHist(S.master,{live:1,name:m.name||S.title,logo:m.logo||'',type:'live',sid:m.sid,tid:m.tid});saveLast({name:m.name||S.title,logo:m.logo||'',sid:m.sid,tid:m.tid,cat:m.cat,url:S.master})}osd();return true}
/* pantalla completa -> vuelve a la vista previa (TV, celular) o cierra */
function exitFull(){S.cf=false;if(touchy())unlockOr();closeDrawer();ovClose('#pm');$('#ib').classList.remove('show');
 if(S.live&&S.cur&&canDock()){S.pv=true;S.pvItem=S.cur;setMode();$('#pvp').classList.remove('idle');showPvInfo(S.cur);markPv();updHist();const l=S.pf;if(S.view&&S.view.indexOf(S.cur)>=0)focusCardOf(S.cur);else if(l&&document.body.contains(l))l.focus();placeDock();return}
 stop()}
function stop(){const v=$('#v');saveProg();v.onended=v.ontimeupdate=v.onplaying=v.onpause=v.onwaiting=v.onloadedmetadata=null;clearTimeout(okT);clearTimeout(pvT);try{v.pause()}catch(e){}cleanup();
 S.pv=false;S.pvItem=null;S.sleepAt=0;S.forcedMute=false;closeDrawer();ovClose('#pm');$('#ib').classList.remove('show');$('#pl').classList.add('hidden');$('#pl').style.cssText='';errActions(false);markPv();$('#pvh').textContent='Elige un canal para verlo aquí';setPvIdle();
 updHist();const l=S.pf;if(l&&document.body.contains(l)&&l.offsetWidth>0)l.focus();else{const f=document.querySelector('#eps:not(.hidden) .f')||$('#list .f')||$('#nav .on');f&&f.focus()}
 if(S.detail&&!$('#eps').classList.contains('hidden'))showDetail(S.detail)}
function updHist(){if(!isBrowse(S.page))return;const n=histItems(S.mode).length,e=document.querySelector('#cats [data-c=__hist]');
 if(n&&!e)return renderCats();if(!n&&e){e.remove();return}if(e)e.querySelector('b').textContent=n}
/* ---------- temporizador de apagado ---------- */
let sleepMin=0;
function setSleep(m){sleepMin=m;S.sleepAt=m?Date.now()+m*60000:0;toast(m?'La reproducción se detendrá en '+m+' min':'Temporizador desactivado',3000)}
setInterval(()=>{if(S.sleepAt&&Date.now()>=S.sleepAt){S.sleepAt=0;sleepMin=0;if(!$('#pl').classList.contains('hidden')){stop();toast('Reproducción detenida por el temporizador',8000)}}},4000);
/* ---------- zapping, número de canal, canal anterior, banner ---------- */
/* al mantener ▲▼ solo se conecta al canal en el que te detienes (antes abría una conexión por cada canal que pasaba) */
let zapT=0;
function zapTo(n){const i=S.zl[n];if(!i||i.type!=='live')return;S.zap=n;S.cur=i;S.pvItem=i;S.title=i.name;clearTimeout(zapT);
 if(playerFull())showBanner();
 zapT=setTimeout(()=>{if(S.cur===i)play(i.url,i.name,true,null,liveMeta(i),undefined,false,false)},230)}
function zap(d){if(S.zap<0||!S.zl.length)return;zapTo((S.zap+d+S.zl.length)%S.zl.length)}
function prevChannel(){const p=LAST.prev;if(!p||!p.url){toast('Aún no hay un canal anterior',2500);return}
 const it=idx('live')[p.url]||{name:p.name,logo:p.logo,cat:p.cat,type:'live',url:p.url,sid:p.sid,tid:p.tid};const k=S.zl.indexOf(it);S.zap=k;S.cur=it;S.pvItem=it;play(it.url,it.name,true,null,liveMeta(it),undefined,false,false)}
function numKey(d){numS=(numS+d).slice(-4);const e=$('#nm');e.textContent=numS;e.classList.remove('hidden');clearTimeout(numT);numT=setTimeout(numGo,1800)}
function numGo(){clearTimeout(numT);const n=parseInt(numS,10);numS='';$('#nm').classList.add('hidden');if(n>=1&&n<=S.zl.length)zapTo(n-1);else if(n)toast('No existe el canal '+n,2500)}
function showBanner(){if(!S.live||S.pv)return;const i=S.cur||{},b=$('#ib'),m=S.meta||{};b.textContent='';const t=h('div','ibt');
 if(S.zap>=0)t.appendChild(h('b','no',String(S.zap+1)));const lg=i.logo||m.logo;if(lg){const im=h('img');im.src=mx(lg);im.onerror=()=>im.remove();t.appendChild(im)}
 const d=h('div','ibn');d.appendChild(h('h2','',S.title));d.appendChild(h('p','dm',(i.cat||m.cat||'')+'  ·  En vivo'));t.appendChild(d);
 const sd=h('div','ibs');sd.appendChild(h('b','',hm(Date.now())));if(S.sleepAt)sd.appendChild(h('span','chipx','Se apaga en '+fmtLeft(S.sleepAt-Date.now())));t.appendChild(sd);b.appendChild(t);
 const ep=h('div','epg2');b.appendChild(ep);if(!TOUCH)b.appendChild(h('p','hint','◀ lista de canales    ▲ ▼ cambiar canal    ▶ opciones    0-9 ir a un número    verde: canal anterior'));
 b.classList.add('show');clearTimeout(ibT);ibT=setTimeout(()=>b.classList.remove('show'),6500);const u=S.url;epgFor(i).then(L=>{if(S.url===u)epgBlock(ep,L)})}
/* ---------- pantalla completa del navegador + giro a horizontal (celular) ---------- */
/* v2 APK: dentro de la app Android (window.AndroidApp) la pantalla completa y el giro los maneja la app nativa */
const NATIVE=()=>!!window.AndroidApp;
const FSAPI=()=>{if(NATIVE())return true;const e=document.documentElement;return !!(e.requestFullscreen||e.webkitRequestFullscreen)};
const isFS=()=>!!(document.fullscreenElement||document.webkitFullscreenElement);
const touchy=()=>TOUCH||narrow();
function lockLand(){if(NATIVE()){try{AndroidApp.landscape(true)}catch(x){}return}try{const o=screen.orientation;if(o&&o.lock){const q=o.lock('landscape');q&&q.catch&&q.catch(()=>{})}}catch(x){}}
function unlockOr(){if(NATIVE()){try{AndroidApp.landscape(false)}catch(x){}return}try{screen.orientation&&screen.orientation.unlock&&screen.orientation.unlock()}catch(x){}}
function fsOn(lock){if(NATIVE()){if(lock)lockLand();return}const e=document.documentElement,f=e.requestFullscreen||e.webkitRequestFullscreen;let r;try{if(f&&!isFS())r=f.call(e)}catch(x){}
 if(!lock)return;if(r&&r.then)r.then(lockLand,()=>{});else lockLand()}
function fsOff(){unlockOr();try{if(isFS()){const f=document.exitFullscreen||document.webkitExitFullscreen,r=f.call(document);r&&r.catch&&r.catch(()=>{})}}catch(x){}}
function updFsBtn(){const b=$('#cfs');if(b)setIc(b,isFS()?'shrink':'expand')}
document.addEventListener('fullscreenchange',()=>{updFsBtn();if(!isFS())unlockOr()});document.addEventListener('webkitfullscreenchange',()=>{updFsBtn();if(!isFS())unlockOr()});
/* al primer toque en un celular, el navegador pasa a pantalla completa (se va la barra de direcciones) */
(function(){let done=false;document.addEventListener('click',()=>{if(done)return;done=true;if(FSAPI()&&touchy()&&CFG.fsa!==0&&!isFS())fsOn(false)},true)})();
let ctlTT=0,wsT=0;
function setWait(){const m=S.meta||{},lg=$('#wlg');$('#wtt').textContent=S.title||'';$('#wss').textContent=S.live?'Sintonizando canal…':'Preparando video…';lg.textContent='';
 if(m.logo){const im=document.createElement('img');im.onerror=()=>{im.remove();setIc(lg,'play')};im.src=mx(m.logo);lg.appendChild(im)}else setIc(lg,'play');
 clearTimeout(wsT);wsT=setTimeout(()=>{$('#wss').textContent='Casi listo…'},4500)}
function ctlOn(){S.cf=true;showCtl();const b=$('#cp');b&&b.focus()}
function ctlOff(){S.cf=false;const a=document.activeElement;if(a&&a.blur&&$('#ctl').contains(a))a.blur();$('#ctl').classList.remove('show')}
function showCtl(){const c=$('#ctl');c.classList.add('show');clearTimeout(ctlT);ctlT=setTimeout(()=>{if(S.cf)ctlOff();else c.classList.remove('show')},S.cf?7000:4000);
 if(S.live)showBanner();else{const t=$('#ti');t.classList.remove('hidden');clearTimeout(ttl);ttl=setTimeout(()=>t.classList.add('hidden'),4000)}}
const osd=showCtl;
/* ---------- panel de canales sobre el video ---------- */
const D={open:false,cat:'*',q:'',items:[],vl:null};
function mkVL(box,rowH,mk){const sp=h('div','vsp');box.textContent='';box.appendChild(sp);let lo=-1,hi=-1;const o={n:0,sel:0};
 o.draw=()=>{const H=box.clientHeight||rowH*8,a=Math.max(0,Math.floor(box.scrollTop/rowH)-4),b=Math.min(o.n,Math.ceil((box.scrollTop+H)/rowH)+4);if(a===lo&&b===hi)return;lo=a;hi=b;sp.textContent='';
  for(let i=a;i<b;i++){const e=mk(i,i===o.sel);e.style.top=i*rowH+'px';e.style.height=rowH+'px';sp.appendChild(e)}};
 o.set=(n,sel)=>{o.n=n;o.sel=sel||0;sp.style.height=n*rowH+'px';lo=hi=-1;box.scrollTop=Math.max(0,o.sel*rowH-(box.clientHeight-rowH)/2);o.draw()};
 o.go=i=>{o.sel=Math.max(0,Math.min(o.n-1,i));const t=box.scrollTop,H=box.clientHeight,y=o.sel*rowH;if(y<t+rowH||y>t+H-rowH*2)box.scrollTop=Math.max(0,y-(H-rowH)/2);lo=hi=-1;o.draw()};
 box.onscroll=o.draw;return o}
function drCats(){const I=catInfo('live'),a=['*','__fav'];if(histItems('live').length)a.push('__hist');return a.concat(I.names)}
function drRow(k,sel){const it=D.items[k],e=h('div','cdr'+(sel?' sel':'')+(it===S.cur?' cur':'')),p=picOf(it);e.appendChild(h('b','no',String(k+1)));e.appendChild(p);
 const n=h('div','nm');n.appendChild(h('span','',it.name));const L=epgPeek(it),nn=L&&nowNext(L);n.appendChild(h('small','',nn&&nn.now?nn.now.title:''));e.appendChild(n);e.onclick=()=>drPick(k);return e}
function drLoad(){D.items=filterItems(D.cat,D.q,'live');const ci=D.items.indexOf(S.cur);$('#cdt').textContent=catLabel(D.cat,'live')+' ('+D.items.length+')';D.vl.set(D.items.length,ci>=0?ci:0);drInfo()}
function drInfo(){const it=D.items[D.vl.sel];if(!it)return;epgFor(it).then(L=>{if(!D.open||D.items[D.vl.sel]!==it)return;const n=nowNext(L);if(!n.now)return;const s=document.querySelector('#cdl .cdr.sel small');if(s)s.textContent=n.now.title})}
function openDrawer(){if(!S.live||S.pv)return;const d=$('#cd');D.cat=S.zcat||'*';D.q='';$('#cdq').value='';d.classList.remove('hidden');D.open=true;$('#ib').classList.remove('show');$('#ctl').classList.remove('show');
 const a=document.activeElement;a&&a.blur&&a.blur();const rh=Math.round(parseFloat(getComputedStyle(document.documentElement).fontSize)*3.6);D.vl=mkVL($('#cdl'),rh,drRow);drLoad();drRst()}
function closeDrawer(){if(!D.open)return;D.open=false;$('#cd').classList.add('hidden');clearTimeout(drT)}
function drRst(){clearTimeout(drT);drT=setTimeout(closeDrawer,12000)}
function drMove(d){D.vl.go(D.vl.sel+d);drInfo()}
function drCat(d){const c=drCats();let k=c.indexOf(D.cat);if(k<0)k=0;D.cat=c[(k+d+c.length)%c.length];drLoad()}
function drPick(k){const it=D.items[k];if(!it)return;S.zl=D.items;S.zcat=D.cat;closeDrawer();zapTo(k)}
$('#cdq').oninput=e=>{D.q=e.target.value;drLoad();drRst()};$('#cdp').onclick=()=>{drCat(-1);drRst()};$('#cdn').onclick=()=>{drCat(1);drRst()};
setIc($('#cdp'),'left');setIc($('#cdn'),'right');

/* ---------- menú del reproductor ---------- */
function mrow(m,label,value,fn,icon){const r=h('div','srow f');r.tabIndex=0;const l=h('span','sl');if(icon)l.innerHTML=ic(icon);l.appendChild(document.createTextNode(label));r.appendChild(l);if(value!=null&&value!=='')r.appendChild(h('span','sv',value));r.onclick=fn;m.appendChild(r);return r}
const SPEEDS=[0.75,1,1.25,1.5,2];
function playerMenu(fi){const m=ovOpen('#pm'),i=S.cur;m.appendChild(h('h2','',S.title));
 if(S.live&&i){const bx=h('div','epg2');m.appendChild(bx);epgFor(i).then(L=>epgBlock(bx,L))}
 const k=()=>$$('.f',m).indexOf(document.activeElement);
 if(i&&i.type!=='ep')mrow(m,isFav(i)?'Quitar de favoritos':'Agregar a favoritos','',()=>{const q=k();toggleFav(i);playerMenu(q)},isFav(i)?'starf':'star');
 if(S.live&&LAST.prev)mrow(m,'Canal anterior',LAST.prev.name,()=>{ovClose('#pm');prevChannel()},'swap');
 if(S.live)mrow(m,'Guía del canal','',guideMenu,'guide');
 mrow(m,'Calidad de video','',qualityMenu,'sliders');
 mrow(m,'Audio y subtítulos','',tracksMenu,'audio');
 mrow(m,'Relación de aspecto',aspectOf(CFG.ar)[1],()=>{const q=k();CFG.ar=nextAspect(CFG.ar);saveCfg();applyAspect();playerMenu(q)},'aspect');
 mrow(m,'Temporizador de apagado',sleepLabel(sleepMin)+(S.sleepAt?' · quedan '+fmtLeft(S.sleepAt-Date.now()):''),()=>{const q=k();setSleep(nextSleep(sleepMin));playerMenu(q)},'moon');
 if(!S.live)mrow(m,'Velocidad',(+$('#v').playbackRate||1)+'×',()=>{const q=k(),v=$('#v'),c=SPEEDS.indexOf(+v.playbackRate||1);v.playbackRate=SPEEDS[(c+1)%SPEEDS.length];playerMenu(q)},'speed');
 mrow(m,'Cerrar','',()=>ovClose('#pm'),'close');
 const fs=$$('.f',m);(fs[fi]||fs[0]).focus()}
async function guideMenu(){const m=ovOpen('#pm');m.appendChild(h('h2','','Guía de '+S.title));const bx=h('div','guide');m.appendChild(bx);bx.appendChild(h('p','dm','Cargando…'));
 mrow(m,'Volver','',()=>playerMenu(),'left').focus();
 const L=S.cur?await epgFor(S.cur):[];bx.textContent='';if(!L.length){bx.appendChild(h('p','dm','Sin guía disponible para este canal.'));return}
 L.forEach((x,k)=>{const r=h('div','gr'+(k===0&&x.start<=Date.now()?' now':''));r.appendChild(h('b','',hm(x.start)+' – '+hm(x.end)));const t=h('div','');t.appendChild(h('span','',x.title));if(x.desc)t.appendChild(h('small','',x.desc.slice(0,160)));r.appendChild(t);bx.appendChild(r)})}
async function qualityMenu(){const m=ovOpen('#pm'),t=S.title;m.appendChild(h('h2','','Calidad de video'));let L=[];
 if(/\.m3u8(\?|$)/i.test(S.master)){try{const r=await get(S.master);L=parseVariants(await r.text(),S.master)}catch(e){}}
 if(!L.length)m.appendChild(h('p','dm','Este contenido no ofrece varias calidades (o el servidor no permite leer la lista).'));
 else{mrow(m,'Automática','',()=>{ovClose('#pm');play(S.master,t,S.live,null,null,S.live?undefined:$('#v').currentTime)});L.forEach(q=>mrow(m,q.label||'Variante','',()=>{ovClose('#pm');play(q.url,t,S.live,S.master,null,S.live?undefined:$('#v').currentTime)}))}
 mrow(m,'Volver','',()=>playerMenu(),'left');$$('.f',m)[0].focus()}
function tracksMenu(){const m=ovOpen('#pm'),v=$('#v');m.appendChild(h('h2','','Audio y subtítulos'));let any=false;const mk=(l,on,fn)=>mrow(m,(on?'● ':'○ ')+l,'',fn);
 if(hls){const at=hls.audioTracks||[];if(at.length>1){any=true;m.appendChild(h('p','sh','Audio'));at.forEach((t,k)=>mk(t.name||t.lang||'Pista '+(k+1),hls.audioTrack===k,()=>{hls.audioTrack=k;tracksMenu()}))}
  const st=hls.subtitleTracks||[];if(st.length){any=true;m.appendChild(h('p','sh','Subtítulos'));mk('Desactivados',hls.subtitleTrack<0,()=>{hls.subtitleTrack=-1;tracksMenu()});
   st.forEach((t,k)=>mk(t.name||t.lang||'Subtítulo '+(k+1),hls.subtitleTrack===k,()=>{hls.subtitleDisplay=true;hls.subtitleTrack=k;tracksMenu()}))}}
 else{const a=v.audioTracks;if(a&&a.length>1){any=true;m.appendChild(h('p','sh','Audio'));for(let k=0;k<a.length;k++)(k=>mk(a[k].label||a[k].language||'Pista '+(k+1),a[k].enabled,()=>{for(let j=0;j<a.length;j++)a[j].enabled=j===k;tracksMenu()}))(k)}
  const tt=Array.prototype.filter.call(v.textTracks||[],t=>/subtitles|captions/.test(t.kind));
  if(tt.length){any=true;m.appendChild(h('p','sh','Subtítulos'));mk('Desactivados',!tt.some(t=>t.mode==='showing'),()=>{tt.forEach(t=>t.mode='disabled');tracksMenu()});tt.forEach((t,k)=>mk(t.label||t.language||'Subtítulo '+(k+1),t.mode==='showing',()=>{tt.forEach(x=>x.mode='disabled');t.mode='showing';tracksMenu()}))}}
 if(!any)m.appendChild(h('p','dm','Este contenido no ofrece varias pistas de audio ni subtítulos.'));
 mrow(m,'Volver','',()=>playerMenu(),'left');$$('.f',m)[0].focus()}

/* ---------- controles táctiles / ratón ---------- */
const seekBy=d=>{const v=$('#v');if(!S.live&&v.duration){v.currentTime=Math.max(0,Math.min(v.duration,v.currentTime+d))}};
const toggleP=()=>{const v=$('#v');if(v.paused){const p=v.play();p&&p.catch&&p.catch(()=>{})}else v.pause()};
function unforce(){if(S.forcedMute){S.forcedMute=false;$('#v').muted=false}}
function flash(side){const d=$('#dbl');d.textContent=side<0?'−10 s':'+10 s';d.className='show '+(side<0?'l':'r');clearTimeout(d._t);d._t=setTimeout(()=>{d.className=''},600)}
$('#pl').addEventListener('mousemove',()=>{if(!S.pv&&!D.open)showCtl()});$('#pl').addEventListener('touchstart',()=>{if(!S.pv&&!D.open)showCtl()});
$('#pl').addEventListener('click',e=>{unforce();if(S.pv){if(!goFull()&&S.cur&&S.cur.type==='live')openItem(S.cur);return}if(D.open){closeDrawer();return}
 if(!S.live&&TOUCH){const now=Date.now(),r=$('#pl').getBoundingClientRect(),x=(e.clientX-r.left)/r.width;
  if(now-tapT<320&&(x<0.35||x>0.65)&&Math.abs(x-tapX)<0.2){seekBy(x<0.5?-10:10);flash(x<0.5?-1:1);tapT=0;return}tapT=now;tapX=x}
 showCtl()});
$('#cb').onclick=e=>{e.stopPropagation();if(S.live)zap(-1);else seekBy(-10);showCtl()};$('#cf').onclick=e=>{e.stopPropagation();if(S.live)zap(1);else seekBy(10);showCtl()};
$('#cp').onclick=e=>{e.stopPropagation();toggleP();showCtl()};$('#cl').onclick=e=>{e.stopPropagation();openDrawer()};
$('#cm2').onclick=e=>{e.stopPropagation();playerMenu()};$('#cx').onclick=e=>{e.stopPropagation();exitFull()};$('#nx').onclick=e=>{e.stopPropagation();playNext()};
$('#ca').onclick=e=>{e.stopPropagation();CFG.ar=nextAspect(CFG.ar);saveCfg();applyAspect();toast('Aspecto: '+aspectOf(CFG.ar)[1],1800);showCtl()};
$('#cz').onclick=e=>{e.stopPropagation();setSleep(nextSleep(sleepMin));showCtl()};
if(NATIVE()||!FSAPI()||!(TOUCH||narrow()))$('#cfs').classList.add('hidden');else $('#cfs').classList.remove('hidden');setIc($('#cfs'),'expand');$('#cfs').onclick=e=>{e.stopPropagation();if(isFS())fsOff();else fsOn(true);showCtl()};window.addEventListener('touchstart',()=>{if(FSAPI()&&!NATIVE())$('#cfs').classList.remove('hidden')},{once:true,passive:true});
setIc($('#cpv'),'skipb');setIc($('#cne'),'skipf');$('#cpv').onclick=e=>{e.stopPropagation();playPrev();showCtl()};$('#cne').onclick=e=>{e.stopPropagation();playNext();showCtl()};
$('#bar').onkeydown=null;setIc($('#cx'),'left');setIc($('#cz'),'moon');setIc($('#ca'),'aspect');setIc($('#cm2'),'more');setIc($('#cp'),'play');
$('#bar').onclick=e=>{e.stopPropagation();const v=$('#v');if(S.live||!v.duration)return;const r=$('#bar').getBoundingClientRect();v.currentTime=v.duration*Math.max(0,Math.min(1,(e.clientX-r.left)/r.width));showCtl()};
$('#pvf').onclick=()=>{S.focusItem&&openItem(S.focusItem)};$('#pvs').onclick=()=>{const i=S.focusItem;if(i){toggleFav(i);refStar(i)}};$('#pvx').onclick=()=>{S.pf=$('#list .card.pvon')||null;stop()};
window.addEventListener('resize',()=>{if(S.pv){if(!canDock())stop();else placeDock()}});
window.addEventListener('orientationchange',()=>setTimeout(placeDock,300));
