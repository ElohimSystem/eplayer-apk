/* npm run build  ->  public/   (opcional: PROXY_URL=https://...run.app npm run build  para usar la URL directa de la función) */
const fs=require('fs'),path=require('path'),crypto=require('crypto');
let esbuild;try{esbuild=require('esbuild')}catch(e){console.error('Falta esbuild. Ejecuta primero:  npm install');process.exit(1)}
const R=(...a)=>path.join(__dirname,'..',...a),PUB=R('public');
const SRC=['lib.js','app/00-core.js','app/08-brand.js','app/10-ui.js','app/15-screens.js','app/20-player.js','app/30-login-input.js','app/35-install.js','app/40-license.js'];
const code=SRC.map(f=>fs.readFileSync(R('src',f),'utf8')).join('\n');
const js=esbuild.transformSync(code,{target:'chrome53',minify:true}).code;   /* chrome53: también corre en navegadores de TV antiguos */
const VER=require(R('package.json')).version;
fs.rmSync(PUB,{recursive:true,force:true});fs.mkdirSync(PUB,{recursive:true});
fs.writeFileSync(path.join(PUB,'app.js'),js);
['index.html','style.css','hls.min.js','mpegts.min.js','manifest.webmanifest','icon-192.png','icon-512.png','icon-maskable-512.png'].forEach(f=>fs.copyFileSync(R('src',f),path.join(PUB,f)));
let PURL=(process.env.PROXY_URL||'').trim();
if(!PURL&&fs.existsSync(R('proxy-url.txt')))PURL=fs.readFileSync(R('proxy-url.txt'),'utf8').split('\n').map(s=>s.trim()).filter(s=>s&&s[0]!=='#')[0]||'';
PURL=PURL.replace(/\/+$/,'');
if(PURL&&!/^https?:\/\//.test(PURL)){console.error('proxy-url.txt: la URL debe empezar con https://');process.exit(1)}
fs.writeFileSync(path.join(PUB,'config.js'),'window.IPTV_PROXY=true;window.IPTV_PROXY_URL='+JSON.stringify(PURL)+';\n');
/* la versión del service worker cambia sola con cada cambio de contenido: los usuarios reciben la actualización */
const hash=crypto.createHash('sha1').update(js).update(fs.readFileSync(R('src/index.html'))).update(fs.readFileSync(R('src/style.css'))).digest('hex').slice(0,8);
fs.writeFileSync(path.join(PUB,'sw.js'),fs.readFileSync(R('src/sw.js'),'utf8').replace('__VER__',VER+'-'+hash));
console.log('public/ listo (v'+VER+'-'+hash+', app.js '+Math.round(js.length/1024)+' KB)'+(PURL?' · proxy: '+PURL:' · ⚠ SIN proxy (pon la URL de tu Worker en proxy-url.txt)'));
