/* npm start -> http://localhost:8080  (sirve public/ y usa el mismo proxy que la Cloud Function; sin comprobación de origen) */
const http=require('http'),fs=require('fs'),path=require('path');
process.env.PROXY_OPEN=process.env.PROXY_OPEN||'1';
const {handler}=require('../opcional-cloud-functions/proxy');
const ROOT=path.join(__dirname,'..','public'),PORT=+process.env.PORT||8080;
const MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png','.webmanifest':'application/manifest+json'};
http.createServer((req,res)=>{
 const u=new URL(req.url,'http://x');if(u.pathname==='/proxy')return handler(req,res);
 let rel;try{rel=decodeURIComponent(u.pathname)}catch(e){res.writeHead(400);return res.end('bad')}
 const f=path.normalize(path.join(ROOT,rel==='/'?'index.html':rel));
 if(f!==ROOT&&!f.startsWith(ROOT+path.sep)){res.writeHead(403);return res.end('403')}
 fs.readFile(f,(e,d)=>{if(e){res.writeHead(404);return res.end('404 (¿ejecutaste npm run build?)')}res.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream','Cache-Control':'no-store'});res.end(d)})
}).listen(PORT,'127.0.0.1',()=>console.log('ElohimPlayer PWA (local): http://localhost:'+PORT));
