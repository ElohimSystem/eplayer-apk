/* Genera los archivos de configuración a partir de las Variables de GitHub. Uso: node gen.js app|store|version <salida> [codigo] */
const fs = require('fs'), E = process.env, modo = process.argv[2], out = process.argv[3];
const tienda = (E.TIENDA_URL || 'https://elohimplay.web.app').replace(/\/+$/, ''), api = (E.API_URL || '').replace(/\/+$/, '');
const wa = (E.WHATSAPP || '').replace(/\D/g, '');
const pr = (E.PRECIOS || '3,8,25,60').split(',').map(x => Number(x.trim()) || 0);
if (modo === 'app') fs.writeFileSync(out, 'window.IPTV_PROXY=false;window.IPTV_PROXY_URL="";window.LIC=' + JSON.stringify({ api, tienda, whatsapp: wa }) + ';\n');
if (modo === 'store') {
  const planes = [
    { id: '30d', nombre: '30 días', precio: pr[0], nota: 'Un mes completo' },
    { id: '90d', nombre: '3 meses', precio: pr[1], nota: 'Más barato que pagar mes a mes' },
    { id: '365d', nombre: '1 año', precio: pr[2], nota: 'El mejor precio por mes', destacado: true },
    { id: 'vida', nombre: 'De por vida', precio: pr[3], nota: 'Un solo pago, sin vencimiento', oro: true }
  ];
  fs.writeFileSync(out, 'window.EP=' + JSON.stringify({ marca: 'E-Player', whatsapp: wa, email: (E.CORREO || '').trim(), api, paypal: false, moneda: E.MONEDA || 'USD', planes }) + ';\n');
}
if (modo === 'version') fs.writeFileSync(out, JSON.stringify({ code: Number(process.argv[4]), url: tienda + '/E-Player.apk', obligatoria: E.OBLIGATORIA === 'true', notas: E.NOTAS || '' }));
