window.IPTV_PROXY=false;window.IPTV_PROXY_URL="";window.LIC={};
