package com.elohim.eplayer;

/** VERSIÓN GOOGLE PLAY: las actualizaciones las gestiona solo Play. Aquí no se descarga ni instala nada. */
final class Updater {
    private Updater() { }

    static void instalar(MainActivity a, String url) {
        a.js("window.__upd&&window.__upd('err',0)");
    }
}
