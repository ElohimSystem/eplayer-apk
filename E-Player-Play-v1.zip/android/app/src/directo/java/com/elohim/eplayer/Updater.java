package com.elohim.eplayer;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** VERSIÓN DIRECTA (APK propio): descarga e instala actualizaciones. No existe en la versión de Google Play. */
final class Updater {
    private Updater() { }

    static void instalar(final MainActivity a, final String url) {
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (Build.VERSION.SDK_INT >= 26 && !a.getPackageManager().canRequestPackageInstalls()) {
                    try {
                        a.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                Uri.parse("package:" + a.getPackageName())));
                    } catch (Exception ignored) { }
                    a.js("window.__upd&&window.__upd('perm',0)");
                    return;
                }
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        descargar(a, url);
                    }
                }).start();
            }
        });
    }

    private static void descargar(final MainActivity a, String url) {
        try {
            File dir = new File(a.getCacheDir(), "apk");
            dir.mkdirs();
            final File f = new File(dir, "update.apk");
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
            c.setInstanceFollowRedirects(true);
            int len = c.getContentLength();
            InputStream in = c.getInputStream();
            FileOutputStream o = new FileOutputStream(f);
            byte[] buf = new byte[32768];
            int n, tot = 0, last = -1;
            while ((n = in.read(buf)) > 0) {
                o.write(buf, 0, n);
                tot += n;
                if (len > 0) {
                    int pc = (int) (100L * tot / len);
                    if (pc != last) {
                        last = pc;
                        a.js("window.__upd&&window.__upd('prog'," + pc + ")");
                    }
                }
            }
            o.close();
            in.close();
            c.disconnect();
            a.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Uri u = FileProvider.getUriForFile(a, a.getPackageName() + ".fp", f);
                        Intent i = new Intent(Intent.ACTION_VIEW);
                        i.setDataAndType(u, "application/vnd.android.package-archive");
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                        a.startActivity(i);
                        a.js("window.__upd&&window.__upd('done',100)");
                    } catch (Exception e) {
                        a.js("window.__upd&&window.__upd('err',0)");
                    }
                }
            });
        } catch (Exception e) {
            a.js("window.__upd&&window.__upd('err',0)");
        }
    }
}
